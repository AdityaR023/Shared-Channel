from fastapi import FastAPI, Request, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from typing import List

# ── App setup ─────────────────────────────────────────────────────────
app = FastAPI(title="SmartQnA", version="0.1.0")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ── Request / Response models ─────────────────────────────────────────

class SignupRequest(BaseModel):
    username: str
    email:    str
    password: str
    domains:  List[str]

class SearchRequest(BaseModel):
    query:        str
    top_k:        int = 5
    brand_filter: str = None
    model_filter: str = None
    domain:       str = None

class ChatRequest(BaseModel):
    query:         str
    brand_filter:  str = None
    source_filter: str = None
    domain:        str = None

# ── Page routes (HTML) ────────────────────────────────────────────────

@app.get("/")
def root():
    return RedirectResponse(url="/login")

@app.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/signup")
def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})

@app.get("/signup/success")
def signup_success_page(request: Request):
    return templates.TemplateResponse("signup_success.html", {"request": request})

@app.get("/upload")
def upload_page(request: Request):
    return templates.TemplateResponse("documents.html", {"request": request})

@app.get("/chat")
def chat_page(request: Request):
    return templates.TemplateResponse("chat.html", {"request": request})

@app.get("/search")
def search_page(request: Request):
    return templates.TemplateResponse("search.html", {"request": request})

@app.get("/profile")
def profile_page(request: Request):
    return templates.TemplateResponse("profile.html", {"request": request})

# ── Auth API stubs (Group B implements real logic) ────────────────────

@app.post("/api/auth/login")
async def login():
    # Group B: validate credentials, return real JWT
    return {
        "access_token": "stub_jwt_token",
        "token_type":   "bearer",
        "user": {
            "id":       "user_001",
            "email":    "test@example.com",
            "username": "testuser",
            "domains":  ["4G", "5G"],
        }
    }

@app.post("/api/auth/signup")
async def signup(body: SignupRequest):
    # Group B: create user, generate API key/secret, return JWT
    return {
        "access_token": "stub_jwt_token",
        "token_type":   "bearer",
        "api_key":      "smq_key_stub123",
        "api_secret":   "smq_secret_stub456",
        "user": {
            "id":       "user_002",
            "email":    body.email,
            "username": body.username,
            "domains":  body.domains,
        }
    }

# ── Search API stub (Group A implements real logic) ───────────────────

@app.post("/api/search")
async def search(body: SearchRequest):
    return {
        "results": [],
        "total":   0,
        "query":   body.query,
        "message": "stub — Group A implementing OpenSearch logic"
    }

# ── Ingestion API stub (Group A implements real logic) ────────────────

@app.post("/api/ingest")
async def ingest(file: UploadFile = File(...)):
    return {
        "success":        True,
        "filename":       file.filename,
        "chunks_indexed": 0,
        "message":        "stub — Group A implementing ingestion logic"
    }

# ── Document CRUD stubs (Group A implements real logic) ──────────────

@app.get("/api/documents")
async def list_documents(search: str = None, domain: str = None, type: str = None):
    # Group A: query OpenSearch, return real document list
    # Returning sample docs so the UI has something to display during development
    return {
        "documents": [
            {
                "id":           "doc_001",
                "brand":        "Samsung",
                "model":        "Galaxy S24 Ultra",
                "generation":   "5G",
                "domain":       "5G",
                "source":       "gsmarena.com",
                "content_type": "pdf",
                "uploaded_at":  "2024-01-15T10:30:00",
            },
            {
                "id":           "doc_002",
                "brand":        "Redmi",
                "model":        "Redmi 12",
                "generation":   "4G",
                "domain":       "4G",
                "source":       "91mobiles.com",
                "content_type": "csv",
                "uploaded_at":  "2024-01-16T14:00:00",
            },
        ],
        "total": 2
    }

@app.get("/api/documents/{doc_id}")
async def get_document(doc_id: str):
    # Group A: fetch single document metadata from OpenSearch
    return {
        "id":           doc_id,
        "brand":        "Samsung",
        "model":        "Galaxy S24 Ultra",
        "generation":   "5G",
        "domain":       "5G",
        "source":       "gsmarena.com",
        "content_type": "pdf",
        "uploaded_at":  "2024-01-15T10:30:00",
    }

@app.patch("/api/documents/{doc_id}")
async def update_document(doc_id: str, body: dict):
    # Group A: update document metadata in OpenSearch
    return { "success": True, "id": doc_id, "updated": body }

@app.delete("/api/documents/{doc_id}")
async def delete_document(doc_id: str):
    # Group A: delete document and its chunks from OpenSearch
    return { "success": True, "id": doc_id }

# ── Chat API stub (Group B implements real logic) ─────────────────────

@app.post("/api/chat")
async def chat(body: ChatRequest):
    return {
        "answer":              "stub — Group B implementing LLM + RAG logic",
        "sources":             [],
        "confidence":          0.0,
        "guardrail_triggered": False,
    }

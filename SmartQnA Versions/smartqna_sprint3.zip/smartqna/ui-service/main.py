"""
SmartQnA — UI Service
Port: 8000
Owns: HTML page serving, proxies API calls to Search and Completions services
"""

import os
import httpx
from typing import Optional, List
from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

# ── App setup ─────────────────────────────────────────────────────────
app = FastAPI(title="SmartQnA — UI Service", version="1.0.0")

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ── Downstream service URLs ───────────────────────────────────────────
SEARCH_SERVICE_URL      = os.getenv("SEARCH_SERVICE_URL",      "http://localhost:8001")
COMPLETIONS_SERVICE_URL = os.getenv("COMPLETIONS_SERVICE_URL", "http://localhost:8002")


# ═════════════════════════════════════════════════════════════════════
# REQUEST MODELS
# ═════════════════════════════════════════════════════════════════════

class SignupRequest(BaseModel):
    username: str
    email:    str
    password: str
    domains:  List[str]

class SearchRequest(BaseModel):
    query:             str
    top_k:             int           = 5
    domain_filter:     Optional[str] = None
    generation_filter: Optional[str] = None
    brand_filter:      Optional[str] = None
    source_filter:     Optional[str] = None

class ChatRequest(BaseModel):
    query:         str
    domain:        Optional[str] = None
    brand_filter:  Optional[str] = None
    source_filter: Optional[str] = None


# ═════════════════════════════════════════════════════════════════════
# PAGE ROUTES — serve HTML templates
# ═════════════════════════════════════════════════════════════════════

@app.get("/")
def root():
    return RedirectResponse(url="/login")

@app.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/signup")
def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})

@app.get("/signup/success")
def signup_success_page(request: Request):
    return templates.TemplateResponse("signup_success.html", {"request": request})

@app.get("/upload")
def upload_page(request: Request):
    return templates.TemplateResponse("documents.html", {"request": request})

@app.get("/chat")
def chat_page(request: Request):
    return templates.TemplateResponse("chat.html", {"request": request})

@app.get("/search")
def search_page(request: Request):
    return templates.TemplateResponse("search.html", {"request": request})

@app.get("/profile")
def profile_page(request: Request):
    return templates.TemplateResponse("profile.html", {"request": request})


# ═════════════════════════════════════════════════════════════════════
# HEALTH — check all downstream services
# ═════════════════════════════════════════════════════════════════════

@app.get("/health")
async def health():
    """Check health of all services."""
    status = {"ui": "ok", "search": "unknown", "completions": "unknown"}

    async with httpx.AsyncClient(timeout=3.0) as client:
        try:
            r = await client.get(f"{SEARCH_SERVICE_URL}/health")
            status["search"] = "ok" if r.status_code == 200 else "degraded"
        except Exception:
            status["search"] = "down"

        try:
            r = await client.get(f"{COMPLETIONS_SERVICE_URL}/health")
            status["completions"] = "ok" if r.status_code == 200 else "degraded"
        except Exception:
            status["completions"] = "down"

    return status


# ═════════════════════════════════════════════════════════════════════
# AUTH API — stubs (Group B to implement real JWT)
# ═════════════════════════════════════════════════════════════════════

@app.get("/api/auth/me")
async def get_me(request: Request):
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer ") or len(auth_header.split(" ")) < 2:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return {
        "id":       "user_001",
        "email":    "test@example.com",
        "username": "testuser",
        "domains":  ["4G", "5G"],
    }

@app.post("/api/auth/login")
async def login():
    return {
        "access_token": "stub_jwt_token",
        "token_type":   "bearer",
        "user": {
            "id":       "user_001",
            "email":    "test@example.com",
            "username": "testuser",
            "domains":  ["4G", "5G"],
        }
    }

@app.post("/api/auth/signup")
async def signup(body: SignupRequest):
    return {
        "access_token": "stub_jwt_token",
        "token_type":   "bearer",
        "api_key":      "smq_key_stub123",
        "api_secret":   "smq_secret_stub456",
        "user": {
            "id":       "user_002",
            "email":    body.email,
            "username": body.username,
            "domains":  body.domains,
        }
    }

@app.post("/api/auth/logout")
async def logout():
    return {"success": True}


# ═════════════════════════════════════════════════════════════════════
# SEARCH API — proxy to Search Service
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/search")
async def search_proxy(body: SearchRequest):
    """Proxy search request to Search Service (port 8001)."""
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                f"{SEARCH_SERVICE_URL}/search",
                json=body.model_dump(),
            )
        return response.json()
    except httpx.ConnectError:
        raise HTTPException(
            status_code=503,
            detail="Search service is unavailable. Please try again later."
        )


@app.post("/api/search/validate")
async def validate_proxy(body: SearchRequest):
    """Proxy validate request to Search Service."""
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                f"{SEARCH_SERVICE_URL}/search/validate",
                json=body.model_dump(),
            )
        return response.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Search service is unavailable.")


# ═════════════════════════════════════════════════════════════════════
# INGEST API — proxy to Search Service
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/ingest")
async def ingest_proxy(
    file:        UploadFile    = File(...),
    brand:       str           = Form(...),
    model:       str           = Form(...),
    generation:  str           = Form(...),
    source:      str           = Form(...),
    domain:      str           = Form(...),
    launch_year: Optional[str] = Form(None),
    price_range: Optional[str] = Form(None),
):
    """Forward file upload to Search Service for indexing."""
    try:
        file_content = await file.read()
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{SEARCH_SERVICE_URL}/ingest",
                files={"file": (file.filename, file_content, file.content_type)},
                data={
                    "brand":       brand,
                    "model":       model,
                    "generation":  generation,
                    "source":      source,
                    "domain":      domain,
                    "launch_year": launch_year or "",
                    "price_range": price_range or "",
                },
            )
        return response.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Search service is unavailable.")


# ═════════════════════════════════════════════════════════════════════
# DOCUMENT CRUD — proxy to Search Service
# ═════════════════════════════════════════════════════════════════════

@app.get("/api/documents")
async def list_documents_proxy(
    search: Optional[str] = Query(None),
    domain: Optional[str] = Query(None),
    type:   Optional[str] = Query(None),
):
    try:
        params = {}
        if search: params["search"] = search
        if domain: params["domain"] = domain
        if type:   params["type"]   = type

        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.get(
                f"{SEARCH_SERVICE_URL}/documents", params=params
            )
        return response.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Search service is unavailable.")


@app.delete("/api/documents/{doc_id:path}")
async def delete_document_proxy(doc_id: str):
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            response = await client.delete(
                f"{SEARCH_SERVICE_URL}/documents/{doc_id}"
            )
        return response.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Search service is unavailable.")


# ═════════════════════════════════════════════════════════════════════
# CHAT API — proxy to Completions Service
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/chat")
async def chat_proxy(
    request: Request,
    query:         Optional[str]        = Form(None),
    image:         Optional[UploadFile] = File(None),
    domain:        Optional[str]        = Form(None),
    brand_filter:  Optional[str]        = Form(None),
    source_filter: Optional[str]        = Form(None),
):
    """
    Forward chat request to Completions Service (port 8002).
    Handles both JSON (text) and FormData (multimodal with image).
    """
    try:
        # JSON path (text only)
        if query is None:
            body = await request.json()
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{COMPLETIONS_SERVICE_URL}/chat",
                    json=body,
                )
            return response.json()

        # FormData path (with image)
        else:
            data = {
                "query":  query,
                "domain": domain        or "",
                "brand_filter":  brand_filter  or "",
                "source_filter": source_filter or "",
            }
            files = {}
            if image:
                image_content = await image.read()
                files["image"] = (image.filename, image_content, image.content_type)

            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(
                    f"{COMPLETIONS_SERVICE_URL}/chat",
                    data=data,
                    files=files if files else None,
                )
            return response.json()

    except httpx.ConnectError:
        raise HTTPException(
            status_code=503,
            detail="Completions service is unavailable. Please try again later."
        )

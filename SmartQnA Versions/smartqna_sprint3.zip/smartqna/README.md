# SmartQnA — Microservices Architecture

## Services

| Service | Port | Owns |
|---|---|---|
| UI Service | 8000 | HTML pages, proxies to other services |
| Search Service | 8001 | ChromaDB indexing + hybrid search |
| Completions Service | 8002 | RAG pipeline, LLM, guardrails, security |

## Quick Start — Without Docker (Development)

### 1. Set your LLM credentials
```bash
cp .env .env.local
# Edit .env and add your API key
```

### 2. Start Search Service
```bash
cd search-service
pip install -r requirements.txt
# Copy Group A files here:
#   cp ../path/to/Chroma.py .
#   cp ../path/to/generate_metadata_file.py .
uvicorn main:app --port 8001 --reload
```

### 3. Start Completions Service
```bash
cd completions-service
pip install -r requirements.txt
uvicorn main:app --port 8002 --reload
```

### 4. Start UI Service
```bash
cd ui-service
pip install -r requirements.txt
# Copy your templates/ and static/ folders here
uvicorn main:app --port 8000 --reload
```

### 5. Open the app
```
http://localhost:8000
```

### 6. Check all services are healthy
```
http://localhost:8000/health
```

---

## Quick Start — With Docker

```bash
# Add your API key to .env first
docker-compose up
```

That's it. All 3 services start in the right order.

---

## Run Evaluation

```bash
cd evaluation
pip install -r requirements.txt

# Run full evaluation
python run_eval.py

# Run for specific category only
python run_eval.py --category 5G

# Results saved to evaluation/results/eval_report_TIMESTAMP.json
```

---

## Service Independence

If Search Service goes down:
- UI still loads ✅
- Chat returns 503 gracefully ⚠️
- Search page returns 503 gracefully ⚠️

If Completions Service goes down:
- UI still loads ✅
- Search page still works ✅
- Chat returns 503 gracefully ⚠️

If UI Service goes down:
- APIs still work via direct calls to 8001/8002 ✅

---

## Swapping the LLM

Edit `.env` only — nothing else changes:

```env
# Mistral (default)
LLM_BASE_URL=https://api.mistral.ai/v1
LLM_API_KEY=your_key
LLM_MODEL=mistral-small-latest

# Groq (free)
LLM_BASE_URL=https://api.groq.com/openai/v1
LLM_API_KEY=your_key
LLM_MODEL=llama3-8b-8192

# Azure OpenAI
LLM_BASE_URL=https://your-resource.openai.azure.com/openai/deployments/your-deployment
LLM_API_KEY=your_key
LLM_MODEL=gpt-4o
```

---

## Folder Structure

```
smartqna/
├── ui-service/
│   ├── main.py              ← page routes + API proxies
│   ├── templates/           ← all HTML pages
│   ├── static/              ← CSS + JS
│   └── requirements.txt
│
├── search-service/
│   ├── main.py              ← hybrid search + indexing
│   ├── Chroma.py            ← Group A: ChromaDB logic
│   ├── generate_metadata_file.py  ← Group A: metadata
│   └── requirements.txt
│
├── completions-service/
│   ├── main.py              ← RAG + LLM + guardrails + security
│   └── requirements.txt
│
├── evaluation/
│   ├── eval_dataset.json    ← 15 ground truth Q&A pairs
│   ├── run_eval.py          ← evaluation runner
│   └── results/             ← generated reports go here
│
├── docker-compose.yml
├── .env                     ← LLM credentials (never commit this)
└── README.md
```

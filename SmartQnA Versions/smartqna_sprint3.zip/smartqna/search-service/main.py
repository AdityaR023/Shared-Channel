"""
SmartQnA — Search Service
Port: 8001
Owns: ChromaDB indexing, hybrid search, result caching
"""

import os
import json
import time
import hashlib
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import shutil

# Group A modules
from Chroma import index_data, search_data, collection
from generate_metadata_file import generate_metadata

# ── App setup ─────────────────────────────────────────────────────────
app = FastAPI(title="SmartQnA — Search Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000"],  # UI service only
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs("Data",     exist_ok=True)
os.makedirs("metadata", exist_ok=True)


# ═════════════════════════════════════════════════════════════════════
# IN-MEMORY CACHE
# Simple TTL cache — same query returns instantly within TTL window
# Replace with Redis for production
# ═════════════════════════════════════════════════════════════════════

class SimpleCache:
    def __init__(self, ttl_seconds=300):  # 5 minute default TTL
        self._store = {}
        self._ttl   = ttl_seconds

    def _key(self, query: str, filters: dict) -> str:
        raw = json.dumps({"q": query.lower().strip(), **filters}, sort_keys=True)
        return hashlib.md5(raw.encode()).hexdigest()

    def get(self, query: str, filters: dict):
        key  = self._key(query, filters)
        item = self._store.get(key)
        if not item:
            return None
        if time.time() - item["ts"] > self._ttl:
            del self._store[key]
            return None
        return item["data"]

    def set(self, query: str, filters: dict, data):
        key = self._key(query, filters)
        self._store[key] = {"data": data, "ts": time.time()}

    def clear(self):
        self._store.clear()

    def stats(self):
        return {"entries": len(self._store), "ttl_seconds": self._ttl}

search_cache = SimpleCache(ttl_seconds=300)


# ═════════════════════════════════════════════════════════════════════
# HYBRID SEARCH
# Combines ChromaDB semantic search with basic keyword matching
# weighted_score = (semantic_weight × semantic) + (keyword_weight × keyword)
# ═════════════════════════════════════════════════════════════════════

def keyword_score(text: str, query: str) -> float:
    """
    Simple keyword relevance score.
    Counts how many query words appear in the text.
    Returns 0.0 – 1.0
    """
    if not text or not query:
        return 0.0

    query_words = [w.lower() for w in query.split() if len(w) > 2]
    if not query_words:
        return 0.0

    text_lower = text.lower()
    matches    = sum(1 for w in query_words if w in text_lower)
    return round(matches / len(query_words), 3)


def hybrid_search(
    query:      str,
    top_k:      int   = 5,
    sem_weight: float = 0.7,   # semantic search weight
    kw_weight:  float = 0.3,   # keyword search weight
    category_filter: Optional[str] = None,
) -> list:
    """
    Hybrid search combining semantic (ChromaDB) + keyword matching.

    ChromaDB returns distance scores (lower = better, 0 = perfect).
    We convert distance → relevance: relevance = 1 - (distance / 2)
    Then combine: final = sem_weight × semantic + kw_weight × keyword
    """
    # Fetch more than top_k from ChromaDB so we have room to re-rank
    fetch_k = min(top_k * 3, 20)

    # Build ChromaDB where clause for category filter
    where = None
    if category_filter:
        where = {"category": category_filter.lower()}

    try:
        results = collection.query(
            query_texts=[query],
            n_results=fetch_k,
            include=["documents", "metadatas", "distances"],
            where=where,
        )
    except Exception as e:
        print(f"ChromaDB query error: {e}")
        return []

    output = []

    docs      = results.get("documents", [[]])[0]
    metadatas = results.get("metadatas", [[]])[0]
    distances = results.get("distances", [[]])[0]

    for i, (doc, meta, dist) in enumerate(zip(docs, metadatas, distances)):

        # Semantic relevance: flip ChromaDB distance
        semantic_relevance = round(1 - (dist / 2), 4)
        semantic_relevance = max(0.0, min(1.0, semantic_relevance))

        # Keyword relevance against document text
        kw_relevance = keyword_score(doc, query)

        # Hybrid score
        final_score = round(
            (sem_weight * semantic_relevance) + (kw_weight * kw_relevance), 4
        )

        output.append({
            "content":            doc,
            "source":             meta.get("file_path", ""),
            "file_name":          meta.get("file_name", ""),
            "category":           meta.get("category", ""),
            "domain":             meta.get("category", "").upper(),
            "generation":         meta.get("category", "").upper(),
            "content_type":       meta.get("file_type", "").replace(".", ""),
            "chunk_id":           meta.get("chunk_id", i),
            "score":              final_score,
            "semantic_score":     semantic_relevance,
            "keyword_score":      kw_relevance,
        })

    # Sort by hybrid score descending
    output.sort(key=lambda x: x["score"], reverse=True)

    return output[:top_k]


# ═════════════════════════════════════════════════════════════════════
# REQUEST MODELS
# ═════════════════════════════════════════════════════════════════════

class SearchRequest(BaseModel):
    query:             str
    top_k:             int            = 5
    domain_filter:     Optional[str]  = None
    generation_filter: Optional[str]  = None
    brand_filter:      Optional[str]  = None
    source_filter:     Optional[str]  = None
    semantic_weight:   float          = 0.7
    keyword_weight:    float          = 0.3


# ═════════════════════════════════════════════════════════════════════
# ENDPOINTS
# ═════════════════════════════════════════════════════════════════════

@app.get("/health")
def health():
    """Health check — UI and Completions service ping this."""
    return {"status": "ok", "service": "search"}


@app.post("/search")
async def search_endpoint(body: SearchRequest):
    """
    Hybrid search endpoint.
    Called by: UI service search page, Completions service (for RAG context)
    """
    if not body.query or not body.query.strip():
        raise HTTPException(status_code=422, detail="query cannot be empty")

    # Check cache first
    filters = {
        "domain":     body.domain_filter,
        "generation": body.generation_filter,
        "top_k":      body.top_k,
    }
    cached = search_cache.get(body.query, filters)
    if cached:
        cached["cache_hit"] = True
        return cached

    # Determine category filter
    category_filter = body.domain_filter or body.generation_filter
    if category_filter:
        category_filter = category_filter.lower()

    results = hybrid_search(
        query           = body.query,
        top_k           = body.top_k,
        sem_weight      = body.semantic_weight,
        kw_weight       = body.keyword_weight,
        category_filter = category_filter,
    )

    response = {
        "query":     body.query,
        "results":   results,
        "total":     len(results),
        "cache_hit": False,
    }

    # Store in cache
    search_cache.set(body.query, filters, response)

    return response


@app.post("/search/validate")
async def validate_endpoint(body: SearchRequest):
    """
    Search and return only high-confidence results.
    Threshold: score > 0.65
    """
    if not body.query or not body.query.strip():
        raise HTTPException(status_code=422, detail="query cannot be empty")

    all_results   = hybrid_search(body.query, top_k=10)
    valid_results = [r for r in all_results if r["score"] > 0.65]

    return {
        "query":         body.query,
        "valid_results": valid_results,
        "total_results": len(all_results),
        "valid_count":   len(valid_results),
    }


@app.post("/ingest")
async def ingest_endpoint(
    file:        UploadFile    = File(...),
    brand:       str           = Form(...),
    model:       str           = Form(...),
    generation:  str           = Form(...),
    source:      str           = Form(...),
    domain:      str           = Form(...),
    launch_year: Optional[str] = Form(None),
    price_range: Optional[str] = Form(None),
):
    """
    Accept file upload, save to Data/, generate metadata, index into ChromaDB.
    Called by: UI service documents page.
    """
    try:
        file_path = os.path.join("Data", file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        generate_metadata("Data")
        chunks_indexed = index_data("file_mapping.json", "Data")

        # Clear cache since new data was added
        search_cache.clear()

        return {
            "success":        True,
            "filename":       file.filename,
            "chunks_indexed": chunks_indexed,
            "brand":          brand,
            "model":          model,
            "generation":     generation,
            "domain":         domain,
            "source":         source,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/index")
async def index_endpoint():
    """Re-index everything in Data/ folder."""
    try:
        result = index_data("file_mapping.json", "Data")
        search_cache.clear()
        return {"status": "indexed", "documents_indexed": result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/generate-metadata")
async def metadata_endpoint():
    """Generate metadata for all files in Data/ folder."""
    try:
        result = generate_metadata("Data")
        return {
            "status":    "success",
            "processed": result["processed"],
            "skipped":   result["skipped"],
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/documents")
async def list_documents(
    search: Optional[str] = None,
    domain: Optional[str] = None,
    type:   Optional[str] = None,
):
    """List all indexed documents from ChromaDB."""
    try:
        all_items = collection.get(include=["metadatas"])
        metadatas = all_items.get("metadatas", [])

        seen = set()
        docs = []

        for meta in metadatas:
            fp = meta.get("file_path", "")
            if fp in seen:
                continue
            seen.add(fp)

            category  = meta.get("category", "")
            file_type = meta.get("file_type", "").replace(".", "")

            if domain and category.lower() != domain.lower():
                continue
            if type and file_type.lower() != type.lower():
                continue
            if search and search.lower() not in meta.get("file_name", "").lower():
                continue

            docs.append({
                "id":           fp,
                "model":        meta.get("file_name", "").replace("_", " "),
                "generation":   category.upper(),
                "domain":       category.upper(),
                "source":       fp,
                "content_type": file_type,
                "uploaded_at":  None,
            })

        return {"documents": docs, "total": len(docs)}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/documents/{doc_id:path}")
async def delete_document(doc_id: str):
    """Delete document chunks from ChromaDB and file from disk."""
    try:
        results        = collection.get(where={"file_path": doc_id}, include=["metadatas"])
        ids_to_delete  = results.get("ids", [])

        if ids_to_delete:
            collection.delete(ids=ids_to_delete)

        if os.path.exists(doc_id):
            os.remove(doc_id)

        search_cache.clear()
        return {"success": True, "id": doc_id, "chunks_deleted": len(ids_to_delete)}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/cache/stats")
def cache_stats():
    return search_cache.stats()

@app.post("/cache/clear")
def cache_clear():
    search_cache.clear()
    return {"status": "cache cleared"}

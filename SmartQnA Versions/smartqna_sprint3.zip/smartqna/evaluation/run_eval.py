"""
SmartQnA — Evaluation Pipeline
LLM-as-a-Judge approach

Flow:
  Load eval dataset → send each query to chat API → LLM judges response → report scores

Run:
  python run_eval.py
  python run_eval.py --dataset eval_dataset.json --output results/
  python run_eval.py --category 5G   (filter by category)
"""

import os
import json
import time
import argparse
import httpx
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

# ── Config ─────────────────────────────────────────────────────────────
CHAT_API_URL = os.getenv("CHAT_API_URL",  "http://localhost:8000/api/chat")
LLM_BASE_URL = os.getenv("LLM_BASE_URL",  "https://api.mistral.ai/v1")
LLM_API_KEY  = os.getenv("LLM_API_KEY",   "your_mistral_api_key_here")
LLM_MODEL    = os.getenv("LLM_MODEL",     "mistral-small-latest")


# ═════════════════════════════════════════════════════════════════════
# STEP 1 — Get system response for a query
# ═════════════════════════════════════════════════════════════════════

def get_system_response(query: str) -> dict:
    """Send query to SmartQnA chat API and get response."""
    try:
        response = httpx.post(
            CHAT_API_URL,
            json={"query": query},
            headers={"Authorization": "Bearer stub_jwt_token"},
            timeout=30.0,
        )
        if response.status_code == 200:
            return response.json()
        else:
            return {
                "answer":    "",
                "sources":   [],
                "confidence": 0.0,
                "error":     f"API returned {response.status_code}"
            }
    except Exception as e:
        return {
            "answer":    "",
            "sources":   [],
            "confidence": 0.0,
            "error":     str(e)
        }


# ═════════════════════════════════════════════════════════════════════
# STEP 2 — LLM Judge evaluates the response
# ═════════════════════════════════════════════════════════════════════

JUDGE_SYSTEM_PROMPT = """You are an objective evaluator assessing the quality of AI-generated answers about smartphones.

You will be given:
- A user question
- The expected (ground truth) answer
- The system's actual answer

Score the system's answer on THREE dimensions, each from 0.0 to 1.0:

1. RELEVANCE (0.0 - 1.0)
   How relevant is the answer to the question asked?
   1.0 = perfectly on-topic
   0.5 = partially relevant
   0.0 = completely off-topic or refused to answer

2. CORRECTNESS (0.0 - 1.0)
   How factually accurate is the answer compared to the ground truth?
   1.0 = completely correct, matches ground truth
   0.5 = partially correct, some facts right some wrong
   0.0 = incorrect or contradicts ground truth

3. GROUNDING (0.0 - 1.0)
   Is the answer grounded in actual document sources (not hallucinated)?
   1.0 = clearly references specific documents/sources
   0.5 = answer seems factual but no source mentioned
   0.0 = appears hallucinated or no grounding at all

Respond ONLY with a valid JSON object in this exact format:
{
  "relevance": 0.0,
  "correctness": 0.0,
  "grounding": 0.0,
  "reasoning": "brief explanation of scores"
}

Do not include anything outside the JSON object."""


def judge_response(query: str, ground_truth: str, system_answer: str) -> dict:
    """
    Ask the LLM to judge the quality of the system's answer.
    Returns scores for relevance, correctness and grounding.
    """
    if not system_answer or system_answer.strip() == "":
        return {
            "relevance":   0.0,
            "correctness": 0.0,
            "grounding":   0.0,
            "reasoning":   "System returned empty answer",
            "judge_error": False,
        }

    judge_prompt = f"""Question: {query}

Expected answer: {ground_truth}

System's answer: {system_answer}

Evaluate the system's answer and return scores as JSON."""

    try:
        response = httpx.post(
            f"{LLM_BASE_URL}/chat/completions",
            headers={
                "Authorization": f"Bearer {LLM_API_KEY}",
                "Content-Type":  "application/json",
            },
            json={
                "model":       LLM_MODEL,
                "messages": [
                    {"role": "system", "content": JUDGE_SYSTEM_PROMPT},
                    {"role": "user",   "content": judge_prompt},
                ],
                "temperature": 0.0,   # deterministic judging
                "max_tokens":  200,
            },
            timeout=30.0,
        )

        if response.status_code != 200:
            return {
                "relevance":   0.0,
                "correctness": 0.0,
                "grounding":   0.0,
                "reasoning":   f"Judge API error: {response.status_code}",
                "judge_error": True,
            }

        content = response.json()["choices"][0]["message"]["content"].strip()

        # Strip markdown code fences if present
        content = content.replace("```json", "").replace("```", "").strip()

        scores = json.loads(content)

        return {
            "relevance":   float(scores.get("relevance",   0.0)),
            "correctness": float(scores.get("correctness", 0.0)),
            "grounding":   float(scores.get("grounding",   0.0)),
            "reasoning":   scores.get("reasoning", ""),
            "judge_error": False,
        }

    except json.JSONDecodeError:
        return {
            "relevance":   0.0,
            "correctness": 0.0,
            "grounding":   0.0,
            "reasoning":   f"Could not parse judge response: {content}",
            "judge_error": True,
        }
    except Exception as e:
        return {
            "relevance":   0.0,
            "correctness": 0.0,
            "grounding":   0.0,
            "reasoning":   f"Judge error: {str(e)}",
            "judge_error": True,
        }


# ═════════════════════════════════════════════════════════════════════
# STEP 3 — Run full evaluation
# ═════════════════════════════════════════════════════════════════════

def run_evaluation(
    dataset_path: str = "eval_dataset.json",
    output_dir:   str = "results",
    category:     str = None,
    delay:        float = 1.0,   # seconds between requests (avoid rate limiting)
) -> dict:
    """
    Run evaluation on all questions in the dataset.
    For each question:
      1. Get system response from chat API
      2. Ask LLM judge to score the response
      3. Aggregate scores

    Returns a full report with per-question and aggregate scores.
    """

    os.makedirs(output_dir, exist_ok=True)

    # Load dataset
    with open(dataset_path, "r", encoding="utf-8") as f:
        dataset = json.load(f)

    # Filter by category if specified
    if category:
        dataset = [d for d in dataset if d.get("category", "").upper() == category.upper()]
        print(f"Filtered to {len(dataset)} questions in category: {category}")

    print(f"\n{'='*60}")
    print(f"SmartQnA Evaluation Pipeline")
    print(f"Dataset: {dataset_path} | Questions: {len(dataset)}")
    print(f"{'='*60}\n")

    results     = []
    total_rel   = 0.0
    total_cor   = 0.0
    total_grd   = 0.0
    errors      = 0

    for i, item in enumerate(dataset, 1):
        q_id         = item.get("id", f"q_{i}")
        query        = item["query"]
        ground_truth = item["ground_truth"]
        difficulty   = item.get("difficulty", "unknown")

        print(f"[{i}/{len(dataset)}] {q_id} ({difficulty})")
        print(f"  Q: {query[:80]}...")

        # Get system response
        t_start          = time.time()
        system_response  = get_system_response(query)
        t_elapsed        = round(time.time() - t_start, 2)

        system_answer    = system_response.get("answer", "")
        system_sources   = system_response.get("sources", [])
        system_confidence= system_response.get("confidence", 0.0)
        api_error        = system_response.get("error")

        if api_error:
            print(f"  ⚠ API error: {api_error}")
            errors += 1

        # Judge the response
        scores = judge_response(query, ground_truth, system_answer)

        rel = scores["relevance"]
        cor = scores["correctness"]
        grd = scores["grounding"]

        total_rel += rel
        total_cor += cor
        total_grd += grd

        print(f"  A: {system_answer[:80]}...")
        print(f"  Scores → Relevance: {rel:.2f} | Correctness: {cor:.2f} | Grounding: {grd:.2f}")
        print(f"  Reasoning: {scores['reasoning'][:100]}")
        print(f"  Response time: {t_elapsed}s\n")

        results.append({
            "id":                 q_id,
            "query":              query,
            "ground_truth":       ground_truth,
            "system_answer":      system_answer,
            "system_sources":     system_sources,
            "system_confidence":  system_confidence,
            "category":           item.get("category"),
            "difficulty":         difficulty,
            "scores": {
                "relevance":   rel,
                "correctness": cor,
                "grounding":   grd,
                "average":     round((rel + cor + grd) / 3, 3),
            },
            "judge_reasoning":   scores["reasoning"],
            "judge_error":       scores["judge_error"],
            "api_error":         api_error,
            "response_time_s":   t_elapsed,
        })

        # Avoid rate limiting
        if i < len(dataset):
            time.sleep(delay)

    # ── Aggregate scores ──────────────────────────────────────────────
    n = len(dataset)

    avg_relevance   = round(total_rel / n, 3) if n > 0 else 0.0
    avg_correctness = round(total_cor / n, 3) if n > 0 else 0.0
    avg_grounding   = round(total_grd / n, 3) if n > 0 else 0.0
    avg_overall     = round((avg_relevance + avg_correctness + avg_grounding) / 3, 3)

    # Scores by difficulty
    by_difficulty = {}
    for diff in ["easy", "medium", "hard"]:
        subset = [r for r in results if r["difficulty"] == diff]
        if subset:
            by_difficulty[diff] = {
                "count":       len(subset),
                "relevance":   round(sum(r["scores"]["relevance"]   for r in subset) / len(subset), 3),
                "correctness": round(sum(r["scores"]["correctness"] for r in subset) / len(subset), 3),
                "grounding":   round(sum(r["scores"]["grounding"]   for r in subset) / len(subset), 3),
            }

    # Scores by category
    by_category = {}
    for cat in set(r["category"] for r in results if r["category"]):
        subset = [r for r in results if r["category"] == cat]
        by_category[cat] = {
            "count":       len(subset),
            "relevance":   round(sum(r["scores"]["relevance"]   for r in subset) / len(subset), 3),
            "correctness": round(sum(r["scores"]["correctness"] for r in subset) / len(subset), 3),
            "grounding":   round(sum(r["scores"]["grounding"]   for r in subset) / len(subset), 3),
        }

    report = {
        "run_timestamp":    datetime.now().isoformat(),
        "dataset":          dataset_path,
        "total_questions":  n,
        "errors":           errors,
        "aggregate_scores": {
            "relevance":   avg_relevance,
            "correctness": avg_correctness,
            "grounding":   avg_grounding,
            "overall":     avg_overall,
        },
        "by_difficulty":    by_difficulty,
        "by_category":      by_category,
        "results":          results,
    }

    # ── Save report ───────────────────────────────────────────────────
    timestamp   = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_path = os.path.join(output_dir, f"eval_report_{timestamp}.json")

    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)

    # ── Print summary ─────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"EVALUATION SUMMARY")
    print(f"{'='*60}")
    print(f"Total questions:  {n}")
    print(f"API errors:       {errors}")
    print(f"\nAggregate Scores:")
    print(f"  Relevance:      {avg_relevance:.3f} / 1.000")
    print(f"  Correctness:    {avg_correctness:.3f} / 1.000")
    print(f"  Grounding:      {avg_grounding:.3f} / 1.000")
    print(f"  Overall:        {avg_overall:.3f} / 1.000")

    if by_difficulty:
        print(f"\nBy Difficulty:")
        for diff, scores in by_difficulty.items():
            print(f"  {diff.capitalize():<8} ({scores['count']} Qs) → "
                  f"Rel: {scores['relevance']:.2f} | "
                  f"Cor: {scores['correctness']:.2f} | "
                  f"Grd: {scores['grounding']:.2f}")

    if by_category:
        print(f"\nBy Category:")
        for cat, scores in by_category.items():
            print(f"  {cat:<8} ({scores['count']} Qs) → "
                  f"Rel: {scores['relevance']:.2f} | "
                  f"Cor: {scores['correctness']:.2f} | "
                  f"Grd: {scores['grounding']:.2f}")

    print(f"\nReport saved: {report_path}")
    print(f"{'='*60}\n")

    return report


# ═════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SmartQnA Evaluation Pipeline")
    parser.add_argument("--dataset",  default="eval_dataset.json", help="Path to evaluation dataset")
    parser.add_argument("--output",   default="results",           help="Output directory for reports")
    parser.add_argument("--category", default=None,                help="Filter by category (e.g. 5G, 4G)")
    parser.add_argument("--delay",    default=1.0, type=float,     help="Delay between requests in seconds")
    args = parser.parse_args()

    run_evaluation(
        dataset_path = args.dataset,
        output_dir   = args.output,
        category     = args.category,
        delay        = args.delay,
    )

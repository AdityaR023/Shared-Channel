// ── auth.js — include this on every protected page ────────────────────
//
// Usage: add this FIRST before any page-specific script
//   <script src="/static/js/auth.js"></script>
//   <script src="/static/js/chat.js"></script>

// ── Get stored token ──────────────────────────────────────────────────
function getToken() {
  return localStorage.getItem("token");
}

// ── Get current user ──────────────────────────────────────────────────
function getUser() {
  const raw = localStorage.getItem("user");
  return raw ? JSON.parse(raw) : null;
}

// ── Get user's domains ────────────────────────────────────────────────
function getUserDomains() {
  const raw = localStorage.getItem("domains");
  return raw ? JSON.parse(raw) : [];
}

// ── Redirect to login if not authenticated ────────────────────────────
function requireAuth() {
  if (!getToken()) {
    window.location.href = "/login";
    return false;
  }
  return true;
}

// ── Logout ────────────────────────────────────────────────────────────
function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  localStorage.removeItem("domains");
  localStorage.removeItem("api_key");
  window.location.href = "/login";
}

// ── Authenticated fetch wrapper ───────────────────────────────────────
// Use this instead of raw fetch() on all protected pages
// It automatically adds the Authorization header and handles 401 errors
async function authFetch(url, options = {}) {
  const token = getToken();

  // Merge in the Authorization header
  const headers = {
    ...options.headers,
    "Authorization": `Bearer ${token}`,
  };

  const response = await fetch(url, { ...options, headers });

  // If token expired or invalid, kick user back to login
  if (response.status === 401) {
    logout();
    return null;
  }

  return response;
}

// ── Populate domain filter dropdowns ─────────────────────────────────
// Call this on any page that has domain filter dropdowns
// selector = CSS selector for the <select> element
function populateDomainFilter(selector, includeAll = true) {
  const select  = document.querySelector(selector);
  if (!select) return;

  const domains = getUserDomains();

  // Clear existing options first
  select.innerHTML = "";

  if (includeAll) {
    const allOpt   = document.createElement("option");
    allOpt.value   = "";
    allOpt.textContent = "All domains";
    select.appendChild(allOpt);
  }

  domains.forEach(domain => {
    const opt   = document.createElement("option");
    opt.value   = domain;
    opt.textContent = domain;
    select.appendChild(opt);
  });
}

// ── Show user info in navbar ──────────────────────────────────────────
// Call this on pages that have a navbar with a user display area
function populateNavbarUser() {
  const userDisplay = document.getElementById("navbarUser");
  if (!userDisplay) return;

  const user = getUser();
  if (user) {
    userDisplay.textContent = user.username || user.email;
  }
}

// ── Auth guard ────────────────────────────────────────────────────────
requireAuth();
populateNavbarUser();

// ── Element references ────────────────────────────────────────────────
const chatWindow    = document.getElementById("chatWindow");
const chatInput     = document.getElementById("chatInput");
const sendBtn       = document.getElementById("sendBtn");
const chatStatus    = document.getElementById("chatStatus");
const imageInput    = document.getElementById("imageInput");
const imagePreviewBar = document.getElementById("imagePreviewBar");
const imagePreview  = document.getElementById("imagePreview");
const imageFileName = document.getElementById("imageFileName");

// ── Populate domain filter from user's assigned domains ───────────────
populateDomainFilter("#domainFilter", true);

// Show domain hint in input area
const domains = getUserDomains();
const domainHint = document.getElementById("domainHint");
if (domains.length > 0) {
  domainHint.textContent = `Searching: ${domains.join(", ")} domains`;
}

// ── Conversation history ──────────────────────────────────────────────
// We keep a local copy of messages so we can display chat history
// and send conversation context to the API if needed
let conversationHistory = [];

// ── Auto-resize textarea as user types ───────────────────────────────
chatInput.addEventListener("input", () => {
  // Reset height first, then set to scrollHeight
  // This makes the textarea grow with content but never shrink below 1 row
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
});

// ── Send on Enter, new line on Shift+Enter ────────────────────────────
chatInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault(); // prevent new line
    sendMessage();
  }
});

sendBtn.addEventListener("click", sendMessage);

// ── Suggestion chips ──────────────────────────────────────────────────
// When a suggestion chip is clicked, fill the input and focus it
function fillQuestion(chipEl) {
  chatInput.value = chipEl.textContent.trim();
  chatInput.focus();
  // Trigger resize in case it needs to grow
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
}

// ── Image attachment ──────────────────────────────────────────────────
let attachedImageFile = null; // stores the File object

imageInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;

  attachedImageFile = file;

  // Show preview bar
  // FileReader reads the file as a data URL so we can display it as an <img>
  const reader = new FileReader();
  reader.onload = (ev) => {
    imagePreview.src     = ev.target.result;
    imageFileName.textContent = file.name;
    imagePreviewBar.style.display = "flex";
  };
  reader.readAsDataURL(file);
});

function removeImage() {
  attachedImageFile        = null;
  imageInput.value         = "";
  imagePreviewBar.style.display = "none";
  imagePreview.src         = "";
}

// ── Core: send a message ──────────────────────────────────────────────
async function sendMessage() {
  const query = chatInput.value.trim();

  // Need at least a text query OR an image
  if (!query && !attachedImageFile) return;

  // 1. Clear input immediately (good UX — feels responsive)
  const sentText  = query;
  const sentImage = attachedImageFile;
  chatInput.value = "";
  chatInput.style.height = "auto";
  removeImage();

  // 2. Show user's message in the chat window
  appendUserMessage(sentText, sentImage);

  // 3. Disable send while waiting (prevent double-send)
  setSendDisabled(true);
  setStatus("thinking");

  // 4. Show typing indicator while waiting for response
  const typingEl = appendTypingIndicator();

  // 5. Read current filter values
  const domain = document.getElementById("domainFilter").value || null;
  const brand  = document.getElementById("brandFilter").value  || null;
  const source = document.getElementById("sourceFilter").value || null;

  try {
    let response;

    if (sentImage) {
      // ── Multimodal request: send as FormData with image ────────────
      // Can't use JSON when sending a file — must use FormData
      const formData = new FormData();
      formData.append("query",  sentText || "Describe this image");
      formData.append("image",  sentImage);
      if (domain) formData.append("domain",        domain);
      if (brand)  formData.append("brand_filter",  brand);
      if (source) formData.append("source_filter", source);

      response = await authFetch("/api/chat", {
        method: "POST",
        body: formData,
        // Don't set Content-Type — browser handles multipart boundary
      });

    } else {
      // ── Text-only request: send as JSON ───────────────────────────
      response = await authFetch("/api/chat", {
        method:  "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query:         sentText,
          domain:        domain,
          brand_filter:  brand,
          source_filter: source,
        }),
      });
    }

    // Remove typing indicator before showing real response
    typingEl.remove();

    if (!response) return; // authFetch redirected to login (401)

    const data = await response.json();

    if (response.ok) {

      if (data.guardrail_triggered) {
        // ── Guardrail fired: question not smartphone-related ─────────
        appendGuardrailMessage();
      } else {
        // ── Normal answer ────────────────────────────────────────────
        appendBotMessage(
          data.answer,
          data.sources    || [],
          data.confidence || 0
        );

        // Add to local history
        conversationHistory.push(
          { role: "user",      content: sentText },
          { role: "assistant", content: data.answer }
        );
      }

      setStatus("ready");

    } else {
      appendErrorMessage(data.detail || "Something went wrong. Please try again.");
      setStatus("error");
    }

  } catch (err) {
    typingEl.remove();
    // Expected in Sprint 1 when backend isn't fully wired
    appendBotMessage(
      "⚠️ Could not reach the server. (Sprint 1: backend stubs active — real LLM not connected yet)",
      [],
      0
    );
    setStatus("ready");
  } finally {
    setSendDisabled(false);
    chatInput.focus();
  }
}

// ── Message rendering functions ───────────────────────────────────────

// Render user's outgoing message
function appendUserMessage(text, imageFile) {
  const div = document.createElement("div");
  div.className = "message user-message";

  // Build image HTML if an image was attached
  let imageHTML = "";
  if (imageFile) {
    // Use the already-loaded preview URL
    imageHTML = `<img src="${imagePreview.src}" class="msg-image" alt="Attached"/>`;
  }

  div.innerHTML = `
    <div class="msg-avatar">You</div>
    <div class="msg-body">
      ${imageHTML}
      ${text ? `<div class="msg-bubble">${escapeHTML(text)}</div>` : ""}
    </div>
  `;

  chatWindow.appendChild(div);
  scrollToBottom();
}

// Render bot's response with confidence score + sources
function appendBotMessage(answer, sources, confidence) {
  const div = document.createElement("div");
  div.className = "message bot-message";

  // Build confidence bar
  // confidence is a float 0.0 – 1.0 from the API
  const pct        = Math.round((confidence || 0) * 100);
  const confClass  = pct >= 70 ? "" : pct >= 40 ? "medium" : "low";
  const confLabel  = pct >= 70 ? "High" : pct >= 40 ? "Medium" : "Low";

  const confidenceHTML = confidence > 0 ? `
    <div class="confidence-bar">
      <span>Confidence:</span>
      <div class="confidence-track">
        <div class="confidence-fill ${confClass}" style="width:${pct}%"></div>
      </div>
      <span>${confLabel} (${pct}%)</span>
    </div>
  ` : "";

  // Build sources tags — each source becomes a clickable chip
  const sourcesHTML = sources.length > 0 ? `
    <div class="msg-sources">
      📚 Sources:
      ${sources.map(s => `
        <a href="${s.url || '#'}" target="_blank" class="source-tag" title="${s.document || s}">
          ${s.document || s}
        </a>
      `).join("")}
    </div>
  ` : "";

  // Convert newlines to <br> for display
  // Also handle simple markdown-style **bold** and `code`
  const formattedAnswer = formatAnswer(answer);

  div.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-body">
      <div class="msg-bubble">${formattedAnswer}</div>
      ${confidenceHTML}
      ${sourcesHTML}
    </div>
  `;

  chatWindow.appendChild(div);
  scrollToBottom();
}

// Render guardrail warning
function appendGuardrailMessage() {
  const div = document.createElement("div");
  div.className = "message bot-message guardrail-msg";
  div.innerHTML = `
    <div class="msg-avatar">🛡️</div>
    <div class="msg-body">
      <div class="msg-bubble">
        ⚠️ <strong>Out of scope.</strong>
        SmartQnA only answers smartphone-related questions.
        Try asking about phone specs, features, comparisons, or pricing.
      </div>
    </div>
  `;
  chatWindow.appendChild(div);
  scrollToBottom();
}

// Render error message
function appendErrorMessage(text) {
  const div = document.createElement("div");
  div.className = "message bot-message";
  div.innerHTML = `
    <div class="msg-avatar">⚠️</div>
    <div class="msg-body">
      <div class="msg-bubble" style="background:#fdecea; border-color:#f5c6c6; color:#b71c1c;">
        ${escapeHTML(text)}
      </div>
    </div>
  `;
  chatWindow.appendChild(div);
  scrollToBottom();
}

// Render animated typing indicator while waiting for response
function appendTypingIndicator() {
  const div = document.createElement("div");
  div.className = "message bot-message";
  div.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-body">
      <div class="msg-bubble">
        <div class="typing-indicator">
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
        </div>
      </div>
    </div>
  `;
  chatWindow.appendChild(div);
  scrollToBottom();
  return div; // caller removes this when real response arrives
}

// ── Clear chat ────────────────────────────────────────────────────────
function clearChat() {
  // Remove all messages except the welcome message
  const allMessages = chatWindow.querySelectorAll(".message:not(#welcomeMsg)");
  allMessages.forEach(m => m.remove());
  conversationHistory = [];
  setStatus("ready");
}

// ── Clear filters ────────────────────────────────────────────────────
function clearFilters() {
  document.getElementById("domainFilter").value = "";
  document.getElementById("brandFilter").value  = "";
  document.getElementById("sourceFilter").value = "";
}

// ── Utility functions ─────────────────────────────────────────────────

// Auto-scroll chat window to the latest message
function scrollToBottom() {
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

// Disable/enable the send button
function setSendDisabled(disabled) {
  sendBtn.disabled = disabled;
}

// Update the status indicator in the header
function setStatus(status) {
  const labels = {
    ready:    { text: "● Ready",    cls: "" },
    thinking: { text: "● Thinking...", cls: "thinking" },
    error:    { text: "● Error",    cls: "error" },
  };
  const s = labels[status] || labels.ready;
  chatStatus.textContent = s.text;
  chatStatus.className   = "chat-status " + s.cls;
}

// Escape HTML to prevent XSS — never render user input as raw HTML
function escapeHTML(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// Basic formatting for bot answers
// Converts newlines → <br>, **text** → <strong>, `code` → <code>
function formatAnswer(text) {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/`(.*?)`/g, "<code style='background:#f0f4f8;padding:1px 5px;border-radius:4px;font-size:13px'>$1</code>")
    .replace(/\n/g, "<br>");
}

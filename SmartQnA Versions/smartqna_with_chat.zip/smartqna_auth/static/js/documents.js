// ── Auth guard — redirect if not logged in ────────────────────────────
requireAuth();
populateNavbarUser();

// ── Element references ────────────────────────────────────────────────
const showUploadBtn  = document.getElementById("showUploadBtn");
const uploadPanel    = document.getElementById("uploadPanel");
const closeUploadBtn = document.getElementById("closeUploadBtn");
const closeUploadBtn2= document.getElementById("closeUploadBtn2");
const uploadForm     = document.getElementById("uploadForm");
const uploadBtn      = document.getElementById("uploadBtn");
const uploadError    = document.getElementById("uploadError");
const uploadSuccess  = document.getElementById("uploadSuccess");
const dropzone       = document.getElementById("dropzone");
const fileInput      = document.getElementById("fileInput");
const fileSelected   = document.getElementById("fileSelected");
const selectedFileName = document.getElementById("selectedFileName");
const docList        = document.getElementById("docList");
const emptyState     = document.getElementById("emptyState");
const loadingState   = document.getElementById("loadingState");

// ── Populate domain dropdowns from user's assigned domains ────────────
// This is why we built auth.js — one call fills all dropdowns correctly
populateDomainFilter("#docDomain",   false); // upload form — no "All" option
populateDomainFilter("#domainFilter", true); // filter bar  — include "All"

// ── Upload panel show / hide ───────────────────────────────────────────
showUploadBtn.addEventListener("click", () => {
  uploadPanel.style.display = "block";
  uploadPanel.scrollIntoView({ behavior: "smooth" });
});

[closeUploadBtn, closeUploadBtn2].forEach(btn => {
  btn.addEventListener("click", () => {
    uploadPanel.style.display = "none";
    resetUploadForm();
  });
});

// ── Content mode toggle (file vs text) ───────────────────────────────
let contentMode = "file"; // tracks which mode is active

function switchContentMode(mode) {
  contentMode = mode;

  document.getElementById("fileMode").style.display = mode === "file" ? "block" : "none";
  document.getElementById("textMode").style.display = mode === "text" ? "block" : "none";

  document.getElementById("toggleFile").classList.toggle("active", mode === "file");
  document.getElementById("toggleText").classList.toggle("active", mode === "text");
}

// ── Dropzone logic ────────────────────────────────────────────────────
dropzone.addEventListener("click", () => fileInput.click());

dropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropzone.classList.add("active");
});
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("active"));
dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("active");
  if (e.dataTransfer.files.length) selectFile(e.dataTransfer.files[0]);
});

fileInput.addEventListener("change", (e) => {
  if (e.target.files.length) selectFile(e.target.files[0]);
});

function selectFile(file) {
  // Show selected file pill, hide drop zone prompt
  selectedFileName.textContent = `📄 ${file.name} (${(file.size/1024).toFixed(1)} KB)`;
  fileSelected.style.display   = "flex";
  document.getElementById("dropText").textContent = "File selected";
  document.getElementById("fileErr").classList.remove("visible");
}

function removeFile() {
  fileInput.value          = "";
  fileSelected.style.display = "none";
  document.getElementById("dropText").innerHTML =
    'Drag &amp; drop or <span class="browse-link">browse</span>';
}

// ── Upload form submit ────────────────────────────────────────────────
uploadForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearUploadErrors();

  // Validate metadata fields
  const brand      = document.getElementById("docBrand").value.trim();
  const model      = document.getElementById("docModel").value.trim();
  const generation = document.getElementById("docGeneration").value;
  const source     = document.getElementById("docSource").value.trim();
  const domain     = document.getElementById("docDomain").value;
  const year       = document.getElementById("docYear").value;
  const priceRange = document.getElementById("docPrice").value;

  let valid = true;

  if (!brand)      { showErr("brandErr");  valid = false; }
  if (!model)      { showErr("modelErr");  valid = false; }
  if (!generation) { showErr("genErr");    valid = false; }
  if (!source)     { showErr("sourceErr"); valid = false; }
  if (!domain)     { showErr("domainErr"); valid = false; }

  // Validate content
  if (contentMode === "file" && !fileInput.files.length) {
    showErr("fileErr"); valid = false;
  }
  if (contentMode === "text" && !document.getElementById("docText").value.trim()) {
    showErr("textErr"); valid = false;
  }

  if (!valid) return;

  // Build FormData — works for both file and text modes
  // FormData lets us send both metadata (text fields) and files in one request
  const formData = new FormData();
  formData.append("brand",       brand);
  formData.append("model",       model);
  formData.append("generation",  generation);
  formData.append("source",      source);
  formData.append("domain",      domain);
  if (year)       formData.append("launch_year",  year);
  if (priceRange) formData.append("price_range",  priceRange);

  if (contentMode === "file") {
    formData.append("file", fileInput.files[0]);
    formData.append("content_type", fileInput.files[0].name.split(".").pop());
  } else {
    // For text input, create a Blob (fake file) and attach it
    const textContent = document.getElementById("docText").value.trim();
    const blob = new Blob([textContent], { type: "text/plain" });
    formData.append("file", blob, `${brand}_${model}_direct.txt`);
    formData.append("content_type", "text");
  }

  setUploadLoading(true);

  try {
    // authFetch from auth.js — automatically adds JWT Authorization header
    const response = await authFetch("/api/ingest", {
      method: "POST",
      body: formData,
      // Don't set Content-Type header — browser sets multipart boundary automatically
    });

    if (!response) return; // authFetch redirected to login (401)

    const data = await response.json();

    if (response.ok) {
      showUploadSuccess(`✅ Uploaded successfully! ${data.chunks_indexed ?? 0} chunks indexed.`);
      resetUploadForm();
      uploadPanel.style.display = "none";
      // Refresh the document list to show the new document
      loadDocuments();
    } else {
      showUploadError(data.detail || "Upload failed. Please try again.");
    }

  } catch (err) {
    showUploadError("Could not reach server. Please try again.");
  } finally {
    setUploadLoading(false);
  }
});

// ── Load documents list ───────────────────────────────────────────────
async function loadDocuments() {
  showLoadingState(true);
  docList.innerHTML = "";

  // Build query params from current filter values
  const search  = document.getElementById("searchFilter").value.trim();
  const domain  = document.getElementById("domainFilter").value;
  const type    = document.getElementById("typeFilter").value;

  const params = new URLSearchParams();
  if (search) params.append("search", search);
  if (domain) params.append("domain", domain);
  if (type)   params.append("type", type);

  try {
    const response = await authFetch(`/api/documents?${params}`);
    if (!response) return;

    const data = await response.json();
    showLoadingState(false);

    if (!data.documents || data.documents.length === 0) {
      emptyState.style.display = "block";
      return;
    }

    emptyState.style.display = "none";

    // Render each document as a card
    data.documents.forEach(doc => renderDocCard(doc));

  } catch (err) {
    showLoadingState(false);
    docList.innerHTML = `<div class="alert error visible" style="margin-bottom:12px">
      Could not load documents. Is the server running?
    </div>`;
  }
}

// ── Render a single document card ────────────────────────────────────
function renderDocCard(doc) {
  const card = document.createElement("div");
  card.className = "doc-card";
  card.dataset.id = doc.id;

  // Format upload date nicely
  const uploadDate = doc.uploaded_at
    ? new Date(doc.uploaded_at).toLocaleDateString("en-IN", {
        day: "numeric", month: "short", year: "numeric"
      })
    : "Unknown date";

  card.innerHTML = `
    <div class="doc-info">
      <div class="doc-title">${doc.brand} ${doc.model}</div>
      <div class="doc-meta">
        <span class="doc-badge badge-domain">${doc.domain}</span>
        <span class="doc-badge badge-gen">${doc.generation}</span>
        <span class="doc-badge badge-type">${doc.content_type?.toUpperCase()}</span>
      </div>
      <div class="doc-source">Source: ${doc.source}</div>
      <div class="doc-date">Uploaded: ${uploadDate}</div>
    </div>
    <div class="doc-actions">
      <button class="btn-icon" onclick="openEditModal('${doc.id}')">✏️ Edit</button>
      <button class="btn-icon delete" onclick="openDeleteModal('${doc.id}', '${doc.brand} ${doc.model}')">
        🗑️ Delete
      </button>
    </div>
  `;

  docList.appendChild(card);
}

// ── EDIT modal ────────────────────────────────────────────────────────
async function openEditModal(docId) {
  // Fetch the document's current data to pre-fill the form
  try {
    const response = await authFetch(`/api/documents/${docId}`);
    if (!response) return;

    const doc = await response.json();

    document.getElementById("editDocId").value    = doc.id;
    document.getElementById("editBrand").value    = doc.brand;
    document.getElementById("editModel").value    = doc.model;
    document.getElementById("editGeneration").value = doc.generation;
    document.getElementById("editSource").value   = doc.source;

    document.getElementById("editModal").style.display = "flex";

  } catch (err) {
    alert("Could not load document details.");
  }
}

function closeEditModal() {
  document.getElementById("editModal").style.display = "none";
  document.getElementById("editError").classList.remove("visible");
}

document.getElementById("editForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const docId = document.getElementById("editDocId").value;
  const body  = {
    brand:      document.getElementById("editBrand").value.trim(),
    model:      document.getElementById("editModel").value.trim(),
    generation: document.getElementById("editGeneration").value,
    source:     document.getElementById("editSource").value.trim(),
  };

  const editBtn = document.getElementById("editBtn");
  editBtn.disabled  = true;
  editBtn.innerHTML = '<span class="spinner"></span> Saving...';

  try {
    // PATCH — partial update (only send fields being changed)
    const response = await authFetch(`/api/documents/${docId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (response && response.ok) {
      closeEditModal();
      loadDocuments(); // refresh the list
    } else {
      const data = await response.json();
      const errEl = document.getElementById("editError");
      errEl.textContent = data.detail || "Update failed.";
      errEl.classList.add("visible");
    }
  } catch (err) {
    const errEl = document.getElementById("editError");
    errEl.textContent = "Could not reach server.";
    errEl.classList.add("visible");
  } finally {
    editBtn.disabled  = false;
    editBtn.innerHTML = "Save Changes";
  }
});

// ── DELETE modal ──────────────────────────────────────────────────────
let pendingDeleteId = null; // store which doc is being deleted

function openDeleteModal(docId, docName) {
  pendingDeleteId = docId;
  document.getElementById("deleteDocName").textContent = docName;
  document.getElementById("deleteModal").style.display = "flex";
}

function closeDeleteModal() {
  pendingDeleteId = null;
  document.getElementById("deleteModal").style.display = "none";
}

document.getElementById("confirmDeleteBtn").addEventListener("click", async () => {
  if (!pendingDeleteId) return;

  const btn = document.getElementById("confirmDeleteBtn");
  btn.disabled = true;
  btn.textContent = "Deleting...";

  try {
    const response = await authFetch(`/api/documents/${pendingDeleteId}`, {
      method: "DELETE",
    });

    if (response && response.ok) {
      closeDeleteModal();
      loadDocuments(); // refresh list
    } else {
      alert("Could not delete document. Please try again.");
    }
  } catch (err) {
    alert("Could not reach server.");
  } finally {
    btn.disabled = false;
    btn.textContent = "Delete";
  }
});

// Close modals when clicking backdrop
document.getElementById("editModal").addEventListener("click", (e) => {
  if (e.target === document.getElementById("editModal")) closeEditModal();
});
document.getElementById("deleteModal").addEventListener("click", (e) => {
  if (e.target === document.getElementById("deleteModal")) closeDeleteModal();
});

// ── Helpers ───────────────────────────────────────────────────────────
function showErr(id) {
  document.getElementById(id).classList.add("visible");
}

function clearUploadErrors() {
  document.querySelectorAll(".error-msg").forEach(el => el.classList.remove("visible"));
  [uploadError, uploadSuccess].forEach(el => {
    el.classList.remove("visible");
    el.textContent = "";
  });
}

function showUploadError(msg) {
  uploadError.textContent = msg;
  uploadError.classList.add("visible");
  uploadPanel.scrollIntoView({ behavior: "smooth" });
}

function showUploadSuccess(msg) {
  uploadSuccess.textContent = msg;
  uploadSuccess.classList.add("visible");
}

function setUploadLoading(loading) {
  uploadBtn.disabled  = loading;
  uploadBtn.innerHTML = loading
    ? '<span class="spinner"></span> Uploading...'
    : "Upload & Index";
}

function resetUploadForm() {
  uploadForm.reset();
  removeFile();
  switchContentMode("file");
  clearUploadErrors();
}

function showLoadingState(loading) {
  loadingState.style.display = loading ? "block" : "none";
  emptyState.style.display   = "none";
}

// ── Filter: search input live filtering ──────────────────────────────
// Debounce — wait 400ms after user stops typing before hitting the API
let debounceTimer;
document.getElementById("searchFilter").addEventListener("input", () => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(loadDocuments, 400);
});

// ── Initial load ──────────────────────────────────────────────────────
loadDocuments();

// ── Element references ────────────────────────────────────────────────
const signupForm    = document.getElementById("signupForm");
const usernameInput = document.getElementById("username");
const emailInput    = document.getElementById("email");
const passInput     = document.getElementById("password");
const signupBtn     = document.getElementById("signupBtn");
const errorAlert    = document.getElementById("errorAlert");
const successAlert  = document.getElementById("successAlert");
const domainError   = document.getElementById("domainError");

// ── Domain chip toggle logic ──────────────────────────────────────────
// querySelectorAll returns ALL elements matching the selector — an array-like list
const chips = document.querySelectorAll(".domain-chip");

// selectedDomains tracks which domains the user has clicked
// Using a Set — automatically handles duplicates, easy to add/remove
const selectedDomains = new Set();

chips.forEach((chip) => {
  chip.addEventListener("click", () => {
    const domain = chip.dataset.domain; // reads data-domain="4G" from the HTML

    if (selectedDomains.has(domain)) {
      // Already selected — deselect it
      selectedDomains.delete(domain);
      chip.classList.remove("selected");
    } else {
      // Not selected — select it
      selectedDomains.add(domain);
      chip.classList.add("selected");
    }

    // Hide domain error if user now has at least one selected
    if (selectedDomains.size > 0) {
      domainError.style.display = "none";
    }
  });
});

// ── Form submit ───────────────────────────────────────────────────────
signupForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearErrors();

  // 1. Validate all fields
  const username = usernameInput.value.trim();
  const email    = emailInput.value.trim();
  const password = passInput.value.trim();
  let valid      = true;

  if (!username) {
    showFieldError(usernameInput, "usernameError");
    valid = false;
  }
  if (!email || !isValidEmail(email)) {
    showFieldError(emailInput, "emailError");
    valid = false;
  }
  if (!password || password.length < 8) {
    showFieldError(passInput, "passwordError");
    valid = false;
  }
  if (selectedDomains.size === 0) {
    domainError.style.display = "block";
    valid = false;
  }
  if (!valid) return;

  // 2. Loading state
  setLoading(true);

  try {
    // 3. Call signup API
    // We send JSON this time (not form data) because it's a richer payload
    const response = await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: username,
        email: email,
        password: password,
        domains: Array.from(selectedDomains), // Set → Array for JSON serialisation
      }),
    });

    const data = await response.json();

    if (response.ok) {
      // 4. Store credentials
      localStorage.setItem("token",   data.access_token);
      localStorage.setItem("user",    JSON.stringify(data.user));
      localStorage.setItem("domains", JSON.stringify(data.user.domains));
      localStorage.setItem("api_key", data.api_key);     // store for profile page

      // 5. Redirect to the credentials reveal page
      // We pass the api key and secret via URL query params
      // (they're only shown once — right after signup)
      const params = new URLSearchParams({
        key:    data.api_key,
        secret: data.api_secret,
      });
      window.location.href = `/signup/success?${params}`;

    } else {
      showAlert("error", data.detail || "Could not create account. Email may already be registered.");
    }

  } catch (err) {
    showAlert("error", "Could not reach the server. Please try again.");
  } finally {
    setLoading(false);
  }
});

// ── Helpers ───────────────────────────────────────────────────────────

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showFieldError(input, errorId) {
  input.classList.add("error");
  document.getElementById(errorId).classList.add("visible");
}

function clearErrors() {
  [usernameInput, emailInput, passInput].forEach(el => el.classList.remove("error"));
  document.querySelectorAll(".error-msg").forEach(el => el.classList.remove("visible"));
  domainError.style.display = "none";
  [errorAlert, successAlert].forEach(el => {
    el.classList.remove("visible");
    el.textContent = "";
  });
}

function showAlert(type, message) {
  const el = type === "error" ? errorAlert : successAlert;
  el.textContent = message;
  el.classList.add("visible");
}

function setLoading(loading) {
  signupBtn.disabled  = loading;
  signupBtn.innerHTML = loading
    ? '<span class="spinner"></span> Creating account...'
    : "Create Account";
}

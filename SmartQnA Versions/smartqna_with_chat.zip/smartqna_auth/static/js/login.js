// ── Element references ────────────────────────────────────────────────
const loginForm   = document.getElementById("loginForm");
const emailInput  = document.getElementById("email");
const passInput   = document.getElementById("password");
const loginBtn    = document.getElementById("loginBtn");
const errorAlert  = document.getElementById("errorAlert");
const emailError  = document.getElementById("emailError");
const passError   = document.getElementById("passwordError");

// ── If already logged in, skip to dashboard ───────────────────────────
// localStorage is the browser's key-value store — persists across page loads
// We store the JWT here after login
if (localStorage.getItem("token")) {
  window.location.href = "/chat";
}

// ── Form submit ───────────────────────────────────────────────────────
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault(); // stop the form from doing a full page reload

  // Clear previous errors
  clearErrors();

  // 1. Validate inputs before making any API call
  const email    = emailInput.value.trim();
  const password = passInput.value.trim();
  let valid      = true;

  if (!email || !isValidEmail(email)) {
    showFieldError(emailInput, emailError);
    valid = false;
  }
  if (!password) {
    showFieldError(passInput, passError);
    valid = false;
  }
  if (!valid) return;

  // 2. Show loading state on button
  setLoading(true);

  try {
    // 3. Call the login API
    // FastAPI expects form data for OAuth2 token endpoint (standard pattern)
    // We use URLSearchParams — this sends as application/x-www-form-urlencoded
    const formData = new URLSearchParams();
    formData.append("username", email);   // OAuth2 standard calls it "username"
    formData.append("password", password);

    const response = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: formData,
    });

    const data = await response.json();

    if (response.ok) {
      // 4. Store JWT and user info in localStorage
      // JWT is a token the server gives us that proves we're logged in
      // We send it with every future API request
      localStorage.setItem("token",   data.access_token);
      localStorage.setItem("user",    JSON.stringify(data.user));    // { id, email, username, domains }
      localStorage.setItem("domains", JSON.stringify(data.user.domains)); // ["4G", "5G"]

      // 5. Redirect to main app
      window.location.href = "/chat";

    } else {
      // Server returned an error (wrong password, user not found etc.)
      showAlert(data.detail || "Invalid email or password. Please try again.");
    }

  } catch (err) {
    // Network error — server not running
    showAlert("Could not reach the server. Please try again.");
  } finally {
    setLoading(false);
  }
});

// ── Helper functions ──────────────────────────────────────────────────

function isValidEmail(email) {
  // Basic email format check using regex
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function showFieldError(input, errorEl) {
  input.classList.add("error");
  errorEl.classList.add("visible");
}

function clearErrors() {
  [emailInput, passInput].forEach(el => el.classList.remove("error"));
  [emailError, passError].forEach(el => el.classList.remove("visible"));
  errorAlert.classList.remove("visible");
  errorAlert.textContent = "";
}

function showAlert(message) {
  errorAlert.textContent = message;
  errorAlert.classList.add("visible");
}

function setLoading(loading) {
  loginBtn.disabled   = loading;
  loginBtn.innerHTML  = loading
    ? '<span class="spinner"></span> Signing in...'
    : "Sign In";
}

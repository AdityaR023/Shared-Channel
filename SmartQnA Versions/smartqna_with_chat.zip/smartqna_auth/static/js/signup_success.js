// Read the API key and secret from URL query parameters
// e.g. /signup/success?key=smq_key_abc&secret=smq_secret_xyz
const params = new URLSearchParams(window.location.search);
const apiKey    = params.get("key")    || "Not available";
const apiSecret = params.get("secret") || "Not available";

// Display them
document.getElementById("apiKeyValue").textContent    = apiKey;
document.getElementById("apiSecretValue").textContent = apiSecret;

// Display domains from localStorage (set during signup)
const domains = JSON.parse(localStorage.getItem("domains") || "[]");
const grid    = document.getElementById("domainsDisplay");

if (domains.length === 0) {
  grid.innerHTML = '<span style="font-size:13px;color:#888">No domains assigned</span>';
} else {
  domains.forEach(domain => {
    const chip = document.createElement("div");
    chip.className = "domain-chip selected";
    chip.style.cursor = "default";
    chip.innerHTML = `
      <span class="chip-gen">${domain}</span>
      <span class="chip-check">✓</span>
    `;
    grid.appendChild(chip);
  });
}

// Copy to clipboard helper
function copyToClipboard(elementId, btn) {
  const text = document.getElementById(elementId).textContent;
  navigator.clipboard.writeText(text).then(() => {
    btn.textContent = "Copied!";
    btn.style.color = "#2e7d32";
    btn.style.borderColor = "#2e7d32";
    setTimeout(() => {
      btn.textContent = "Copy";
      btn.style.color = "";
      btn.style.borderColor = "";
    }, 2000);
  });
}

// After 5 minutes, clear the secret from the URL (security hygiene)
// This prevents the secret from sitting in browser history
setTimeout(() => {
  window.history.replaceState({}, "", "/signup/success");
}, 5 * 60 * 1000);

"""
SmartQnA — Database Layer
SQLite for development (swap to PostgreSQL for production by changing DATABASE_URL)

Tables:
  users          → registered users with domains and API credentials
  conversations  → chat sessions per user
  messages       → individual messages within a conversation
"""

import os
import sqlite3
import hashlib
import secrets
import uuid
from datetime import datetime
from typing import Optional, List
from contextlib import contextmanager

DATABASE_PATH = os.getenv("DATABASE_PATH", "./smartqna.db")


# ═════════════════════════════════════════════════════════════════════
# CONNECTION MANAGEMENT
# ═════════════════════════════════════════════════════════════════════

@contextmanager
def get_db():
    """Context manager for database connections."""
    conn = sqlite3.connect(DATABASE_PATH)
    conn.row_factory = sqlite3.Row   # rows behave like dicts
    conn.execute("PRAGMA journal_mode=WAL")   # better concurrent access
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ═════════════════════════════════════════════════════════════════════
# SCHEMA — create all tables if they don't exist
# ═════════════════════════════════════════════════════════════════════

def init_db():
    """Create all tables. Safe to call multiple times."""
    with get_db() as conn:
        conn.executescript("""
            -- Users table
            CREATE TABLE IF NOT EXISTS users (
                id           TEXT PRIMARY KEY,
                username     TEXT UNIQUE NOT NULL,
                email        TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                domains      TEXT NOT NULL DEFAULT '[]',
                api_key      TEXT UNIQUE,
                api_secret_hash TEXT,
                created_at   TEXT NOT NULL,
                last_login   TEXT
            );

            -- Conversations table
            -- Each row = one chat session for a user
            CREATE TABLE IF NOT EXISTS conversations (
                id           TEXT PRIMARY KEY,
                user_id      TEXT NOT NULL,
                title        TEXT NOT NULL DEFAULT 'New Conversation',
                created_at   TEXT NOT NULL,
                updated_at   TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            );

            -- Messages table
            -- Each row = one message (user or assistant) in a conversation
            CREATE TABLE IF NOT EXISTS messages (
                id              TEXT PRIMARY KEY,
                conversation_id TEXT NOT NULL,
                role            TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
                content         TEXT NOT NULL,
                sources         TEXT DEFAULT '[]',
                confidence      REAL DEFAULT 0.0,
                guardrail       INTEGER DEFAULT 0,
                created_at      TEXT NOT NULL,
                FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
            );

            -- Indexes for fast lookups
            CREATE INDEX IF NOT EXISTS idx_conversations_user
                ON conversations(user_id, updated_at DESC);

            CREATE INDEX IF NOT EXISTS idx_messages_conv
                ON messages(conversation_id, created_at ASC);
        """)
    print("Database initialised.")


# ═════════════════════════════════════════════════════════════════════
# USER OPERATIONS
# ═════════════════════════════════════════════════════════════════════

def hash_password(password: str) -> str:
    """Hash password with SHA-256 + salt."""
    salt = secrets.token_hex(16)
    hashed = hashlib.sha256(f"{salt}{password}".encode()).hexdigest()
    return f"{salt}:{hashed}"

def verify_password(password: str, stored_hash: str) -> bool:
    """Verify password against stored hash."""
    try:
        salt, hashed = stored_hash.split(":")
        check = hashlib.sha256(f"{salt}{password}".encode()).hexdigest()
        return check == hashed
    except Exception:
        return False

def generate_api_credentials() -> dict:
    """Generate API key + secret pair."""
    api_key    = f"smq_key_{secrets.token_hex(16)}"
    api_secret = f"smq_secret_{secrets.token_hex(24)}"
    secret_hash= hashlib.sha256(api_secret.encode()).hexdigest()
    return {"api_key": api_key, "api_secret": api_secret, "secret_hash": secret_hash}


def create_user(username: str, email: str, password: str, domains: list) -> dict:
    """Create a new user. Returns user dict with api_key and api_secret (shown once)."""
    import json

    user_id   = str(uuid.uuid4())
    pw_hash   = hash_password(password)
    creds     = generate_api_credentials()
    now       = datetime.utcnow().isoformat()

    with get_db() as conn:
        # Check if email or username already exists
        existing = conn.execute(
            "SELECT id FROM users WHERE email=? OR username=?",
            (email, username)
        ).fetchone()
        if existing:
            raise ValueError("Email or username already registered")

        conn.execute("""
            INSERT INTO users
              (id, username, email, password_hash, domains, api_key, api_secret_hash, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            user_id, username, email, pw_hash,
            json.dumps(domains),
            creds["api_key"],
            creds["secret_hash"],
            now
        ))

    return {
        "id":         user_id,
        "username":   username,
        "email":      email,
        "domains":    domains,
        "api_key":    creds["api_key"],
        "api_secret": creds["api_secret"],   # raw secret — shown once only
        "created_at": now,
    }


def get_user_by_email(email: str) -> Optional[dict]:
    """Fetch user by email."""
    import json
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM users WHERE email=?", (email,)
        ).fetchone()
        if not row:
            return None
        user = dict(row)
        user["domains"] = json.loads(user["domains"])
        return user


def update_last_login(user_id: str):
    """Update last_login timestamp."""
    with get_db() as conn:
        conn.execute(
            "UPDATE users SET last_login=? WHERE id=?",
            (datetime.utcnow().isoformat(), user_id)
        )


# ═════════════════════════════════════════════════════════════════════
# CONVERSATION OPERATIONS
# ═════════════════════════════════════════════════════════════════════

def create_conversation(user_id: str, title: str = "New Conversation") -> dict:
    """Create a new conversation for a user."""
    conv_id = str(uuid.uuid4())
    now     = datetime.utcnow().isoformat()

    with get_db() as conn:
        conn.execute("""
            INSERT INTO conversations (id, user_id, title, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?)
        """, (conv_id, user_id, title, now, now))

    return {"id": conv_id, "user_id": user_id, "title": title,
            "created_at": now, "updated_at": now, "messages": []}


def get_conversations(user_id: str, limit: int = 20) -> list:
    """Get all conversations for a user, newest first."""
    with get_db() as conn:
        rows = conn.execute("""
            SELECT c.id, c.title, c.created_at, c.updated_at,
                   COUNT(m.id) as message_count,
                   MAX(m.content) as last_message
            FROM conversations c
            LEFT JOIN messages m ON m.conversation_id = c.id
            WHERE c.user_id = ?
            GROUP BY c.id
            ORDER BY c.updated_at DESC
            LIMIT ?
        """, (user_id, limit)).fetchall()
        return [dict(r) for r in rows]


def get_conversation_with_messages(conv_id: str, user_id: str) -> Optional[dict]:
    """Get a conversation with all its messages."""
    import json
    with get_db() as conn:
        conv = conn.execute(
            "SELECT * FROM conversations WHERE id=? AND user_id=?",
            (conv_id, user_id)
        ).fetchone()

        if not conv:
            return None

        msgs = conn.execute("""
            SELECT * FROM messages
            WHERE conversation_id=?
            ORDER BY created_at ASC
        """, (conv_id,)).fetchall()

        result        = dict(conv)
        result["messages"] = []
        for m in msgs:
            msg            = dict(m)
            msg["sources"] = json.loads(msg.get("sources", "[]"))
            result["messages"].append(msg)

        return result


def update_conversation_title(conv_id: str, title: str):
    """Update conversation title (auto-generated from first message)."""
    with get_db() as conn:
        conn.execute(
            "UPDATE conversations SET title=?, updated_at=? WHERE id=?",
            (title[:80], datetime.utcnow().isoformat(), conv_id)
        )


def delete_conversation(conv_id: str, user_id: str):
    """Delete a conversation and all its messages."""
    with get_db() as conn:
        conn.execute(
            "DELETE FROM conversations WHERE id=? AND user_id=?",
            (conv_id, user_id)
        )


# ═════════════════════════════════════════════════════════════════════
# MESSAGE OPERATIONS
# ═════════════════════════════════════════════════════════════════════

def save_message(
    conv_id:    str,
    role:       str,
    content:    str,
    sources:    list  = None,
    confidence: float = 0.0,
    guardrail:  bool  = False,
) -> dict:
    """Save a single message to a conversation."""
    import json

    msg_id = str(uuid.uuid4())
    now    = datetime.utcnow().isoformat()

    with get_db() as conn:
        conn.execute("""
            INSERT INTO messages
              (id, conversation_id, role, content, sources, confidence, guardrail, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            msg_id, conv_id, role, content,
            json.dumps(sources or []),
            confidence,
            1 if guardrail else 0,
            now
        ))

        # Update conversation's updated_at timestamp
        conn.execute(
            "UPDATE conversations SET updated_at=? WHERE id=?",
            (now, conv_id)
        )

    return {
        "id":              msg_id,
        "conversation_id": conv_id,
        "role":            role,
        "content":         content,
        "sources":         sources or [],
        "confidence":      confidence,
        "guardrail":       guardrail,
        "created_at":      now,
    }


def get_recent_messages(conv_id: str, limit: int = 10) -> list:
    """
    Get the most recent N messages from a conversation.
    Used to build multi-turn context for LLM — we don't send
    the full history (could be huge), just the last N turns.
    """
    import json
    with get_db() as conn:
        rows = conn.execute("""
            SELECT * FROM messages
            WHERE conversation_id=?
            ORDER BY created_at DESC
            LIMIT ?
        """, (conv_id, limit)).fetchall()

        msgs = [dict(r) for r in reversed(rows)]  # reverse back to chronological
        for m in msgs:
            m["sources"] = json.loads(m.get("sources", "[]"))
        return msgs

// ── Auth guard ────────────────────────────────────────────────────────
requireAuth();
populateNavbarUser();

// ── Element references ────────────────────────────────────────────────
const chatWindow     = document.getElementById("chatWindow");
const chatInput      = document.getElementById("chatInput");
const sendBtn        = document.getElementById("sendBtn");
const chatStatus     = document.getElementById("chatStatus");
const imageInput     = document.getElementById("imageInput");
const imagePreviewBar= document.getElementById("imagePreviewBar");
const imagePreview   = document.getElementById("imagePreview");
const imageFileName  = document.getElementById("imageFileName");
const convList       = document.getElementById("convList");
const newChatBtn     = document.getElementById("newChatBtn");

// ── State ─────────────────────────────────────────────────────────────
let currentConvId    = null;   // active conversation ID
let isStreaming      = false;  // prevents double-send during stream
let attachedImage    = null;   // attached image File object

// ── Populate domain filter ────────────────────────────────────────────
populateDomainFilter("#domainFilter", true);

const domains    = getUserDomains();
const domainHint = document.getElementById("domainHint");
if (domains.length > 0) {
  domainHint.textContent = `Domains: ${domains.join(", ")}`;
}

// ── Auto-resize textarea ──────────────────────────────────────────────
chatInput.addEventListener("input", () => {
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
});

// ── Keyboard shortcuts ────────────────────────────────────────────────
chatInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

sendBtn.addEventListener("click", sendMessage);

// ── New chat button ───────────────────────────────────────────────────
newChatBtn.addEventListener("click", () => {
  startNewConversation();
});

// ── Image attachment ──────────────────────────────────────────────────
imageInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  attachedImage = file;

  const reader = new FileReader();
  reader.onload = (ev) => {
    imagePreview.src              = ev.target.result;
    imageFileName.textContent     = file.name;
    imagePreviewBar.style.display = "flex";
  };
  reader.readAsDataURL(file);
});

function removeImage() {
  attachedImage                 = null;
  imageInput.value              = "";
  imagePreviewBar.style.display = "none";
  imagePreview.src              = "";
}

// ═════════════════════════════════════════════════════════════════════
// CONVERSATION HISTORY — load and display past conversations
// ═════════════════════════════════════════════════════════════════════

async function loadConversationList() {
  try {
    const response = await authFetch("/api/conversations");
    if (!response) return;

    const data  = await response.json();
    const convs = data.conversations || [];

    renderConversationList(convs);
  } catch (err) {
    console.error("Failed to load conversations:", err);
  }
}

function renderConversationList(convs) {
  convList.innerHTML = "";

  if (convs.length === 0) {
    convList.innerHTML = `
      <div class="conv-empty">No conversations yet. Start chatting!</div>
    `;
    return;
  }

  convs.forEach(conv => {
    const item = document.createElement("div");
    item.className = "conv-item" + (conv.id === currentConvId ? " active" : "");
    item.dataset.id = conv.id;

    // Format date
    const date = new Date(conv.updated_at);
    const dateStr = date.toLocaleDateString("en-IN", {
      day: "numeric", month: "short"
    });

    item.innerHTML = `
      <div class="conv-item-inner" onclick="loadConversation('${conv.id}')">
        <span class="conv-title">${escapeHTML(conv.title || "New Conversation")}</span>
        <span class="conv-date">${dateStr}</span>
      </div>
      <button class="conv-delete" title="Delete"
              onclick="deleteConversation('${conv.id}', event)">✕</button>
    `;

    convList.appendChild(item);
  });
}

async function loadConversation(convId) {
  try {
    const response = await authFetch(`/api/conversations/${convId}`);
    if (!response) return;

    const conv = await response.json();

    // Set as active conversation
    currentConvId = convId;

    // Clear chat window
    chatWindow.innerHTML = "";

    // Render all messages from history
    if (conv.messages && conv.messages.length > 0) {
      conv.messages.forEach(msg => {
        if (msg.role === "user") {
          appendUserMessage(msg.content, null);
        } else {
          appendBotMessage(msg.content, msg.sources || [], msg.confidence || 0);
        }
      });
    } else {
      showWelcomeMessage();
    }

    // Highlight active conversation in sidebar
    document.querySelectorAll(".conv-item").forEach(item => {
      item.classList.toggle("active", item.dataset.id === convId);
    });

    // Refresh list to update ordering
    loadConversationList();

  } catch (err) {
    console.error("Failed to load conversation:", err);
  }
}

async function deleteConversation(convId, event) {
  event.stopPropagation();  // don't trigger loadConversation

  if (!confirm("Delete this conversation?")) return;

  try {
    await authFetch(`/api/conversations/${convId}`, { method: "DELETE" });

    // If we deleted the active conversation, start fresh
    if (convId === currentConvId) {
      startNewConversation();
    }

    loadConversationList();
  } catch (err) {
    console.error("Failed to delete:", err);
  }
}

function startNewConversation() {
  currentConvId        = null;
  chatWindow.innerHTML = "";
  showWelcomeMessage();

  // Deselect all items in sidebar
  document.querySelectorAll(".conv-item").forEach(i => i.classList.remove("active"));
}

// ═════════════════════════════════════════════════════════════════════
// SEND MESSAGE — with streaming + multi-turn
// ═════════════════════════════════════════════════════════════════════

async function sendMessage() {
  if (isStreaming) return;

  const query = chatInput.value.trim();
  if (!query && !attachedImage) return;

  // Capture and clear input immediately
  const sentText  = query;
  const sentImage = attachedImage;
  chatInput.value = "";
  chatInput.style.height = "auto";
  removeImage();

  // Show user message
  appendUserMessage(sentText, sentImage);

  // Disable input during response
  isStreaming        = true;
  sendBtn.disabled   = true;
  setStatus("thinking");

  // Show typing indicator
  const typingEl = appendTypingIndicator();

  // Read filters
  const domain = document.getElementById("domainFilter").value || null;
  const brand  = document.getElementById("brandFilter").value  || null;

  try {
    // ── Streaming request ─────────────────────────────────────────────
    const response = await authFetch("/api/chat", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query:           sentText || "Describe this image",
        conversation_id: currentConvId,
        domain:          domain,
        brand_filter:    brand,
        stream:          true,    // ← request streaming
      }),
    });

    if (!response) return;  // 401 — redirected to login

    typingEl.remove();

    // ── Handle SSE stream ─────────────────────────────────────────────
    // Create a bot message bubble that we'll fill token by token
    const botMsgEl = createEmptyBotMessage();
    const bubbleEl = botMsgEl.querySelector(".msg-bubble-text");

    let sources    = [];
    let confidence = 0;
    let fullText   = "";

    const reader = response.body.getReader();
    const decoder= new TextDecoder();
    let   buffer  = "";

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      // SSE lines end with \n\n
      const lines = buffer.split("\n\n");
      buffer = lines.pop();  // keep incomplete chunk

      for (const line of lines) {
        if (!line.startsWith("data: ")) continue;

        const data = line.slice(6).trim();
        if (data === "[DONE]") break;

        try {
          const parsed = JSON.parse(data);

          if (parsed.type === "meta") {
            // Metadata chunk — sources + confidence
            sources    = parsed.sources    || [];
            confidence = parsed.confidence || 0;

          } else if (parsed.type === "conv_id") {
            // Server sends back the conversation ID
            currentConvId = parsed.conversation_id;
            loadConversationList();  // refresh sidebar

          } else if (parsed.token) {
            // Text token — append to bubble
            fullText += parsed.token;
            bubbleEl.innerHTML = formatAnswer(fullText);
            scrollToBottom();

          } else if (parsed.error) {
            bubbleEl.innerHTML = `<span style="color:#e24b4a">⚠️ ${parsed.error}</span>`;

          } else if (parsed.guardrail_triggered) {
            // Guardrail fired — show styled warning
            botMsgEl.classList.add("guardrail-msg");
            bubbleEl.innerHTML = `⚠️ <strong>Out of scope.</strong> ${parsed.answer || "SmartQnA only answers smartphone-related questions."}`;
          }

        } catch (e) {
          // Malformed JSON chunk — skip
        }
      }
    }

    // Append sources + confidence after stream ends
    if (sources.length > 0 || confidence > 0) {
      appendSourcesAndConfidence(botMsgEl, sources, confidence);
    }

    setStatus("ready");

  } catch (err) {
    typingEl.remove();
    appendBotMessage(
      "⚠️ Could not reach the server. Please check that all services are running.",
      [], 0
    );
    setStatus("error");
  } finally {
    isStreaming      = false;
    sendBtn.disabled = false;
    chatInput.focus();
  }
}

// ═════════════════════════════════════════════════════════════════════
// MESSAGE RENDERING
// ═════════════════════════════════════════════════════════════════════

function showWelcomeMessage() {
  const div = document.createElement("div");
  div.className = "message bot-message";
  div.id        = "welcomeMsg";
  div.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-body">
      <div class="msg-bubble">
        <p>Hi! I'm <strong>SmartQnA</strong>.</p>
        <p style="margin-top:8px">Ask me anything about smartphones.</p>
        <p style="margin-top:8px; font-size:13px; color:#888;">
          Your conversations are saved and accessible from the sidebar.
        </p>
      </div>
    </div>
  `;
  chatWindow.appendChild(div);
}

function appendUserMessage(text, imageFile) {
  const div = document.createElement("div");
  div.className = "message user-message";

  let imageHTML = "";
  if (imageFile) {
    imageHTML = `<img src="${imagePreview.src}" class="msg-image" alt="Attached"/>`;
  }

  div.innerHTML = `
    <div class="msg-avatar">You</div>
    <div class="msg-body">
      ${imageHTML}
      ${text ? `<div class="msg-bubble">${escapeHTML(text)}</div>` : ""}
    </div>
  `;

  chatWindow.appendChild(div);
  scrollToBottom();
}

function createEmptyBotMessage() {
  /**
   * Creates an empty bot message bubble.
   * Returns the element — caller fills .msg-bubble-text incrementally
   * as streaming tokens arrive.
   */
  const div = document.createElement("div");
  div.className = "message bot-message";
  div.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-body">
      <div class="msg-bubble">
        <span class="msg-bubble-text"></span>
      </div>
    </div>
  `;
  chatWindow.appendChild(div);
  scrollToBottom();
  return div;
}

function appendSourcesAndConfidence(msgEl, sources, confidence) {
  /**
   * Appends sources + confidence bar below an existing bot message.
   * Called after the stream ends when we have the full metadata.
   */
  const body = msgEl.querySelector(".msg-body");

  const pct       = Math.round((confidence || 0) * 100);
  const confClass = pct >= 70 ? "" : pct >= 40 ? "medium" : "low";
  const confLabel = pct >= 70 ? "High" : pct >= 40 ? "Medium" : "Low";

  const confHTML = confidence > 0 ? `
    <div class="confidence-bar">
      <span>Confidence:</span>
      <div class="confidence-track">
        <div class="confidence-fill ${confClass}" style="width:${pct}%"></div>
      </div>
      <span>${confLabel} (${pct}%)</span>
    </div>
  ` : "";

  const sourcesHTML = sources.length > 0 ? `
    <div class="msg-sources">
      📚 Sources:
      ${sources.map(s => `
        <a href="${s.url || "#"}" target="_blank" class="source-tag">
          ${s.document || s}
        </a>
      `).join("")}
    </div>
  ` : "";

  if (confHTML || sourcesHTML) {
    const meta = document.createElement("div");
    meta.innerHTML = confHTML + sourcesHTML;
    body.appendChild(meta);
    scrollToBottom();
  }
}

function appendBotMessage(answer, sources, confidence) {
  /**
   * Full bot message — used when loading history (non-streaming).
   */
  const div = document.createElement("div");
  div.className = "message bot-message";

  const pct       = Math.round((confidence || 0) * 100);
  const confClass = pct >= 70 ? "" : pct >= 40 ? "medium" : "low";
  const confLabel = pct >= 70 ? "High" : pct >= 40 ? "Medium" : "Low";

  const confHTML = confidence > 0 ? `
    <div class="confidence-bar">
      <span>Confidence:</span>
      <div class="confidence-track">
        <div class="confidence-fill ${confClass}" style="width:${pct}%"></div>
      </div>
      <span>${confLabel} (${pct}%)</span>
    </div>
  ` : "";

  const sourcesHTML = sources && sources.length > 0 ? `
    <div class="msg-sources">
      📚 Sources:
      ${sources.map(s => `
        <a href="${s.url || "#"}" target="_blank" class="source-tag">
          ${s.document || s}
        </a>
      `).join("")}
    </div>
  ` : "";

  div.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-body">
      <div class="msg-bubble">
        <span class="msg-bubble-text">${formatAnswer(answer)}</span>
      </div>
      ${confHTML}
      ${sourcesHTML}
    </div>
  `;

  chatWindow.appendChild(div);
  scrollToBottom();
  return div;
}

function appendTypingIndicator() {
  const div = document.createElement("div");
  div.className = "message bot-message";
  div.innerHTML = `
    <div class="msg-avatar">🤖</div>
    <div class="msg-body">
      <div class="msg-bubble">
        <div class="typing-indicator">
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
          <div class="typing-dot"></div>
        </div>
      </div>
    </div>
  `;
  chatWindow.appendChild(div);
  scrollToBottom();
  return div;
}

// ── Suggestion chips ──────────────────────────────────────────────────
function fillQuestion(chipEl) {
  chatInput.value = chipEl.textContent.trim();
  chatInput.focus();
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
}

// ── Clear filters ─────────────────────────────────────────────────────
function clearFilters() {
  document.getElementById("domainFilter").value = "";
  document.getElementById("brandFilter").value  = "";
  document.getElementById("sourceFilter").value = "";
}

// ── Utilities ─────────────────────────────────────────────────────────
function scrollToBottom() {
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

function setStatus(status) {
  const labels = {
    ready:    { text: "● Ready",      cls: "" },
    thinking: { text: "● Thinking...", cls: "thinking" },
    error:    { text: "● Error",      cls: "error" },
  };
  const s = labels[status] || labels.ready;
  chatStatus.textContent = s.text;
  chatStatus.className   = "chat-status " + s.cls;
}

function escapeHTML(str) {
  if (!str) return "";
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function formatAnswer(text) {
  if (!text) return "";
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/`(.*?)`/g, "<code style='background:#f0f4f8;padding:1px 5px;border-radius:4px;font-size:13px'>$1</code>")
    .replace(/\n/g, "<br>");
}

// ═════════════════════════════════════════════════════════════════════
// INIT — load conversation list on page load
// ═════════════════════════════════════════════════════════════════════
showWelcomeMessage();
loadConversationList();

"""
SmartQnA — UI Service
Port: 8000

New in this version:
  - Conversation history endpoints (cross-session)
  - Chat proxy supports streaming + multi-turn history
  - Auth now backed by real SQLite database
"""

import os
import json
import httpx
from typing import Optional, List
from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse, StreamingResponse
from pydantic import BaseModel
from dotenv import load_dotenv
from database import (
    init_db, create_user, get_user_by_email, verify_password, update_last_login,
    create_conversation, get_conversations, get_conversation_with_messages,
    delete_conversation, save_message, get_recent_messages,
    update_conversation_title,
)

load_dotenv()

# ── App setup ─────────────────────────────────────────────────────────
app = FastAPI(title="SmartQnA — UI Service", version="2.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

SEARCH_SERVICE_URL      = os.getenv("SEARCH_SERVICE_URL",      "http://localhost:8001")
COMPLETIONS_SERVICE_URL = os.getenv("COMPLETIONS_SERVICE_URL", "http://localhost:8002")

# ── Init DB on startup ────────────────────────────────────────────────
@app.on_event("startup")
def startup():
    init_db()


# ═════════════════════════════════════════════════════════════════════
# JWT HELPERS (stub — Group B replaces with real JWT)
# ═════════════════════════════════════════════════════════════════════

import secrets as sec
_sessions = {}   # token → user_id (in-memory, stub only)

def create_token(user_id: str) -> str:
    token = sec.token_hex(32)
    _sessions[token] = user_id
    return token

def get_user_id_from_token(request: Request) -> Optional[str]:
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        return None
    token = auth[7:]
    return _sessions.get(token)

def require_user(request: Request) -> str:
    user_id = get_user_id_from_token(request)
    if not user_id:
        raise HTTPException(status_code=401, detail="Not authenticated")
    return user_id


# ═════════════════════════════════════════════════════════════════════
# REQUEST MODELS
# ═════════════════════════════════════════════════════════════════════

class SignupRequest(BaseModel):
    username: str
    email:    str
    password: str
    domains:  List[str]

class LoginRequest(BaseModel):
    username: str   # email in our case
    password: str

class SearchRequest(BaseModel):
    query:             str
    top_k:             int           = 5
    domain_filter:     Optional[str] = None
    generation_filter: Optional[str] = None
    brand_filter:      Optional[str] = None
    source_filter:     Optional[str] = None

class ChatRequest(BaseModel):
    query:           str
    conversation_id: Optional[str]  = None   # None = new conversation
    domain:          Optional[str]  = None
    brand_filter:    Optional[str]  = None
    source_filter:   Optional[str]  = None
    stream:          bool           = False


# ═════════════════════════════════════════════════════════════════════
# PAGE ROUTES
# ═════════════════════════════════════════════════════════════════════

@app.get("/")
def root():
    return RedirectResponse(url="/login")

@app.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/signup")
def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})

@app.get("/signup/success")
def signup_success_page(request: Request):
    return templates.TemplateResponse("signup_success.html", {"request": request})

@app.get("/upload")
def upload_page(request: Request):
    return templates.TemplateResponse("documents.html", {"request": request})

@app.get("/chat")
def chat_page(request: Request):
    return templates.TemplateResponse("chat.html", {"request": request})

@app.get("/search")
def search_page(request: Request):
    return templates.TemplateResponse("search.html", {"request": request})

@app.get("/profile")
def profile_page(request: Request):
    return templates.TemplateResponse("profile.html", {"request": request})


# ═════════════════════════════════════════════════════════════════════
# HEALTH
# ═════════════════════════════════════════════════════════════════════

@app.get("/health")
async def health():
    status = {"ui": "ok", "search": "unknown", "completions": "unknown"}
    async with httpx.AsyncClient(timeout=3.0) as client:
        try:
            r = await client.get(f"{SEARCH_SERVICE_URL}/health")
            status["search"] = "ok" if r.status_code == 200 else "degraded"
        except Exception:
            status["search"] = "down"
        try:
            r = await client.get(f"{COMPLETIONS_SERVICE_URL}/health")
            status["completions"] = "ok" if r.status_code == 200 else "degraded"
        except Exception:
            status["completions"] = "down"
    return status


# ═════════════════════════════════════════════════════════════════════
# AUTH — backed by real SQLite database
# ═════════════════════════════════════════════════════════════════════

@app.get("/api/auth/me")
async def get_me(request: Request):
    user_id = require_user(request)
    return {"id": user_id}

@app.post("/api/auth/login")
async def login(request: Request):
    try:
        body = await request.json()
        email    = body.get("username", "")
        password = body.get("password", "")
    except Exception:
        # Handle form-encoded
        form = await request.form()
        email    = form.get("username", "")
        password = form.get("password", "")

    user = get_user_by_email(email)
    if not user or not verify_password(password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    update_last_login(user["id"])
    token = create_token(user["id"])

    return {
        "access_token": token,
        "token_type":   "bearer",
        "user": {
            "id":       user["id"],
            "email":    user["email"],
            "username": user["username"],
            "domains":  user["domains"],
        }
    }

@app.post("/api/auth/signup")
async def signup(body: SignupRequest):
    try:
        user = create_user(body.username, body.email, body.password, body.domains)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    token = create_token(user["id"])

    return {
        "access_token": token,
        "token_type":   "bearer",
        "api_key":      user["api_key"],
        "api_secret":   user["api_secret"],
        "user": {
            "id":       user["id"],
            "email":    user["email"],
            "username": user["username"],
            "domains":  user["domains"],
        }
    }

@app.post("/api/auth/logout")
async def logout(request: Request):
    auth  = request.headers.get("Authorization", "")
    token = auth[7:] if auth.startswith("Bearer ") else None
    if token and token in _sessions:
        del _sessions[token]
    return {"success": True}


# ═════════════════════════════════════════════════════════════════════
# CONVERSATION HISTORY — cross-session persistence
# ═════════════════════════════════════════════════════════════════════

@app.get("/api/conversations")
async def list_conversations(request: Request):
    """Get all conversations for the logged-in user."""
    user_id = require_user(request)
    convs   = get_conversations(user_id, limit=30)
    return {"conversations": convs}

@app.post("/api/conversations")
async def new_conversation(request: Request):
    """Create a new empty conversation."""
    user_id = require_user(request)
    conv    = create_conversation(user_id)
    return conv

@app.get("/api/conversations/{conv_id}")
async def get_conversation(conv_id: str, request: Request):
    """Get a specific conversation with all its messages."""
    user_id = require_user(request)
    conv    = get_conversation_with_messages(conv_id, user_id)
    if not conv:
        raise HTTPException(status_code=404, detail="Conversation not found")
    return conv

@app.delete("/api/conversations/{conv_id}")
async def remove_conversation(conv_id: str, request: Request):
    """Delete a conversation."""
    user_id = require_user(request)
    delete_conversation(conv_id, user_id)
    return {"success": True}


# ═════════════════════════════════════════════════════════════════════
# CHAT — multi-turn + streaming proxy to Completions Service
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/chat")
async def chat_proxy(body: ChatRequest, request: Request):
    """
    Chat endpoint with multi-turn and streaming support.

    Flow:
    1. Get or create conversation in DB
    2. Load recent message history from DB
    3. Save user message to DB
    4. Forward to Completions Service (with history + stream flag)
    5. If streaming: pipe SSE stream back to client + save final answer to DB
    6. If not streaming: save answer to DB + return JSON
    """
    user_id = require_user(request)

    # Step 1: get or create conversation
    if body.conversation_id:
        conv = get_conversation_with_messages(body.conversation_id, user_id)
        if not conv:
            raise HTTPException(status_code=404, detail="Conversation not found")
        conv_id = body.conversation_id
    else:
        conv    = create_conversation(user_id)
        conv_id = conv["id"]

        # Auto-title from first message (first 60 chars)
        title = body.query[:60] + ("..." if len(body.query) > 60 else "")
        update_conversation_title(conv_id, title)

    # Step 2: load recent history (last 10 messages = 5 turns)
    recent_msgs = get_recent_messages(conv_id, limit=10)
    history     = [{"role": m["role"], "content": m["content"]} for m in recent_msgs]

    # Step 3: save user message to DB
    save_message(conv_id, "user", body.query)

    # Step 4: build payload for Completions Service
    completions_payload = {
        "query":        body.query,
        "history":      history,
        "domain":       body.domain,
        "brand_filter": body.brand_filter,
        "stream":       body.stream,
    }

    # ── Streaming path ────────────────────────────────────────────────
    if body.stream:
        async def stream_and_save():
            """
            Pipe SSE tokens from Completions Service to client.
            Accumulate full answer and save to DB when stream ends.
            """
            full_answer = ""
            sources     = []
            confidence  = 0.0

            try:
                async with httpx.AsyncClient(timeout=60.0) as client:
                    async with client.stream(
                        "POST",
                        f"{COMPLETIONS_SERVICE_URL}/chat",
                        json=completions_payload,
                    ) as resp:

                        async for line in resp.aiter_lines():
                            if not line.startswith("data: "):
                                continue

                            data = line[6:].strip()

                            # Forward raw SSE line to client
                            yield f"data: {data}\n\n"

                            if data == "[DONE]":
                                break

                            try:
                                parsed = json.loads(data)

                                # Accumulate tokens
                                if parsed.get("type") != "meta":
                                    full_answer += parsed.get("token", "")
                                else:
                                    # Meta chunk — extract sources + confidence
                                    sources    = parsed.get("sources", [])
                                    confidence = parsed.get("confidence", 0.0)

                            except Exception:
                                pass

            except httpx.ConnectError:
                yield 'data: {"error": "Completions service unavailable"}\n\n'
                yield "data: [DONE]\n\n"
                return

            # Save complete assistant message to DB after stream ends
            if full_answer:
                save_message(
                    conv_id,
                    "assistant",
                    full_answer,
                    sources=sources,
                    confidence=confidence,
                )

            # Send conversation_id so UI can store it
            yield f"data: {json.dumps({'type': 'conv_id', 'conversation_id': conv_id})}\n\n"

        return StreamingResponse(
            stream_and_save(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    # ── Non-streaming path ────────────────────────────────────────────
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.post(
                f"{COMPLETIONS_SERVICE_URL}/chat",
                json=completions_payload,
            )
        data = resp.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Completions service unavailable")

    # Step 6: save assistant message to DB
    if not data.get("guardrail_triggered"):
        save_message(
            conv_id,
            "assistant",
            data.get("answer", ""),
            sources=data.get("sources", []),
            confidence=data.get("confidence", 0.0),
            guardrail=data.get("guardrail_triggered", False),
        )

    data["conversation_id"] = conv_id
    return data


# ═════════════════════════════════════════════════════════════════════
# SEARCH PROXY
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/search")
async def search_proxy(body: SearchRequest):
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                f"{SEARCH_SERVICE_URL}/search", json=body.model_dump()
            )
        return response.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Search service unavailable")


# ═════════════════════════════════════════════════════════════════════
# INGEST + DOCUMENT CRUD PROXIES
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/ingest")
async def ingest_proxy(
    file:        UploadFile    = File(...),
    brand:       str           = Form(...),
    model:       str           = Form(...),
    generation:  str           = Form(...),
    source:      str           = Form(...),
    domain:      str           = Form(...),
    launch_year: Optional[str] = Form(None),
    price_range: Optional[str] = Form(None),
):
    try:
        content = await file.read()
        async with httpx.AsyncClient(timeout=60.0) as client:
            response = await client.post(
                f"{SEARCH_SERVICE_URL}/ingest",
                files={"file": (file.filename, content, file.content_type)},
                data={"brand": brand, "model": model, "generation": generation,
                      "source": source, "domain": domain,
                      "launch_year": launch_year or "", "price_range": price_range or ""},
            )
        return response.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Search service unavailable")

@app.get("/api/documents")
async def list_docs(search: Optional[str] = Query(None),
                    domain: Optional[str] = Query(None),
                    type:   Optional[str] = Query(None)):
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.get(f"{SEARCH_SERVICE_URL}/documents",
                                 params={"search": search, "domain": domain, "type": type})
        return r.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Search service unavailable")

@app.delete("/api/documents/{doc_id:path}")
async def delete_doc(doc_id: str):
    try:
        async with httpx.AsyncClient(timeout=10.0) as client:
            r = await client.delete(f"{SEARCH_SERVICE_URL}/documents/{doc_id}")
        return r.json()
    except httpx.ConnectError:
        raise HTTPException(status_code=503, detail="Search service unavailable")

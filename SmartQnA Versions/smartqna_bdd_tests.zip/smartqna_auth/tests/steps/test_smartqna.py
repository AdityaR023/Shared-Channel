# ─────────────────────────────────────────────────────────────────────
# SmartQnA — BDD Step Definitions
# File: tests/steps/test_smartqna.py
#
# Install dependencies:
#   pip install pytest pytest-bdd requests
#
# Run all tests:
#   pytest tests/ -v
#
# Run only Sprint 1:
#   pytest tests/ -v -k "Ingestion or Search"
#
# Run only Sprint 2:
#   pytest tests/ -v -k "Chat"
# ─────────────────────────────────────────────────────────────────────

import pytest
import requests
from pytest_bdd import scenarios, given, when, then, parsers

# ── Load all scenarios from the feature file ──────────────────────────
scenarios("../features/smartqna.feature")

# ── Base config ───────────────────────────────────────────────────────
BASE_URL   = "http://localhost:8000"
TEST_TOKEN = "stub_jwt_token"   # replace with real token when Group B delivers auth

HEADERS_AUTH = {
    "Authorization": f"Bearer {TEST_TOKEN}",
    "Content-Type":  "application/json",
}
HEADERS_NO_AUTH = {
    "Content-Type": "application/json",
}


# ═════════════════════════════════════════════════════════════════════
# SHARED FIXTURES
# ═════════════════════════════════════════════════════════════════════

@pytest.fixture
def context():
    """Shared state between steps within a scenario."""
    return {}


# ═════════════════════════════════════════════════════════════════════
# SPRINT 1 — INGESTION STEP DEFINITIONS
# ═════════════════════════════════════════════════════════════════════

# ── Given steps ───────────────────────────────────────────────────────

@given("the ingestion API is running")
def ingestion_api_running():
    res = requests.get(f"{BASE_URL}/docs")
    assert res.status_code == 200, "FastAPI server is not running"

@given(parsers.parse('the user has a valid PDF file "{filename}"'))
def has_pdf_file(context, filename):
    context["filename"] = filename
    context["file_content"] = b"%PDF-1.4 sample content for testing"
    context["content_type"] = "application/pdf"

@given(parsers.parse('the user has a valid CSV file "{filename}" with {rows:d} rows'))
def has_csv_file(context, filename, rows):
    context["filename"] = filename
    header = "brand,model,generation,price\n"
    rows_data = "".join([f"Samsung,Model{i},4G,10000\n" for i in range(rows)])
    context["file_content"] = (header + rows_data).encode()
    context["content_type"] = "text/csv"

@given(parsers.parse('the user has a valid HTML file "{filename}"'))
def has_html_file(context, filename):
    context["filename"] = filename
    context["file_content"] = b"<html><body><p>Samsung S24 specs</p></body></html>"
    context["content_type"] = "text/html"

@given(parsers.parse('the user has a valid TXT file "{filename}"'))
def has_txt_file(context, filename):
    context["filename"] = filename
    context["file_content"] = b"This is a transcript of a phone review."
    context["content_type"] = "text/plain"

@given(parsers.parse('the user has a file "{filename}"'))
def has_any_file(context, filename):
    context["filename"] = filename
    context["file_content"] = b"dummy content"
    context["content_type"] = "application/octet-stream"

@given(parsers.parse('the request is missing the "{field}" field'))
def missing_field(context, field):
    context["missing_field"] = field

@given("no JWT token is provided in the request header")
def no_auth(context):
    context["no_auth"] = True

@given("an expired or invalid JWT token is provided")
def invalid_auth(context):
    context["invalid_token"] = "Bearer invalid.token.here"

# ── When steps (ingestion) ────────────────────────────────────────────

@when("the user uploads the file to POST /api/ingest")
def upload_file(context):
    filename     = context.get("filename", "test.pdf")
    file_content = context.get("file_content", b"test")
    no_auth      = context.get("no_auth", False)
    missing      = context.get("missing_field", None)

    headers = {} if no_auth else {"Authorization": f"Bearer {TEST_TOKEN}"}

    files = {"file": (filename, file_content)}
    data  = {}

    if not missing or missing != "brand":
        data["brand"] = "Samsung"
    data["model"]      = "S24"
    data["generation"] = "5G"
    data["source"]     = "gsmarena.com"
    data["domain"]     = "5G"

    context["response"] = requests.post(
        f"{BASE_URL}/api/ingest",
        files=files,
        data=data,
        headers=headers
    )

@when("the user sends a POST to /api/ingest with no file")
def upload_no_file(context):
    context["response"] = requests.post(
        f"{BASE_URL}/api/ingest",
        headers={"Authorization": f"Bearer {TEST_TOKEN}"}
    )

# ── Then steps (ingestion) ────────────────────────────────────────────

@then(parsers.parse("the response status should be {status:d}"))
def check_status(context, status):
    assert context["response"].status_code == status, (
        f"Expected {status}, got {context['response'].status_code}. "
        f"Body: {context['response'].text}"
    )

@then(parsers.parse('the response should contain field "{field}" as true'))
def check_field_true(context, field):
    data = context["response"].json()
    assert data.get(field) is True, f"Expected {field}=true, got {data.get(field)}"

@then(parsers.parse('the response should contain field "{field}" as "{value}"'))
def check_field_value(context, field, value):
    data = context["response"].json()
    assert str(data.get(field)) == value, (
        f"Expected {field}={value}, got {data.get(field)}"
    )

@then(parsers.parse('the field "{field}" should be greater than {value:d}'))
def check_field_greater(context, field, value):
    data = context["response"].json()
    assert data.get(field, 0) > value, (
        f"Expected {field} > {value}, got {data.get(field)}"
    )

@then("the document chunks should appear in OpenSearch")
def check_opensearch_indexed(context):
    # Query search API to confirm document was indexed
    res = requests.post(
        f"{BASE_URL}/api/search",
        json={"query": "Samsung S24", "top_k": 5},
        headers=HEADERS_AUTH
    )
    assert res.status_code == 200
    data = res.json()
    assert data.get("total", 0) >= 0  # at minimum endpoint responds

@then(parsers.parse('the response should contain "{text}"'))
def check_response_contains(context, text):
    assert text.lower() in context["response"].text.lower(), (
        f"Expected '{text}' in response: {context['response'].text}"
    )


# ═════════════════════════════════════════════════════════════════════
# SPRINT 1 — SEARCH STEP DEFINITIONS
# ═════════════════════════════════════════════════════════════════════

# ── Given steps (search) ──────────────────────────────────────────────

@given(parsers.parse('a document about "{topic}" has been indexed'))
def document_indexed(context, topic):
    context["indexed_topic"] = topic

@given("documents from multiple brands are indexed")
def multi_brand_indexed(context):
    context["multi_brand"] = True

@given("documents across multiple domains are indexed")
def multi_domain_indexed(context):
    context["multi_domain"] = True

@given("4G and 5G documents are indexed")
def gen_docs_indexed(context):
    context["generations_indexed"] = ["4G", "5G"]

@given("multiple documents are indexed")
def multiple_docs_indexed(context):
    context["multiple_docs"] = True

@given("more than 10 documents are indexed")
def many_docs_indexed(context):
    context["many_docs"] = True

@given(parsers.parse('the knowledge base has no data about "{topic}"'))
def no_data_about(context, topic):
    context["missing_topic"] = topic

@given(parsers.parse('a user is assigned only the "{domain}" domain'))
def user_domain_restricted(context, domain):
    context["user_domain"] = domain

@given(parsers.parse('a "{domain}" document about "{topic}" is indexed'))
def domain_doc_indexed(context, domain, topic):
    context["restricted_domain"] = domain
    context["restricted_topic"]  = topic

# ── When steps (search) ───────────────────────────────────────────────

@when(parsers.parse('the user sends a search query "{query}"'))
def send_search(context, query):
    no_auth = context.get("no_auth", False)
    headers = HEADERS_NO_AUTH if no_auth else HEADERS_AUTH
    context["last_query"] = query
    context["response"]   = requests.post(
        f"{BASE_URL}/api/search",
        json={"query": query, "top_k": 5},
        headers=headers
    )

@when(parsers.parse('the user searches "{query}" with brand_filter "{brand}"'))
def search_with_brand(context, query, brand):
    context["response"] = requests.post(
        f"{BASE_URL}/api/search",
        json={"query": query, "top_k": 5, "brand_filter": brand},
        headers=HEADERS_AUTH
    )

@when(parsers.parse('the user searches "{query}" with domain_filter "{domain}"'))
def search_with_domain(context, query, domain):
    context["response"] = requests.post(
        f"{BASE_URL}/api/search",
        json={"query": query, "top_k": 5, "domain_filter": domain},
        headers=HEADERS_AUTH
    )

@when(parsers.parse('the user searches "{query}" with generation_filter "{gen}"'))
def search_with_gen(context, query, gen):
    context["response"] = requests.post(
        f"{BASE_URL}/api/search",
        json={"query": query, "top_k": 5, "generation_filter": gen},
        headers=HEADERS_AUTH
    )

@when(parsers.parse('the user searches "{query}" with top_k set to {k:d}'))
def search_with_topk(context, query, k):
    context["response"] = requests.post(
        f"{BASE_URL}/api/search",
        json={"query": query, "top_k": k},
        headers=HEADERS_AUTH
    )

# ── Then steps (search) ───────────────────────────────────────────────

@then(parsers.parse("the results list should contain at least {count:d} item"))
def results_at_least(context, count):
    data    = context["response"].json()
    results = data.get("results", [])
    assert len(results) >= count, f"Expected >= {count} results, got {len(results)}"

@then(parsers.parse("the results list should contain exactly {count:d} items"))
def results_exactly(context, count):
    data    = context["response"].json()
    results = data.get("results", [])
    assert len(results) == count, f"Expected {count} results, got {len(results)}"

@then("the results list should be empty")
def results_empty(context):
    data    = context["response"].json()
    results = data.get("results", [])
    assert len(results) == 0, f"Expected empty results, got {len(results)}"

@then(parsers.parse('each result should have a "{field}" field'))
def each_result_has_field(context, field):
    data    = context["response"].json()
    results = data.get("results", [])
    for r in results:
        assert field in r, f"Result missing field '{field}': {r}"

@then("each result score should be between 0 and 1")
def scores_valid(context):
    data    = context["response"].json()
    results = data.get("results", [])
    for r in results:
        score = r.get("score", -1)
        assert 0 <= score <= 1, f"Score out of range: {score}"

@then(parsers.parse('all returned results should have brand "{brand}"'))
def all_results_brand(context, brand):
    data    = context["response"].json()
    results = data.get("results", [])
    for r in results:
        assert r.get("brand") == brand, (
            f"Expected brand={brand}, got {r.get('brand')}"
        )

@then(parsers.parse('all returned results should have domain "{domain}"'))
def all_results_domain(context, domain):
    data    = context["response"].json()
    results = data.get("results", [])
    for r in results:
        assert r.get("domain") == domain, (
            f"Expected domain={domain}, got {r.get('domain')}"
        )

@then(parsers.parse('all returned results should have generation "{gen}"'))
def all_results_gen(context, gen):
    data    = context["response"].json()
    results = data.get("results", [])
    for r in results:
        assert r.get("generation") == gen, (
            f"Expected generation={gen}, got {r.get('generation')}"
        )

@then("results should be ordered by score from highest to lowest")
def results_ordered(context):
    data    = context["response"].json()
    results = data.get("results", [])
    scores  = [r.get("score", 0) for r in results]
    assert scores == sorted(scores, reverse=True), (
        f"Results not in descending score order: {scores}"
    )

@then(parsers.parse('the field "{field}" should be {value:d}'))
def field_equals_int(context, field, value):
    data = context["response"].json()
    assert data.get(field) == value, (
        f"Expected {field}={value}, got {data.get(field)}"
    )


# ═════════════════════════════════════════════════════════════════════
# SPRINT 2 — CHAT / COMPLETIONS STEP DEFINITIONS
# ═════════════════════════════════════════════════════════════════════

# ── Given steps (chat) ────────────────────────────────────────────────

@given("the completions API is running")
def completions_api_running():
    res = requests.get(f"{BASE_URL}/docs")
    assert res.status_code == 200, "FastAPI server is not running"

@given("smartphone data has been indexed")
def smartphone_data_indexed(context):
    context["data_indexed"] = True

@given(parsers.parse('documents from "{source}" are indexed'))
def source_docs_indexed(context, source):
    context["indexed_source"] = source

@given("only partial data about a device is indexed")
def partial_data_indexed(context):
    context["partial_data"] = True

@given("the user attaches an image of a smartphone")
def attach_image(context):
    # Minimal 1x1 white PNG bytes for testing
    context["image"] = (
        b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x01"
        b"\x00\x00\x00\x01\x08\x02\x00\x00\x00\x90wS\xde\x00\x00"
        b"\x00\x0cIDATx\x9cc\xf8\x0f\x00\x00\x01\x01\x00\x05\x18"
        b"\xd5N\x00\x00\x00\x00IEND\xaeB`\x82"
    )

# ── When steps (chat) ─────────────────────────────────────────────────

@when(parsers.parse('the user asks "{question}"'))
def ask_question(context, question):
    no_auth      = context.get("no_auth", False)
    invalid_tok  = context.get("invalid_token", None)
    brand_filter = context.get("brand_filter", None)

    if invalid_tok:
        headers = {"Authorization": invalid_tok, "Content-Type": "application/json"}
    elif no_auth:
        headers = HEADERS_NO_AUTH
    else:
        headers = HEADERS_AUTH

    body = {"query": question}
    if brand_filter:
        body["brand_filter"] = brand_filter

    context["response"] = requests.post(
        f"{BASE_URL}/api/chat",
        json=body,
        headers=headers
    )

@when(parsers.parse('the user asks "{question}" with brand_filter "{brand}"'))
def ask_with_brand(context, question, brand):
    context["brand_filter"] = brand
    context["response"]     = requests.post(
        f"{BASE_URL}/api/chat",
        json={"query": question, "brand_filter": brand},
        headers=HEADERS_AUTH
    )

@when(parsers.parse('the user asks "{question}" with the image'))
def ask_with_image(context, question):
    image = context.get("image", b"fake_image_bytes")
    context["response"] = requests.post(
        f"{BASE_URL}/api/chat",
        files={"image": ("test.png", image, "image/png")},
        data={"query": question},
        headers={"Authorization": f"Bearer {TEST_TOKEN}"}
    )

@when("the user attaches an image with no text query")
def attach_image_no_query(context):
    image = context.get("image", b"fake_image_bytes")
    context["response"] = requests.post(
        f"{BASE_URL}/api/chat",
        files={"image": ("test.png", image, "image/png")},
        headers={"Authorization": f"Bearer {TEST_TOKEN}"}
    )

@when("the user sends an empty query to POST /api/chat")
def send_empty_chat(context):
    context["response"] = requests.post(
        f"{BASE_URL}/api/chat",
        json={"query": ""},
        headers=HEADERS_AUTH
    )

@when("the request is sent to POST /api/chat")
def send_chat_request(context):
    # Generic fallback when context already has the response set up
    pass

# ── Then steps (chat) ─────────────────────────────────────────────────

@then(parsers.parse('the field "{field}" should be false'))
def field_is_false(context, field):
    data = context["response"].json()
    assert data.get(field) is False, (
        f"Expected {field}=false, got {data.get(field)}"
    )

@then(parsers.parse('the field "{field}" should be true'))
def field_is_true(context, field):
    data = context["response"].json()
    assert data.get(field) is True, (
        f"Expected {field}=true, got {data.get(field)}"
    )

@then(parsers.parse('the field "{field}" should not be empty'))
def field_not_empty(context, field):
    data  = context["response"].json()
    value = data.get(field)
    assert value is not None and value != "" and value != [], (
        f"Expected {field} to be non-empty, got {value}"
    )

@then(parsers.parse('the field "{field}" should be empty or contain a rejection message'))
def field_empty_or_rejection(context, field):
    data  = context["response"].json()
    value = data.get(field, "")
    # Either empty or contains a message indicating rejection
    is_empty    = value == "" or value is None or value == []
    is_rejection= any(
        word in str(value).lower()
        for word in ["only", "smartphone", "cannot", "scope", "unrelated"]
    )
    assert is_empty or is_rejection, (
        f"Expected empty or rejection message in {field}, got: {value}"
    )

@then(parsers.parse('the field "{field}" should contain at least {count:d} item'))
def field_contains_items(context, field, count):
    data  = context["response"].json()
    value = data.get(field, [])
    assert len(value) >= count, (
        f"Expected {field} to have >= {count} items, got {len(value)}"
    )

@then(parsers.parse('the field "{field}" should be empty'))
def field_is_empty(context, field):
    data  = context["response"].json()
    value = data.get(field, [])
    assert value == [] or value == "" or value is None, (
        f"Expected {field} to be empty, got {value}"
    )

@then(parsers.parse('the field "{field}" should be greater than {value:f}'))
def field_greater_than_float(context, field, value):
    data = context["response"].json()
    assert data.get(field, 0) > value, (
        f"Expected {field} > {value}, got {data.get(field)}"
    )

@then(parsers.parse('the field "{field}" should be less than {value:f}'))
def field_less_than_float(context, field, value):
    data = context["response"].json()
    assert data.get(field, 1) < value, (
        f"Expected {field} < {value}, got {data.get(field)}"
    )

@then("the answer should reference content from the indexed documents")
def answer_references_docs(context):
    data   = context["response"].json()
    answer = data.get("answer", "")
    assert len(answer) > 20, f"Answer too short to be meaningful: {answer}"

@then("the sources should point to Samsung S24 related files")
def sources_samsung(context):
    data    = context["response"].json()
    sources = data.get("sources", [])
    # At least one source should mention Samsung or S24
    found = any(
        "samsung" in str(s).lower() or "s24" in str(s).lower()
        for s in sources
    )
    assert found, f"No Samsung S24 source found in: {sources}"

@then("each source should have a \"document\" field")
def sources_have_document(context):
    data    = context["response"].json()
    sources = data.get("sources", [])
    for s in sources:
        assert "document" in s, f"Source missing 'document' field: {s}"

@then("the answer should only reference 4G devices")
def answer_only_4g(context):
    data   = context["response"].json()
    answer = data.get("answer", "").lower()
    assert "5g" not in answer, f"Answer references 5G devices unexpectedly: {answer}"

@then("the answer should only reference Apple devices")
def answer_only_apple(context):
    data   = context["response"].json()
    answer = data.get("answer", "").lower()
    non_apple = ["samsung", "redmi", "realme", "poco", "motorola"]
    for brand in non_apple:
        assert brand not in answer, (
            f"Answer references non-Apple brand '{brand}': {answer}"
        )

@then("the answer should indicate that no relevant information was found")
def answer_no_info(context):
    data   = context["response"].json()
    answer = data.get("answer", "").lower()
    no_info_phrases = [
        "don't have", "no information", "couldn't find",
        "not found", "no data", "unable to find"
    ]
    found = any(phrase in answer for phrase in no_info_phrases)
    assert found, (
        f"Expected a 'no information' message in answer, got: {answer}"
    )

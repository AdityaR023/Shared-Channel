# tests/conftest.py
# Shared pytest configuration for SmartQnA BDD tests

import pytest

def pytest_configure(config):
    config.addinivalue_line(
        "markers", "sprint1: marks tests as Sprint 1 scenarios"
    )
    config.addinivalue_line(
        "markers", "sprint2: marks tests as Sprint 2 scenarios"
    )

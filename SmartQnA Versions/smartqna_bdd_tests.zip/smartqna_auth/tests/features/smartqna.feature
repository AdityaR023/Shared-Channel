# ─────────────────────────────────────────────────────────────────────
# SmartQnA — BDD Test Scenarios
# Group C | Frontend + QA
# Covers: Sprint 1 (Ingestion + Search) and Sprint 2 (Chat / Completions)
# Framework: pytest-bdd (Gherkin syntax)
# Run with: pytest tests/ -v
# ─────────────────────────────────────────────────────────────────────


# ═════════════════════════════════════════════════════════════════════
# SPRINT 1 — Ingestion + Search Foundation
# ═════════════════════════════════════════════════════════════════════

Feature: Sprint 1 — Document Ingestion

  # ── Upload: success cases ────────────────────────────────────────

  Scenario: Upload a valid PDF file successfully
    Given the ingestion API is running
    And the user has a valid PDF file "samsung_s24_manual.pdf"
    When the user uploads the file to POST /api/ingest
    Then the response status should be 200
    And the response should contain field "success" as true
    And the response should contain field "filename" as "samsung_s24_manual.pdf"
    And the document chunks should appear in OpenSearch

  Scenario: Upload a valid CSV file successfully
    Given the ingestion API is running
    And the user has a valid CSV file "budget_phones.csv" with 50 rows
    When the user uploads the file to POST /api/ingest
    Then the response status should be 200
    And the response should contain field "success" as true
    And the field "chunks_indexed" should be greater than 0

  Scenario: Upload a valid HTML file successfully
    Given the ingestion API is running
    And the user has a valid HTML file "gsmarena_redmi12.html"
    When the user uploads the file to POST /api/ingest
    Then the response status should be 200
    And the response should contain field "success" as true

  Scenario: Upload a plain text transcript file successfully
    Given the ingestion API is running
    And the user has a valid TXT file "pixel8_review_transcript.txt"
    When the user uploads the file to POST /api/ingest
    Then the response status should be 200
    And the response should contain field "success" as true

  # ── Upload: failure cases ─────────────────────────────────────────

  Scenario: Reject upload of unsupported file type
    Given the ingestion API is running
    And the user has a file "presentation.pptx"
    When the user uploads the file to POST /api/ingest
    Then the response status should be 400
    And the response should contain "unsupported file type"

  Scenario: Reject upload with no file attached
    Given the ingestion API is running
    When the user sends a POST to /api/ingest with no file
    Then the response status should be 422

  Scenario: Reject upload with missing mandatory metadata
    Given the ingestion API is running
    And the user has a valid PDF file "test.pdf"
    But the request is missing the "brand" field
    When the user uploads the file to POST /api/ingest
    Then the response status should be 422

  Scenario: Reject upload from unauthenticated user
    Given the ingestion API is running
    And the user has a valid PDF file "test.pdf"
    But no JWT token is provided in the request header
    When the user uploads the file to POST /api/ingest
    Then the response status should be 401


Feature: Sprint 1 — Document Search

  # ── Search: success cases ─────────────────────────────────────────

  Scenario: Search returns relevant results for a valid query
    Given a document about "Samsung S24 Ultra" has been indexed
    When the user sends a search query "S24 Ultra battery"
    Then the response status should be 200
    And the results list should contain at least 1 item
    And each result should have a "content" field
    And each result should have a "score" field
    And each result score should be between 0 and 1

  Scenario: Search with brand filter returns only matching brand results
    Given documents from multiple brands are indexed
    When the user searches "best camera phone" with brand_filter "Apple"
    Then the response status should be 200
    And all returned results should have brand "Apple"

  Scenario: Search with domain filter returns only matching domain results
    Given documents across multiple domains are indexed
    When the user searches "battery life" with domain_filter "5G"
    Then the response status should be 200
    And all returned results should have domain "5G"

  Scenario: Search with generation filter returns correct generation
    Given 4G and 5G documents are indexed
    When the user searches "processor specs" with generation_filter "4G"
    Then the response status should be 200
    And all returned results should have generation "4G"

  Scenario: Search results are returned in descending relevance order
    Given multiple documents are indexed
    When the user searches "Samsung S24 camera megapixels"
    Then the response status should be 200
    And results should be ordered by score from highest to lowest

  Scenario: Search respects top_k parameter
    Given more than 10 documents are indexed
    When the user searches "smartphone" with top_k set to 3
    Then the response status should be 200
    And the results list should contain exactly 3 items

  # ── Search: empty and edge cases ─────────────────────────────────

  Scenario: Search with no matching results returns empty list
    Given the knowledge base has no data about "Nokia 3310"
    When the user searches "Nokia 3310 specs"
    Then the response status should be 200
    And the results list should be empty
    And the field "total" should be 0

  Scenario: Search with empty query is rejected
    When the user sends a search query ""
    Then the response status should be 422
    And the response should contain "query cannot be empty"

  Scenario: Search from unauthenticated user is rejected
    Given no JWT token is provided in the request header
    When the user sends a search query "Samsung S24"
    Then the response status should be 401

  Scenario: User cannot search outside their assigned domains
    Given a user is assigned only the "4G" domain
    And a "5G" document about "iPhone 15" is indexed
    When the user searches "iPhone 15 specs"
    Then the response status should be 200
    And the results list should be empty


# ═════════════════════════════════════════════════════════════════════
# SPRINT 2 — Chat / Completions API
# ═════════════════════════════════════════════════════════════════════

Feature: Sprint 2 — Chat and Completions API

  # ── Chat: valid smartphone questions ─────────────────────────────

  Scenario: Valid smartphone question returns a proper answer
    Given the completions API is running
    And smartphone data has been indexed
    When the user asks "Does Samsung S24 Ultra support wireless charging?"
    Then the response status should be 200
    And the field "guardrail_triggered" should be false
    And the field "answer" should not be empty
    And the field "sources" should contain at least 1 item
    And the field "confidence" should be greater than 0

  Scenario: Question answered only from indexed documents
    Given only Samsung S24 documents are indexed
    When the user asks "What is the battery capacity of Samsung S24?"
    Then the response status should be 200
    And the answer should reference content from the indexed documents
    And the sources should point to Samsung S24 related files

  Scenario: Chat response includes source references
    Given documents from "gsmarena.com" are indexed
    When the user asks "What is the RAM of Redmi 12?"
    Then the response status should be 200
    And the field "sources" should not be empty
    And each source should have a "document" field

  Scenario: Chat with domain filter scopes the answer correctly
    Given 4G and 5G documents are indexed
    And the user has access to only "4G" domain
    When the user asks "Best phone with good battery?"
    Then the response status should be 200
    And the answer should only reference 4G devices

  Scenario: Chat with brand filter narrows the answer to that brand
    Given multiple brand documents are indexed
    When the user asks "Tell me about camera features" with brand_filter "Apple"
    Then the response status should be 200
    And the answer should only reference Apple devices

  # ── Chat: guardrail scenarios ─────────────────────────────────────

  Scenario: Non-smartphone question triggers guardrail
    Given the completions API is running
    When the user asks "What is the capital of France?"
    Then the response status should be 200
    And the field "guardrail_triggered" should be true
    And the field "answer" should be empty or contain a rejection message

  Scenario: Harmful or irrelevant query is blocked by guardrail
    Given the completions API is running
    When the user asks "How do I hack into a network?"
    Then the response status should be 200
    And the field "guardrail_triggered" should be true

  Scenario: Borderline query about phone accessories is allowed
    Given the completions API is running
    When the user asks "What charger is compatible with iPhone 15?"
    Then the response status should be 200
    And the field "guardrail_triggered" should be false

  # ── Chat: fallback when no results found ─────────────────────────

  Scenario: Fallback response when no relevant documents found
    Given no data about "Nokia 3310" exists in the knowledge base
    When the user asks "What is the battery of Nokia 3310?"
    Then the response status should be 200
    And the field "guardrail_triggered" should be false
    And the answer should indicate that no relevant information was found
    And the field "sources" should be empty

  Scenario: Low confidence score when answer is uncertain
    Given only partial data about a device is indexed
    When the user asks a detailed question about that device
    Then the response status should be 200
    And the field "confidence" should be less than 0.5

  # ── Chat: multimodal (image) ──────────────────────────────────────

  Scenario: Image upload with a smartphone question is accepted
    Given the completions API is running
    And the user attaches an image of a smartphone
    When the user asks "What phone is this?" with the image
    Then the response status should be 200
    And the field "answer" should not be empty

  Scenario: Image upload without a query defaults to describe behaviour
    Given the completions API is running
    And the user attaches an image with no text query
    When the request is sent to POST /api/chat
    Then the response status should be 200
    And the field "answer" should not be empty

  # ── Chat: error handling ──────────────────────────────────────────

  Scenario: Empty query is rejected
    When the user sends an empty query to POST /api/chat
    Then the response status should be 422

  Scenario: Unauthenticated chat request is rejected
    Given no JWT token is provided in the request header
    When the user asks "Does S24 have 5G?"
    Then the response status should be 401

  Scenario: Chat request with invalid JWT is rejected
    Given an expired or invalid JWT token is provided
    When the user asks "Does S24 have 5G?"
    Then the response status should be 401

# SmartQnA — BDD Tests

## Setup
```bash
pip install pytest pytest-bdd requests
```

## Run all tests
```bash
pytest tests/ -v
```

## Run Sprint 1 only
```bash
pytest tests/ -v -k "Ingestion or Search"
```

## Run Sprint 2 only
```bash
pytest tests/ -v -k "Chat"
```

## Run a specific scenario
```bash
pytest tests/ -v -k "Upload a valid PDF"
```

## Notes
- Server must be running on localhost:8000 before running tests
- Update TEST_TOKEN in test_smartqna.py once Group B delivers real auth
- Sprint 1 tests require Group A's ingestion + search APIs to be live
- Sprint 2 tests require Group B's completions API to be live

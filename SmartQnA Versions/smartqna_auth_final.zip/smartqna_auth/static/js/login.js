// ── Validate token on load — fixes stuck redirect after server restart ─
(async () => {
  const token = localStorage.getItem("token");
  if (!token) return;

  try {
    const res = await fetch("/api/auth/me", {
      headers: { "Authorization": `Bearer ${token}` }
    });
    if (res.ok) {
      window.location.href = "/chat";
    } else {
      clearStorage();
    }
  } catch {
    // Server not reachable — clear and stay on login
    clearStorage();
  }
})();

// ── Element references ────────────────────────────────────────────────
const loginForm  = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passInput  = document.getElementById("password");
const loginBtn   = document.getElementById("loginBtn");
const errorAlert = document.getElementById("errorAlert");

// ── Form submit ───────────────────────────────────────────────────────
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearErrors();

  const email    = emailInput.value.trim();
  const password = passInput.value.trim();
  let valid = true;

  if (!email || !isValidEmail(email)) {
    showFieldError(emailInput, "emailError"); valid = false;
  }
  if (!password) {
    showFieldError(passInput, "passwordError"); valid = false;
  }
  if (!valid) return;

  setLoading(true);

  try {
    const formData = new URLSearchParams();
    formData.append("username", email);
    formData.append("password", password);

    const response = await fetch("/api/auth/login", {
      method:  "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body:    formData,
    });

    const data = await response.json();

    if (response.ok) {
      // Store token + user info (domains come from server — set at signup)
      localStorage.setItem("token",   data.access_token);
      localStorage.setItem("user",    JSON.stringify(data.user));
      localStorage.setItem("domains", JSON.stringify(data.user.domains));
      window.location.href = "/chat";
    } else {
      showAlert(data.detail || "Invalid email or password.");
    }

  } catch {
    showAlert("Could not reach the server. Please try again.");
  } finally {
    setLoading(false);
  }
});

// ── Helpers ───────────────────────────────────────────────────────────
function isValidEmail(e) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
}

function showFieldError(input, errorId) {
  input.classList.add("error");
  document.getElementById(errorId).classList.add("visible");
}

function clearErrors() {
  [emailInput, passInput].forEach(el => el.classList.remove("error"));
  document.querySelectorAll(".error-msg").forEach(el => el.classList.remove("visible"));
  errorAlert.classList.remove("visible");
  errorAlert.textContent = "";
}

function showAlert(msg) {
  errorAlert.textContent = msg;
  errorAlert.classList.add("visible");
}

function setLoading(loading) {
  loginBtn.disabled  = loading;
  loginBtn.innerHTML = loading
    ? '<span class="spinner"></span> Signing in...'
    : "Sign In";
}

function clearStorage() {
  ["token","user","domains","api_key"].forEach(k => localStorage.removeItem(k));
}

function clearSessionAndStay(e) {
  e.preventDefault();
  clearStorage();
  window.location.reload();
}

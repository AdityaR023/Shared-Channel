// ── Auth guard ────────────────────────────────────────────────────────
requireAuth();
populateNavbarUser();

// ── Element references ────────────────────────────────────────────────
const searchInput   = document.getElementById("searchInput");
const searchBtn     = document.getElementById("searchBtn");
const initialState  = document.getElementById("initialState");
const searchLoading = document.getElementById("searchLoading");
const resultsHeader = document.getElementById("resultsHeader");
const resultsList   = document.getElementById("resultsList");
const noResults     = document.getElementById("noResults");
const searchError   = document.getElementById("searchError");
const resultsCount  = document.getElementById("resultsCount");
const resultsQuery  = document.getElementById("resultsQuery");

// ── Populate domain filter from user's assigned domains ───────────────
populateDomainFilter("#domainFilter", true);

// ── Track last query for "Ask in Chat" button ─────────────────────────
let lastQuery = "";

// ── Search on button click ────────────────────────────────────────────
searchBtn.addEventListener("click", runSearch);

// ── Search on Enter key ───────────────────────────────────────────────
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") runSearch();
});

// ── Example query chips ───────────────────────────────────────────────
function fillSearch(chipEl) {
  searchInput.value = chipEl.textContent.trim();
  searchInput.focus();
  runSearch();
}

// ── Clear all filters ─────────────────────────────────────────────────
function clearFilters() {
  document.getElementById("domainFilter").value     = "";
  document.getElementById("brandFilter").value      = "";
  document.getElementById("generationFilter").value = "";
  document.getElementById("sourceFilter").value     = "";
  document.getElementById("topKFilter").value       = "5";
}

// ── Core search function ──────────────────────────────────────────────
async function runSearch() {
  const query = searchInput.value.trim();
  if (!query) {
    searchInput.focus();
    return;
  }

  lastQuery = query;

  // Collect filter values
  const domain     = document.getElementById("domainFilter").value     || null;
  const brand      = document.getElementById("brandFilter").value      || null;
  const generation = document.getElementById("generationFilter").value || null;
  const source     = document.getElementById("sourceFilter").value     || null;
  const topK       = parseInt(document.getElementById("topKFilter").value) || 5;

  // Show loading state, hide everything else
  showState("loading");
  searchBtn.disabled = true;

  try {
    const response = await authFetch("/api/search", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        query,
        top_k:             topK,
        domain_filter:     domain,
        brand_filter:      brand,
        generation_filter: generation,
        source_filter:     source,
      }),
    });

    if (!response) return; // 401 — redirected to login

    const data = await response.json();

    if (!response.ok) {
      showState("error");
      searchError.textContent = data.detail || "Search failed. Please try again.";
      searchError.style.display = "block";
      return;
    }

    const results = data.results || [];

    if (results.length === 0) {
      // No results found
      showState("empty");
      document.getElementById("noResultsSub").textContent =
        `No documents matched "${query}". Try different keywords or upload more documents.`;
      return;
    }

    // Show results
    showState("results");
    resultsCount.textContent = `${results.length} result${results.length > 1 ? "s" : ""}`;
    resultsQuery.textContent = `for "${query}"`;

    resultsList.innerHTML = "";
    results.forEach((result, index) => {
      renderResultCard(result, query, index);
    });

  } catch (err) {
    // Sprint 1 — backend not fully connected yet
    // Show sample results so the UI can be demoed
    showState("results");
    const sampleResults = getSampleResults(query);
    resultsCount.textContent = `${sampleResults.length} result${sampleResults.length > 1 ? "s" : ""} (sample data)`;
    resultsQuery.textContent = `for "${query}"`;
    resultsList.innerHTML = "";
    sampleResults.forEach((result, index) => renderResultCard(result, query, index));

  } finally {
    searchBtn.disabled = false;
  }
}

// ── Render a single result card ───────────────────────────────────────
function renderResultCard(result, query, index) {
  const card = document.createElement("div");
  card.className = "result-card";

  // Score as percentage
  const score    = result.score || 0;
  const scorePct = Math.round(score * 100);
  const scoreClass = scorePct >= 70 ? "" : scorePct >= 40 ? "medium" : "low";

  // Highlight the search query keywords in the content snippet
  const snippet = highlightKeywords(
    truncate(result.content || result.description || "No content available", 220),
    query
  );

  // Badges — only show if the value exists
  const badges = [
    result.brand      ? `<span class="result-badge badge-brand">${result.brand}</span>`      : "",
    result.generation ? `<span class="result-badge badge-gen">${result.generation}</span>`    : "",
    result.domain     ? `<span class="result-badge badge-domain">${result.domain}</span>`     : "",
    result.content_type ? `<span class="result-badge badge-type">${result.content_type?.toUpperCase()}</span>` : "",
  ].filter(Boolean).join("");

  // Source — make it a link if it looks like a URL, otherwise plain text
  const sourceDisplay = result.source
    ? (result.source.includes(".")
        ? `<a href="https://${result.source.replace(/^https?:\/\//, '')}" target="_blank">${result.source}</a>`
        : result.source)
    : "Unknown source";

  card.style.animationDelay = `${index * 0.05}s`;

  card.innerHTML = `
    <div class="result-card-header">
      <div class="result-title">
        ${result.brand || ""} ${result.model || result.title || "Document chunk"}
      </div>
      <div class="result-score-wrap">
        <span class="result-score-label">Relevance</span>
        <div class="result-score-bar">
          <div class="score-track">
            <div class="score-fill ${scoreClass}" style="width:${scorePct}%"></div>
          </div>
          <span class="score-value">${scorePct}%</span>
        </div>
      </div>
    </div>

    <div class="result-badges">${badges}</div>

    <div class="result-content">${snippet}</div>

    <div class="result-footer">
      <span class="result-source">📄 Source: ${sourceDisplay}</span>
      <button class="btn-ask-this"
              onclick="askThisInChat('${escapeAttr(result.content || result.description || "")}')">
        💬 Ask about this
      </button>
    </div>
  `;

  resultsList.appendChild(card);
}

// ── "Ask in Chat" — carry current query over to Chat page ────────────
// Stores the query in sessionStorage then navigates
// Chat page can read it on load and pre-fill the input
function askInChat() {
  if (!lastQuery) return;
  sessionStorage.setItem("chatPrefill", lastQuery);
  window.location.href = "/chat";
}

// "Ask about this" — carry a specific snippet's context to chat
function askThisInChat(content) {
  const question = `Based on this information: "${truncate(content, 120)}" — can you elaborate?`;
  sessionStorage.setItem("chatPrefill", question);
  window.location.href = "/chat";
}

// ── State management — show one section at a time ─────────────────────
function showState(state) {
  initialState.style.display  = state === "initial"  ? "block" : "none";
  searchLoading.style.display = state === "loading"  ? "block" : "none";
  resultsHeader.style.display = state === "results"  ? "flex"  : "none";
  resultsList.style.display   = state === "results"  ? "block" : "none";
  noResults.style.display     = state === "empty"    ? "block" : "none";
  searchError.style.display   = state === "error"    ? "block" : "none";
}

// ── Keyword highlighting ──────────────────────────────────────────────
// Wraps matched keywords in <mark> tags for yellow highlight
function highlightKeywords(text, query) {
  if (!query) return text;

  // Split query into individual words, escape special regex characters
  const words = query
    .split(/\s+/)
    .filter(w => w.length > 2) // only highlight words longer than 2 chars
    .map(w => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")); // escape regex

  if (!words.length) return text;

  // Build one regex that matches any of the keywords (case-insensitive)
  const regex = new RegExp(`(${words.join("|")})`, "gi");
  return text.replace(regex, "<mark>$1</mark>");
}

// ── Truncate long text ────────────────────────────────────────────────
function truncate(text, maxLen) {
  if (!text || text.length <= maxLen) return text;
  return text.substring(0, maxLen).trim() + "...";
}

// ── Escape for HTML attribute (used in onclick) ───────────────────────
function escapeAttr(str) {
  return str.replace(/'/g, "\\'").replace(/"/g, "&quot;").substring(0, 200);
}

// ── Sample results for Sprint 1 demo (when backend isn't connected) ───
function getSampleResults(query) {
  return [
    {
      brand: "Samsung", model: "Galaxy S24 Ultra", generation: "5G",
      domain: "5G", source: "gsmarena.com", content_type: "pdf", score: 0.94,
      content: "Samsung Galaxy S24 Ultra features a 5000mAh battery with 45W wired fast charging and 15W wireless charging support. The titanium frame design and 200MP main sensor make it a flagship device for 2024.",
    },
    {
      brand: "Redmi", model: "Redmi 12", generation: "4G",
      domain: "4G", source: "91mobiles.com", content_type: "csv", score: 0.81,
      content: "Redmi 12 is powered by the Snapdragon 685 chipset with a 6.79-inch FHD+ IPS LCD display. The 5000mAh battery and 50MP main camera make it a strong budget 4G contender under ₹10,000.",
    },
    {
      brand: "Motorola", model: "Moto G54 5G", generation: "5G",
      domain: "5G", source: "flipkart.com", content_type: "csv", score: 0.73,
      content: "Moto G54 5G offers one of the best battery capacities in budget 5G segment with 6000mAh. Dimensity 7020 chipset, 6.5-inch IPS LCD display, available under ₹15,000.",
    },
  ];
}

// ── On page load: check if chat page sent a prefill query ─────────────
// (Not used on search page itself, but good pattern for cross-page communication)
window.addEventListener("load", () => {
  showState("initial");
});

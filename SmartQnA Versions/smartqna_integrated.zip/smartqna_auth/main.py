from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from typing import Optional, List
import shutil
import os

# ── Group A imports ───────────────────────────────────────────────────
# These are the files shared by Group A — generate_metadata_file.py and Chroma.py
# They handle metadata extraction, ChromaDB indexing and search
from generate_metadata_file import generate_metadata
from Chroma import index_data, search_data

# ── App setup ─────────────────────────────────────────────────────────
app = FastAPI(
    title="SmartQnA",
    description="AI-powered smartphone Q&A system",
    version="0.2.0"
)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

# ── Ensure required folders exist ─────────────────────────────────────
os.makedirs("Data",     exist_ok=True)
os.makedirs("metadata", exist_ok=True)


# ═════════════════════════════════════════════════════════════════════
# REQUEST / RESPONSE MODELS
# ═════════════════════════════════════════════════════════════════════

class SignupRequest(BaseModel):
    username: str
    email:    str
    password: str
    domains:  List[str]

class SearchRequest(BaseModel):
    query:             str
    top_k:             int = 5
    brand_filter:      Optional[str] = None
    model_filter:      Optional[str] = None
    domain_filter:     Optional[str] = None
    generation_filter: Optional[str] = None
    source_filter:     Optional[str] = None

class ChatRequest(BaseModel):
    query:         str
    domain:        Optional[str] = None
    brand_filter:  Optional[str] = None
    source_filter: Optional[str] = None


# ═════════════════════════════════════════════════════════════════════
# PAGE ROUTES — serve HTML templates
# ═════════════════════════════════════════════════════════════════════

@app.get("/")
def root():
    return RedirectResponse(url="/login")

@app.get("/login")
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/signup")
def signup_page(request: Request):
    return templates.TemplateResponse("signup.html", {"request": request})

@app.get("/signup/success")
def signup_success_page(request: Request):
    return templates.TemplateResponse("signup_success.html", {"request": request})

@app.get("/upload")
def upload_page(request: Request):
    return templates.TemplateResponse("documents.html", {"request": request})

@app.get("/chat")
def chat_page(request: Request):
    return templates.TemplateResponse("chat.html", {"request": request})

@app.get("/search")
def search_page(request: Request):
    return templates.TemplateResponse("search.html", {"request": request})

@app.get("/profile")
def profile_page(request: Request):
    return templates.TemplateResponse("profile.html", {"request": request})


# ═════════════════════════════════════════════════════════════════════
# AUTH API — stubs (Group B to implement real JWT logic)
# ═════════════════════════════════════════════════════════════════════

@app.get("/api/auth/me")
async def get_me(request: Request):
    """Validate JWT token — stub returns user if Bearer token present."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer ") or len(auth_header.split(" ")) < 2:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    return {
        "id":       "user_001",
        "email":    "test@example.com",
        "username": "testuser",
        "domains":  ["4G", "5G"],
    }

@app.post("/api/auth/login")
async def login():
    """Login — stub returns a dummy JWT."""
    return {
        "access_token": "stub_jwt_token",
        "token_type":   "bearer",
        "user": {
            "id":       "user_001",
            "email":    "test@example.com",
            "username": "testuser",
            "domains":  ["4G", "5G"],
        }
    }

@app.post("/api/auth/signup")
async def signup(body: SignupRequest):
    """Signup — stub creates user and returns API key/secret."""
    return {
        "access_token": "stub_jwt_token",
        "token_type":   "bearer",
        "api_key":      "smq_key_stub123",
        "api_secret":   "smq_secret_stub456",
        "user": {
            "id":       "user_002",
            "email":    body.email,
            "username": body.username,
            "domains":  body.domains,
        }
    }

@app.post("/api/auth/logout")
async def logout():
    return {"success": True}


# ═════════════════════════════════════════════════════════════════════
# GROUP A — METADATA API
# Converted from Flask: @app.route("/generate-metadata", methods=["POST"])
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/generate-metadata")
async def metadata_api():
    """
    Scan the Data/ folder and generate metadata JSON files
    for all supported file types (CSV, PDF, HTML, JSON).
    Maps each file to its metadata file in file_mapping.json.
    """
    try:
        result = generate_metadata("Data")
        return {
            "status":    "success",
            "processed": result["processed"],
            "skipped":   result["skipped"],
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ═════════════════════════════════════════════════════════════════════
# GROUP A — INGEST / INDEXING API  (TASK-103)
# Converted from Flask: @app.route("/index", methods=["POST"])
# Extended to accept file uploads from the UI
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/ingest")
async def ingest(
    file:        UploadFile = File(...),
    brand:       str        = Form(...),
    model:       str        = Form(...),
    generation:  str        = Form(...),
    source:      str        = Form(...),
    domain:      str        = Form(...),
    launch_year: Optional[str] = Form(None),
    price_range: Optional[str] = Form(None),
    content_type_field: Optional[str] = Form(None),
):
    """
    Accept a file upload from the Documents UI.
    1. Save the file to Data/ folder
    2. Generate metadata for it
    3. Index it into ChromaDB via Group A's index_data()
    """
    try:
        # 1. Save uploaded file to Data/ folder
        file_path = os.path.join("Data", file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # 2. Generate metadata for the newly uploaded file
        generate_metadata("Data")

        # 3. Index everything in Data/ into ChromaDB
        chunks_indexed = index_data("file_mapping.json", "Data")

        return {
            "success":        True,
            "filename":       file.filename,
            "chunks_indexed": chunks_indexed,
            "brand":          brand,
            "model":          model,
            "generation":     generation,
            "domain":         domain,
            "source":         source,
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/index")
async def index_api():
    """
    Re-index everything in the Data/ folder into ChromaDB.
    Useful to call manually if files were added outside the upload UI.
    Converted from Flask: @app.route("/index", methods=["POST"])
    """
    try:
        result = index_data("file_mapping.json", "Data")
        return {
            "status":            "indexed",
            "documents_indexed": result,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ═════════════════════════════════════════════════════════════════════
# GROUP A — SEARCH API  (TASK-104)
# Converted from Flask: @app.route("/search", methods=["GET"])
# Changed to POST with JSON body to match the frontend's fetch() call
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/search")
async def search_api(body: SearchRequest):
    """
    Search indexed documents in ChromaDB.

    Original Flask version used GET ?q= param.
    Converted to POST with JSON body to match:
      - Search page UI (search.js)
      - BDD test scenarios
      - Postman collection

    ChromaDB distance scores: lower = more similar (0 = perfect match).
    We convert to a relevance score where higher = better for the UI.
    """
    if not body.query or not body.query.strip():
        raise HTTPException(status_code=422, detail="query cannot be empty")

    try:
        # Call Group A's search function
        raw_results = search_data(body.query)

        # Group A's search_data returns:
        # [{ "category", "file", "score" (distance), "chunk_id" }]

        # Convert ChromaDB distance → relevance score for the UI
        # ChromaDB distance is 0 (identical) to 2 (opposite)
        # We flip it: relevance = 1 - (distance / 2)
        formatted = []
        for r in raw_results:
            distance  = r.get("score", 1.0)
            relevance = round(1 - (distance / 2), 3)
            relevance = max(0.0, min(1.0, relevance))  # clamp 0–1

            # Apply domain filter if provided
            # ChromaDB metadata stores category (2g/3g/4g/5g)
            category = r.get("category", "").lower()
            if body.domain_filter and category != body.domain_filter.lower():
                continue
            if body.generation_filter and category != body.generation_filter.lower():
                continue

            formatted.append({
                "content":      r.get("file", ""),   # file path as content reference
                "source":       r.get("file", ""),
                "score":        relevance,
                "category":     r.get("category"),
                "chunk_id":     r.get("chunk_id"),
                "domain":       r.get("category"),   # category maps to domain
                "generation":   r.get("category"),
            })

        # Respect top_k
        formatted = formatted[:body.top_k]

        return {
            "query":   body.query,
            "results": formatted,
            "total":   len(formatted),
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ═════════════════════════════════════════════════════════════════════
# GROUP A — VALIDATE API  (TASK-105)
# Converted from Flask: @app.route("/search/validate", methods=["GET"])
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/search/validate")
async def validate_api(body: SearchRequest):
    """
    Search and return only high-quality results.
    Group A's original logic: filter results where distance < 0.7
    In our converted relevance score: relevance > 0.65 (approx equivalent)
    """
    if not body.query or not body.query.strip():
        raise HTTPException(status_code=422, detail="query cannot be empty")

    try:
        raw_results = search_data(body.query)

        all_formatted = []
        valid_results = []

        for r in raw_results:
            distance  = r.get("score", 1.0)
            relevance = round(1 - (distance / 2), 3)
            relevance = max(0.0, min(1.0, relevance))

            item = {
                "content":    r.get("file", ""),
                "source":     r.get("file", ""),
                "score":      relevance,
                "category":   r.get("category"),
                "chunk_id":   r.get("chunk_id"),
            }

            all_formatted.append(item)

            # Original Group A threshold: score (distance) < 0.7
            # Keeping the same logic but using their raw distance
            if distance < 0.7:
                valid_results.append(item)

        return {
            "query":         body.query,
            "valid_results": valid_results,
            "total_results": len(all_formatted),
            "valid_count":   len(valid_results),
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ═════════════════════════════════════════════════════════════════════
# DOCUMENT CRUD — wraps ChromaDB for the Documents UI page
# ═════════════════════════════════════════════════════════════════════

@app.get("/api/documents")
async def list_documents(
    search: Optional[str] = Query(None),
    domain: Optional[str] = Query(None),
    type:   Optional[str] = Query(None),
):
    """
    List all documents in the Data/ folder.
    Uses ChromaDB collection to get indexed file metadata.
    """
    try:
        from Chroma import collection

        # Get all items from ChromaDB
        all_items = collection.get(include=["metadatas"])
        metadatas = all_items.get("metadatas", [])

        # Deduplicate by file path
        seen      = set()
        documents = []

        for meta in metadatas:
            file_path = meta.get("file_path", "")
            if file_path in seen:
                continue
            seen.add(file_path)

            category = meta.get("category", "")
            file_type= meta.get("file_type", "").replace(".", "")

            # Apply filters
            if domain and category.lower() != domain.lower():
                continue
            if type and file_type.lower() != type.lower():
                continue
            if search:
                name = meta.get("file_name", "").lower()
                if search.lower() not in name:
                    continue

            documents.append({
                "id":           file_path,
                "brand":        "",           # not stored in ChromaDB metadata yet
                "model":        meta.get("file_name", "").replace("_", " "),
                "generation":   category.upper(),
                "domain":       category.upper(),
                "source":       file_path,
                "content_type": file_type,
                "uploaded_at":  None,
            })

        return {"documents": documents, "total": len(documents)}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/api/documents/{doc_id:path}")
async def get_document(doc_id: str):
    """Get metadata for a single document by file path."""
    try:
        from Chroma import collection
        results = collection.get(
            where={"file_path": doc_id},
            include=["metadatas"],
            limit=1
        )
        if not results["metadatas"]:
            raise HTTPException(status_code=404, detail="Document not found")

        meta = results["metadatas"][0]
        return {
            "id":           doc_id,
            "model":        meta.get("file_name", ""),
            "generation":   meta.get("category", "").upper(),
            "domain":       meta.get("category", "").upper(),
            "source":       doc_id,
            "content_type": meta.get("file_type", "").replace(".", ""),
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.patch("/api/documents/{doc_id:path}")
async def update_document(doc_id: str, body: dict):
    """
    Update document metadata.
    ChromaDB doesn't support direct metadata updates —
    this updates the local file and re-indexes.
    Group A to implement full update logic in Sprint 2 (TASK-201).
    """
    return {"success": True, "id": doc_id, "updated": body}


@app.delete("/api/documents/{doc_id:path}")
async def delete_document(doc_id: str):
    """
    Delete document from ChromaDB and Data/ folder.
    Removes all chunks associated with the file path.
    """
    try:
        from Chroma import collection

        # Get all chunk IDs for this file
        results = collection.get(
            where={"file_path": doc_id},
            include=["metadatas"]
        )
        ids_to_delete = results.get("ids", [])

        if ids_to_delete:
            collection.delete(ids=ids_to_delete)

        # Also delete the actual file if it exists
        if os.path.exists(doc_id):
            os.remove(doc_id)

        return {"success": True, "id": doc_id, "chunks_deleted": len(ids_to_delete)}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ═════════════════════════════════════════════════════════════════════
# CHAT / COMPLETIONS API
# Group B to implement real RAG + LLM logic (TASK-205 to 208)
# For now: runs search via Group A's ChromaDB and returns raw chunks
# as the "answer" so the UI has something real to display
# ═════════════════════════════════════════════════════════════════════

@app.post("/api/chat")
async def chat(
    request: Request,
    query:         Optional[str]        = Form(None),
    image:         Optional[UploadFile] = File(None),
    domain:        Optional[str]        = Form(None),
    brand_filter:  Optional[str]        = Form(None),
    source_filter: Optional[str]        = Form(None),
):
    """
    Chat endpoint.
    Current behaviour (Sprint 2 workaround):
      - Runs Group A's search_data() to find relevant chunks
      - Returns the top chunk content as the "answer"
      - Guardrail: basic keyword check for smartphone relevance
      - Group B will replace this with real LLM + RAG logic

    Handles both:
      - JSON body (text-only queries from chat.js)
      - FormData (multimodal queries with image attachment)
    """

    # Handle JSON body (text-only path)
    if query is None:
        try:
            body         = await request.json()
            query        = body.get("query", "")
            domain       = body.get("domain")
            brand_filter = body.get("brand_filter")
            source_filter= body.get("source_filter")
        except Exception:
            raise HTTPException(status_code=422, detail="Invalid request body")

    if not query or not query.strip():
        raise HTTPException(status_code=422, detail="query cannot be empty")

    # ── Basic guardrail ───────────────────────────────────────────────
    # Group B will implement a proper LLM-based guardrail
    # For now: check if query contains any smartphone-related keywords
    smartphone_keywords = [
        "phone", "mobile", "smartphone", "battery", "camera", "display",
        "screen", "processor", "ram", "storage", "5g", "4g", "3g", "2g",
        "android", "ios", "iphone", "samsung", "redmi", "realme", "poco",
        "oneplus", "pixel", "motorola", "nokia", "charging", "specs",
        "specification", "review", "price", "launch", "chipset", "sensor",
        "megapixel", "mp", "mah", "gb", "brand", "model", "flagship",
        "budget", "mid-range", "premium", "charger", "cable", "accessory"
    ]
    query_lower = query.lower()
    is_smartphone_related = any(kw in query_lower for kw in smartphone_keywords)

    if not is_smartphone_related:
        return {
            "answer":              "",
            "sources":             [],
            "confidence":          0.0,
            "guardrail_triggered": True,
        }

    # ── Search ChromaDB for relevant chunks ───────────────────────────
    try:
        raw_results = search_data(query)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Search failed: {str(e)}")

    if not raw_results:
        return {
            "answer":              "I don't have enough information in the uploaded documents to answer this question.",
            "sources":             [],
            "confidence":          0.0,
            "guardrail_triggered": False,
        }

    # ── Build answer from top chunks ──────────────────────────────────
    # Group B replaces this section with real LLM call
    # For now: return the file references as the answer
    top_result   = raw_results[0]
    distance     = top_result.get("score", 1.0)
    confidence   = round(1 - (distance / 2), 3)
    confidence   = max(0.0, min(1.0, confidence))

    # Build sources list
    sources = []
    for r in raw_results[:3]:
        file_name = os.path.basename(r.get("file", ""))
        sources.append({
            "document": file_name,
            "url":      "",
            "category": r.get("category", ""),
        })

    # Temporary answer — Group B replaces with LLM-generated response
    answer = (
        f"Based on the indexed documents, the most relevant information "
        f"was found in: {', '.join([s['document'] for s in sources])}. "
        f"(Note: Full LLM-generated answers will be available once Group B "
        f"integrates the Completions API in Sprint 2.)"
    )

    return {
        "answer":              answer,
        "sources":             sources,
        "confidence":          confidence,
        "guardrail_triggered": False,
    }

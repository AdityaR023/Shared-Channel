# ── Logger import — paste this at the top of every service main.py ────
# Works because logger.py is at project root and uses absolute paths.
# Each service runs from its own folder (e.g. cd ui-service && uvicorn main:app)
# The ".." resolves back to project root where logger.py lives.

import sys, os
sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from logger import get_logger

logger = get_logger("ui_service")          # ui-service/main.py
# logger = get_logger("completions_service") # completions-service/main.py
# logger = get_logger("search_service")      # search-service/main.py (if added)

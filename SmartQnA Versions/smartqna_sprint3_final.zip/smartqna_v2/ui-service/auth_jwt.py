"""
SmartQnA — JWT Authentication
Real JWT implementation using python-jose.

Token contains:
  - user_id
  - email
  - username
  - domains        (selected at signup — permanent access scope)
  - active_domains (selected at query time — per-request filter)
  - exp            (expiry timestamp)

Install: pip install python-jose[cryptography]
"""

import os
from datetime import datetime, timedelta
from typing import Optional, List
from jose import JWTError, jwt
from fastapi import HTTPException, Request
import sys

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from logger import get_logger

logger = get_logger("auth.jwt")

# ── Config ─────────────────────────────────────────────────────────────
# Change SECRET_KEY in .env before deploying
SECRET_KEY    = os.getenv("JWT_SECRET_KEY", "smartqna-secret-key-change-in-production")
ALGORITHM     = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("JWT_EXPIRE_MINUTES", "60"))


# ═════════════════════════════════════════════════════════════════════
# TOKEN CREATION
# ═════════════════════════════════════════════════════════════════════

def create_access_token(
    user_id:        str,
    email:          str,
    username:       str,
    domains:        List[str],          # permanent — from signup
    active_domains: Optional[List[str]] = None,  # per-session filter
) -> str:
    """
    Create a signed JWT containing user identity and domain access.

    domains        = what the user is subscribed to (set at signup, never changes)
    active_domains = what they selected for this session (subset of domains)
                     defaults to all their domains if not specified
    """
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)

    payload = {
        "sub":            user_id,
        "email":          email,
        "username":       username,
        "domains":        domains,                        # permanent access
        "active_domains": active_domains or domains,     # session filter
        "exp":            expire,
        "iat":            datetime.utcnow(),
    }

    token = jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)
    logger.info(
        f"Token created for {email} | "
        f"domains: {domains} | active: {active_domains or domains}"
    )
    return token


def create_token_with_active_domains(
    user:           dict,
    active_domains: List[str],
) -> str:
    """
    Create a new token when user selects specific domains for a query session.
    Validates that active_domains is a subset of user's subscribed domains.
    """
    subscribed = user.get("domains", [])

    # Validate — user can't select domains they don't have access to
    invalid = [d for d in active_domains if d not in subscribed]
    if invalid:
        raise HTTPException(
            status_code=403,
            detail=f"You don't have access to domains: {invalid}. "
                   f"Your subscribed domains: {subscribed}"
        )

    return create_access_token(
        user_id        = user["id"],
        email          = user["email"],
        username       = user["username"],
        domains        = subscribed,
        active_domains = active_domains,
    )


# ═════════════════════════════════════════════════════════════════════
# TOKEN VALIDATION
# ═════════════════════════════════════════════════════════════════════

def decode_token(token: str) -> dict:
    """
    Decode and validate a JWT.
    Raises HTTPException 401 if invalid or expired.
    Returns the full payload dict.
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError as e:
        logger.warning(f"JWT decode failed: {e}")
        raise HTTPException(
            status_code=401,
            detail="Token is invalid or has expired. Please log in again."
        )


def get_token_from_request(request: Request) -> str:
    """Extract Bearer token from Authorization header."""
    auth = request.headers.get("Authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(
            status_code=401,
            detail="Missing or invalid Authorization header. Expected: Bearer <token>"
        )
    return auth[7:]


def get_current_user(request: Request) -> dict:
    """
    Dependency — extracts and validates JWT from request.
    Returns decoded payload with user info + domains.

    Use in any endpoint:
        user = get_current_user(request)
        user["domains"]        → subscribed domains
        user["active_domains"] → current session domains
    """
    token   = get_token_from_request(request)
    payload = decode_token(token)

    # Ensure required fields exist
    if not payload.get("sub"):
        raise HTTPException(status_code=401, detail="Invalid token payload")

    return {
        "id":             payload["sub"],
        "email":          payload.get("email", ""),
        "username":       payload.get("username", ""),
        "domains":        payload.get("domains", []),         # subscribed
        "active_domains": payload.get("active_domains", []),  # session filter
    }


def require_domain_access(user: dict, domain: str) -> bool:
    """
    Check if user has access to a specific domain.
    Checks against their subscribed domains (not active_domains).
    """
    subscribed = [d.lower() for d in user.get("domains", [])]
    if domain.lower() not in subscribed:
        raise HTTPException(
            status_code=403,
            detail=f"You don't have access to domain '{domain}'. "
                   f"Your domains: {user.get('domains', [])}"
        )
    return True

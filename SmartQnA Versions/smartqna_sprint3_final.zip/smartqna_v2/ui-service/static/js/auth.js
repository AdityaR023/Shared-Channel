// ── auth.js — shared across all pages ────────────────────────────────
//
// JWT is stored in localStorage after login/signup.
// Every authFetch() call sends it in the Authorization header.
// Domain selection calls /api/auth/select-domains which issues a NEW token
// with updated active_domains — client replaces the old token.

// ── Token management ──────────────────────────────────────────────────

function getToken() {
  return localStorage.getItem("token");
}

function getUser() {
  const raw = localStorage.getItem("user");
  return raw ? JSON.parse(raw) : null;
}

function getUserDomains() {
  // All subscribed domains — set at signup, never changes
  const user = getUser();
  return user ? (user.domains || []) : [];
}

function getActiveDomains() {
  // Currently selected domains for querying — subset of subscribed
  const user = getUser();
  return user ? (user.active_domains || user.domains || []) : [];
}

function setSession(data) {
  // Store token and user info after login/signup/domain-select
  localStorage.setItem("token", data.access_token);
  if (data.user) {
    localStorage.setItem("user", JSON.stringify(data.user));
  }
}

function clearStorage() {
  ["token", "user"].forEach(k => localStorage.removeItem(k));
}

// ── Auth guard ────────────────────────────────────────────────────────

async function requireAuth() {
  const token = getToken();
  if (!token) {
    window.location.href = "/login";
    return false;
  }

  // Validate token with server
  try {
    const res = await fetch("/api/auth/me", {
      headers: { "Authorization": `Bearer ${token}` }
    });
    if (res.ok) {
      // Update stored user with latest from server
      const userData = await res.json();
      const stored   = getUser() || {};
      localStorage.setItem("user", JSON.stringify({ ...stored, ...userData }));
      return true;
    } else {
      // Token expired or invalid
      clearStorage();
      window.location.href = "/login";
      return false;
    }
  } catch {
    // Server unreachable — clear and redirect
    clearStorage();
    window.location.href = "/login";
    return false;
  }
}

// ── Authenticated fetch ───────────────────────────────────────────────

async function authFetch(url, options = {}) {
  const token = getToken();
  const headers = {
    ...options.headers,
    "Authorization": `Bearer ${token}`,
  };

  const response = await fetch(url, { ...options, headers });

  if (response.status === 401) {
    // Token expired — redirect to login
    clearStorage();
    window.location.href = "/login";
    return null;
  }

  if (response.status === 403) {
    // Domain access denied — show message but don't redirect
    console.warn("Domain access denied:", await response.text());
    return response;
  }

  return response;
}

// ── Domain selection ──────────────────────────────────────────────────
// Called when user picks which domains to query against
// Issues a new JWT with updated active_domains
// Client stores new token replacing the old one

async function selectActiveDomains(selectedDomains) {
  const response = await authFetch("/api/auth/select-domains", {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ active_domains: selectedDomains }),
  });

  if (!response || !response.ok) {
    const err = await response?.json();
    throw new Error(err?.detail || "Failed to update domain selection");
  }

  const data = await response.json();

  // Replace token with new one containing updated active_domains
  localStorage.setItem("token", data.access_token);

  // Update stored user
  const user = getUser() || {};
  user.active_domains = data.active_domains;
  localStorage.setItem("user", JSON.stringify(user));

  return data;
}

// ── UI helpers ────────────────────────────────────────────────────────

function populateNavbarUser() {
  const el   = document.getElementById("navbarUser");
  const user = getUser();
  if (el && user) {
    el.textContent = user.username || user.email || "";
  }
}

function populateDomainFilter(selector, includeAll = true) {
  const select = document.querySelector(selector);
  if (!select) return;

  // Use ACTIVE domains — not all subscribed domains
  // User only sees domains they've selected for this session
  const domains = getActiveDomains();

  select.innerHTML = "";

  if (includeAll) {
    const allOpt       = document.createElement("option");
    allOpt.value       = "";
    allOpt.textContent = "All active domains";
    select.appendChild(allOpt);
  }

  domains.forEach(domain => {
    const opt       = document.createElement("option");
    opt.value       = domain;
    opt.textContent = domain;
    select.appendChild(opt);
  });
}

function logout() {
  authFetch("/api/auth/logout", { method: "POST" })
    .finally(() => {
      clearStorage();
      window.location.href = "/login";
    });
}

function clearSessionAndStay(e) {
  if (e) e.preventDefault();
  clearStorage();
  window.location.reload();
}

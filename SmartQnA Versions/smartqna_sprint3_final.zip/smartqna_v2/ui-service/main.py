"""
SmartQnA — UI Service  Port: 8000
Real JWT: signup/login embed domains, select-domains issues new token
"""
import os, sys, json
import httpx
from typing import Optional, List
from fastapi import FastAPI, Request, UploadFile, File, Form, HTTPException, Query
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.responses import RedirectResponse, StreamingResponse
from pydantic import BaseModel
from dotenv import load_dotenv

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from logger   import get_logger
from auth_jwt import create_access_token, get_current_user

load_dotenv()
logger = get_logger("ui_service")

app = FastAPI(title="SmartQnA — UI Service", version="3.0.0")
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

SEARCH_URL      = os.getenv("SEARCH_SERVICE_URL",      "http://localhost:8001")
COMPLETIONS_URL = os.getenv("COMPLETIONS_SERVICE_URL", "http://localhost:8002")

from database import (
    init_db, create_user, get_user_by_email, verify_password, update_last_login,
    create_conversation, get_conversations, get_conversation_with_messages,
    delete_conversation, save_message, get_recent_messages, update_conversation_title,
)

@app.on_event("startup")
def startup():
    init_db()
    logger.info("UI service started.")

# ── Models ─────────────────────────────────────────────────────────────
class SignupRequest(BaseModel):
    username: str; email: str; password: str; domains: List[str]

class SelectDomainsRequest(BaseModel):
    active_domains: List[str]

class SearchRequest(BaseModel):
    query: str; top_k: int = 5
    domain_filter: Optional[str] = None; brand_filter: Optional[str] = None

class ChatRequest(BaseModel):
    query: str; conversation_id: Optional[str] = None
    active_domains: Optional[List[str]] = None
    brand_filter: Optional[str] = None; stream: bool = False

# ── Pages ──────────────────────────────────────────────────────────────
@app.get("/")
def root(): return RedirectResponse(url="/login")
@app.get("/login")
def login_page(r: Request): return templates.TemplateResponse("login.html", {"request":r})
@app.get("/signup")
def signup_page(r: Request): return templates.TemplateResponse("signup.html", {"request":r})
@app.get("/signup/success")
def success_page(r: Request): return templates.TemplateResponse("signup_success.html", {"request":r})
@app.get("/upload")
def upload_page(r: Request): return templates.TemplateResponse("documents.html", {"request":r})
@app.get("/chat")
def chat_page(r: Request): return templates.TemplateResponse("chat.html", {"request":r})
@app.get("/search")
def search_page(r: Request): return templates.TemplateResponse("search.html", {"request":r})
@app.get("/profile")
def profile_page(r: Request): return templates.TemplateResponse("profile.html", {"request":r})

# ── Health ─────────────────────────────────────────────────────────────
@app.get("/health")
async def health():
    status = {"ui":"ok","search":"unknown","completions":"unknown"}
    async with httpx.AsyncClient(timeout=3.0) as c:
        try:
            r=await c.get(f"{SEARCH_URL}/health"); status["search"]="ok" if r.status_code==200 else "degraded"
        except: status["search"]="down"
        try:
            r=await c.get(f"{COMPLETIONS_URL}/health"); status["completions"]="ok" if r.status_code==200 else "degraded"
        except: status["completions"]="down"
    return status

# ── Auth ───────────────────────────────────────────────────────────────
@app.get("/api/auth/me")
async def get_me(request: Request):
    return get_current_user(request)

@app.post("/api/auth/login")
async def login(request: Request):
    try:
        body=await request.json(); email=body.get("username",""); password=body.get("password","")
    except:
        form=await request.form(); email=form.get("username",""); password=form.get("password","")
    user = get_user_by_email(email)
    if not user or not verify_password(password, user["password_hash"]):
        logger.warning(f"Failed login: {email}")
        raise HTTPException(401, "Invalid email or password")
    update_last_login(user["id"])
    token = create_access_token(user["id"], user["email"], user["username"],
                                user["domains"], user["domains"])
    logger.info(f"Login: {email} | domains: {user['domains']}")
    return {"access_token":token,"token_type":"bearer",
            "user":{"id":user["id"],"email":user["email"],"username":user["username"],
                    "domains":user["domains"],"active_domains":user["domains"]}}

@app.post("/api/auth/signup")
async def signup(body: SignupRequest):
    if not body.domains:
        raise HTTPException(400, "Select at least one domain")
    try:
        user = create_user(body.username, body.email, body.password, body.domains)
    except ValueError as e:
        raise HTTPException(400, str(e))
    token = create_access_token(user["id"], user["email"], user["username"],
                                user["domains"], user["domains"])
    logger.info(f"Signup: {body.email} | domains: {body.domains}")
    return {"access_token":token,"token_type":"bearer",
            "api_key":user["api_key"],"api_secret":user["api_secret"],
            "user":{"id":user["id"],"email":user["email"],"username":user["username"],
                    "domains":user["domains"],"active_domains":user["domains"]}}

@app.post("/api/auth/logout")
async def logout(): return {"success": True}

@app.post("/api/auth/select-domains")
async def select_domains(body: SelectDomainsRequest, request: Request):
    """
    User picks which of their subscribed domains to query against.
    Issues a new JWT with active_domains updated.
    Client replaces stored token with the new one.
    """
    user = get_current_user(request)
    subscribed = user["domains"]
    invalid = [d for d in body.active_domains if d not in subscribed]
    if invalid:
        raise HTTPException(403, f"Not subscribed to: {invalid}. Your domains: {subscribed}")
    if not body.active_domains:
        raise HTTPException(400, "Select at least one domain")
    new_token = create_access_token(user["id"], user["email"], user["username"],
                                    subscribed, body.active_domains)
    logger.info(f"Domain selection: {user['email']} selected {body.active_domains}")
    return {"access_token":new_token,"token_type":"bearer",
            "active_domains":body.active_domains,"domains":subscribed}

# ── Profile ────────────────────────────────────────────────────────────
@app.get("/api/profile")
async def get_profile(request: Request):
    user    = get_current_user(request)
    db_user = get_user_by_email(user["email"])
    return {"id":user["id"],"username":user["username"],"email":user["email"],
            "domains":user["domains"],"active_domains":user["active_domains"],
            "api_key": db_user.get("api_key","") if db_user else ""}

# ── Ingest ─────────────────────────────────────────────────────────────
@app.post("/api/ingest")
async def ingest_proxy(file: UploadFile = File(...), request: Request = None):
    user = get_current_user(request)
    ext  = os.path.splitext(file.filename)[1].lower()
    if ext not in {".pdf",".csv",".html",".mhtml",".mht",".json"}:
        raise HTTPException(400, f"Unsupported file type '{ext}'")
    content = await file.read()
    try:
        async with httpx.AsyncClient(timeout=60.0) as c:
            r = await c.post(f"{SEARCH_URL}/generate-metadata",
                             files={"file":(file.filename, content, file.content_type)})
        data = r.json()
        logger.info(f"Upload by {user['email']}: {file.filename} | chunks:{data.get('total_chunks',0)}")
        return {"success":True,"filename":file.filename,"chunks_indexed":data.get("total_chunks",0)}
    except httpx.ConnectError:
        raise HTTPException(503, "Search service unavailable")

# ── Search ─────────────────────────────────────────────────────────────
@app.post("/api/search")
async def search_proxy(body: SearchRequest, request: Request):
    user           = get_current_user(request)
    active_domains = user["active_domains"]
    domain_filter  = body.domain_filter
    if domain_filter and domain_filter not in active_domains:
        raise HTTPException(403, f"'{domain_filter}' not in active domains: {active_domains}")
    logger.info(f"Search by {user['email']}: '{body.query}' | active:{active_domains}")
    try:
        async with httpx.AsyncClient(timeout=15.0) as c:
            r = await c.post(f"{SEARCH_URL}/search",
                             json={"query":body.query,"top_k":body.top_k,
                                   "domain_filter":domain_filter,"brand_filter":body.brand_filter})
        raw = r.json().get("results",[])
        translated = [{"content":x.get("answer",""),"source":x.get("file",""),
                       "file_name":x.get("file",""),"category":x.get("category",""),
                       "domain":x.get("category","").upper(),"score":x.get("score",0),
                       "chunk_id":x.get("chunk_id")} for x in raw]
        return {"query":body.query,"results":translated,"total":len(translated)}
    except httpx.ConnectError:
        raise HTTPException(503, "Search service unavailable")

# ── Chat ───────────────────────────────────────────────────────────────
@app.post("/api/chat")
async def chat_proxy(body: ChatRequest, request: Request):
    user           = get_current_user(request)
    active_domains = body.active_domains or user["active_domains"]
    if body.active_domains:
        invalid = [d for d in body.active_domains if d not in user["domains"]]
        if invalid:
            raise HTTPException(403, f"Not subscribed to: {invalid}")
    logger.info(f"Chat by {user['email']}: '{body.query[:60]}' | domains:{active_domains}")
    if body.conversation_id:
        conv    = get_conversation_with_messages(body.conversation_id, user["id"])
        if not conv: raise HTTPException(404,"Conversation not found")
        conv_id = body.conversation_id
    else:
        conv    = create_conversation(user["id"])
        conv_id = conv["id"]
        update_conversation_title(conv_id, body.query[:60])
    history = [{"role":m["role"],"content":m["content"]}
               for m in get_recent_messages(conv_id, limit=10)]
    save_message(conv_id, "user", body.query)
    payload = {"query":body.query,"history":history,"active_domains":active_domains,
               "user_domains":user["domains"],"brand_filter":body.brand_filter,"stream":body.stream}
    if body.stream:
        async def stream_and_save():
            full=""; sources=[]; conf=0.0
            try:
                async with httpx.AsyncClient(timeout=60.0) as c:
                    async with c.stream("POST",f"{COMPLETIONS_URL}/chat",json=payload) as resp:
                        async for line in resp.aiter_lines():
                            if not line.startswith("data: "): continue
                            data=line[6:].strip()
                            yield f"data: {data}\n\n"
                            if data=="[DONE]": break
                            try:
                                p=json.loads(data)
                                if p.get("type")=="meta": sources=p.get("sources",[]); conf=p.get("confidence",0)
                                elif p.get("token"): full+=p["token"]
                            except: pass
            except httpx.ConnectError:
                yield 'data: {"error":"Completions service unavailable"}\n\n'
                yield "data: [DONE]\n\n"; return
            if full: save_message(conv_id,"assistant",full,sources=sources,confidence=conf)
            yield f"data: {json.dumps({'type':'conv_id','conversation_id':conv_id})}\n\n"
        return StreamingResponse(stream_and_save(), media_type="text/event-stream",
                                 headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})
    try:
        async with httpx.AsyncClient(timeout=30.0) as c:
            resp=await c.post(f"{COMPLETIONS_URL}/chat",json=payload)
        data=resp.json()
    except httpx.ConnectError:
        raise HTTPException(503,"Completions service unavailable")
    if not data.get("guardrail_triggered"):
        save_message(conv_id,"assistant",data.get("answer",""),
                     sources=data.get("sources",[]),confidence=data.get("confidence",0.0))
    data["conversation_id"]=conv_id
    return data

# ── Conversations ──────────────────────────────────────────────────────
@app.get("/api/conversations")
async def list_convs(request: Request):
    user=get_current_user(request); return {"conversations":get_conversations(user["id"],30)}
@app.post("/api/conversations")
async def new_conv(request: Request):
    user=get_current_user(request); return create_conversation(user["id"])
@app.get("/api/conversations/{conv_id}")
async def get_conv(conv_id:str, request:Request):
    user=get_current_user(request)
    conv=get_conversation_with_messages(conv_id,user["id"])
    if not conv: raise HTTPException(404,"Not found")
    return conv
@app.delete("/api/conversations/{conv_id}")
async def del_conv(conv_id:str, request:Request):
    user=get_current_user(request); delete_conversation(conv_id,user["id"]); return {"success":True}

# ── Documents ──────────────────────────────────────────────────────────
@app.get("/api/documents")
async def list_docs(request:Request, search:Optional[str]=Query(None),
                    domain:Optional[str]=Query(None), type:Optional[str]=Query(None)):
    get_current_user(request)
    async with httpx.AsyncClient(timeout=10.0) as c:
        r=await c.get(f"{SEARCH_URL}/documents",params={"search":search,"domain":domain,"type":type})
    return r.json()

@app.delete("/api/documents/{doc_id:path}")
async def del_doc(doc_id:str, request:Request):
    get_current_user(request)
    async with httpx.AsyncClient(timeout=10.0) as c:
        r=await c.delete(f"{SEARCH_URL}/documents/{doc_id}")
    return r.json()

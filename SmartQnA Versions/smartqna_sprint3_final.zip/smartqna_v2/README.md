# SmartQnA — Sprint 3

## What Changed in This Version

### 1. Upload — No Manual Metadata
Upload a file and metadata is extracted automatically by Group A's service.
No brand, model, generation fields to fill in manually.
Supported formats: PDF, CSV, HTML, MHTML, JSON

### 2. Profile — Real Domains
Assigned domains on the profile page now show exactly what the
user selected during signup — pulled from the SQLite database.

### 3. Logging
All three services log to `logs/app.log` using a shared rotating file logger.
Each log line shows: timestamp | level | service name | message

Example:
```
2024-01-15 10:23:45 | INFO     | ui_service           | User logged in: test@example.com | domains: ['4G', '5G']
2024-01-15 10:23:46 | INFO     | completions_service  | Chat request: 'Does S24 have 5G?' | stream:True
2024-01-15 10:23:47 | INFO     | completions_service  | Search returned 3 chunks
2024-01-15 10:23:49 | INFO     | completions_service  | Streamed response cached | confidence:0.87
```

---

## Project Structure

```
smartqna/
├── ui-service/
│   ├── main.py              ← page routes + API proxies
│   ├── database.py          ← SQLite — users, conversations, messages
│   ├── templates/
│   │   ├── documents.html   ← simplified upload (no metadata form)
│   │   ├── profile.html
│   │   └── chat.html
│   ├── static/
│   │   ├── js/
│   │   │   ├── documents.js ← file-only upload
│   │   │   ├── profile.js   ← loads real domains from /api/profile
│   │   │   ├── chat.js      ← streaming + multi-turn
│   │   │   └── auth.js
│   │   └── css/
│   └── requirements.txt
│
├── completions-service/
│   └── main.py              ← RAG + LLM + guardrails + logging
│
├── search-service/          ← Group A's Flask app lives here
│   └── app.py               ← run with: python app.py
│
├── evaluation/
│   ├── eval_dataset.json
│   └── run_eval.py
│
├── logs/
│   └── app.log              ← all service logs go here
│
├── logger.py                ← shared logger module
├── .env                     ← credentials and config
└── README.md
```

---

## How to Run

### Step 1 — Set credentials
```bash
# Edit .env and add your LLM API key
LLM_API_KEY=your_actual_key_here
```

### Step 2 — Start Group A's Search Service (Flask)
```bash
cd search-service
pip install -r requirements.txt
python app.py
# Runs on http://localhost:5000
```

### Step 3 — Start Completions Service
```bash
cd completions-service
pip install -r requirements.txt
uvicorn main:app --port 8002 --reload
```

### Step 4 — Start UI Service
```bash
cd ui-service
pip install -r requirements.txt
uvicorn main:app --port 8000 --reload
```

### Step 5 — Open the app
```
http://localhost:8000
```

### Step 6 — Check all services
```
http://localhost:8000/health
```

Expected response:
```json
{"ui": "ok", "search": "ok", "completions": "ok"}
```

---

## View Logs
```bash
# Live log tail
tail -f logs/app.log

# Last 50 lines
tail -n 50 logs/app.log

# Filter by service
grep "ui_service" logs/app.log
grep "completions" logs/app.log
grep "ERROR" logs/app.log
```

---

## Run Evaluation
```bash
cd evaluation
python run_eval.py

# Filter by category
python run_eval.py --category 5G
```

---

## Key Integration Points

Group A's Flask search service (`/generate-metadata`) now handles:
- Saving the uploaded file to the correct `Data/` subfolder
- Extracting metadata automatically (no user input needed)
- Indexing into ChromaDB
- Clearing search cache

Your UI just sends the file — no metadata fields required.

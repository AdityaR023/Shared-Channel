"""
SmartQnA — Shared Logger
Place this file at the project root.
All services import it regardless of which directory they run from.

Usage in any service file:
    import sys, os
    sys.path.append(os.path.join(os.path.dirname(__file__), ".."))
    from logger import get_logger
    logger = get_logger(__name__)
"""

import logging
import os
from logging.handlers import RotatingFileHandler

# ── Resolve project root absolutely ───────────────────────────────────
# __file__ = /path/to/smartqna/logger.py
# PROJECT_ROOT = /path/to/smartqna/
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))

# logs/ folder and app.log always resolve to project root
# regardless of which directory the service is launched from
LOG_DIR  = os.path.join(PROJECT_ROOT, "logs")
LOG_FILE = os.path.join(LOG_DIR, "app.log")

LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")

os.makedirs(LOG_DIR, exist_ok=True)

# ── Format ────────────────────────────────────────────────────────────
FORMATTER = logging.Formatter(
    fmt    = "%(asctime)s | %(levelname)-8s | %(name)-22s | %(message)s",
    datefmt= "%Y-%m-%d %H:%M:%S"
)


def get_logger(name: str) -> logging.Logger:
    """
    Returns a named logger that writes to both console and
    project-root/logs/app.log — always, regardless of CWD.

    Call at the top of any module:
        logger = get_logger(__name__)
    """
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger   # already configured, don't add duplicate handlers

    logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

    # ── Console ───────────────────────────────────────────────────────
    console = logging.StreamHandler()
    console.setFormatter(FORMATTER)
    logger.addHandler(console)

    # ── Rotating file → logs/app.log ──────────────────────────────────
    # Max 5MB per file, keep last 3 backup files
    file_handler = RotatingFileHandler(
        LOG_FILE,
        maxBytes   = 5 * 1024 * 1024,
        backupCount= 3,
        encoding   = "utf-8"
    )
    file_handler.setFormatter(FORMATTER)
    logger.addHandler(file_handler)

    logger.propagate = False
    return logger

"""
SmartQnA — ChromaDB Client
Shared across indexing and search services.
"""

import chromadb
from chromadb.utils import embedding_functions
import sys, os

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from logger import get_logger

logger = get_logger("search_service.chroma")

embedding_function = embedding_functions.DefaultEmbeddingFunction()

client = chromadb.PersistentClient(path="./chroma_db")

collection = client.get_or_create_collection(
    name="mobile_data",
    embedding_function=embedding_function
)

logger.info("ChromaDB client initialised. Collection: mobile_data")

"""
SmartQnA — Text Extractor
Extracts raw text from PDF, CSV, HTML, JSON files.
"""

import json
from pathlib import Path

import pandas as pd
from bs4 import BeautifulSoup
from PyPDF2 import PdfReader


def extract_text(file_path) -> str | None:
    ext = Path(file_path).suffix.lower()

    try:
        if ext == ".csv":
            df = pd.read_csv(file_path)
            return df.to_string()

        elif ext == ".json":
            with open(file_path, "r", encoding="utf-8") as f:
                return json.dumps(json.load(f), indent=2)

        elif ext in [".html", ".mhtml", ".mht"]:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                soup = BeautifulSoup(f.read(), "html.parser")
                return soup.get_text()

        elif ext == ".pdf":
            reader = PdfReader(file_path)
            text   = ""
            for page in reader.pages:
                text += page.extract_text() or ""
            return text

        else:
            return None

    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return None

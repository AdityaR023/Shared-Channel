"""
SmartQnA — Category Classifier
Detects 2G/3G/4G/5G category from file path and metadata.
"""

import json


def detect_category(file_path, metadata: dict) -> str:
    text = str(file_path).lower() + json.dumps(metadata).lower()

    if "2g" in text:
        return "2g"
    elif "3g" in text:
        return "3g"
    elif "4g" in text:
        return "4g"
    elif "5g" in text:
        return "5g"
    elif "review" in text:
        return "reviews"
    elif "sale" in text or "price" in text:
        return "sales"
    else:
        return "unknown"

"""
SmartQnA — Metadata Service
Single-file metadata extraction from Group A's generate_metadata_file.py.
Saves to type-based subfolders and updates file_mapping.json.
"""

import os
import json
import sys
from pathlib import Path

import pandas as pd

try:
    import PyPDF2
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from logger import get_logger

logger = get_logger("search_service.metadata")

file_mapping = {}


def create_metadata_json(file_path, metadata: dict, data_folder="Data") -> dict:
    """Save metadata JSON and update file_mapping."""
    base_output_dir = "metadata"

    absolute_path  = Path(file_path).resolve()
    base_data_path = Path(data_folder).resolve()
    relative_path  = absolute_path.relative_to(base_data_path)

    output_dir = os.path.join(base_output_dir, str(relative_path.parent))
    os.makedirs(output_dir, exist_ok=True)

    file_name   = relative_path.stem
    output_file = os.path.join(output_dir, f"{file_name}_metadata.json")

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=4)

    rel_str      = str(relative_path)
    meta_rel_str = str(Path(output_dir) / f"{file_name}_metadata.json")

    file_mapping[rel_str] = meta_rel_str

    return {"file_path": rel_str, "metadata_file_path": meta_rel_str}


def extract_csv_schema(file_path, data_folder="Data") -> dict:
    df     = pd.read_csv(file_path)
    result = {
        "file_name":    Path(file_path).stem,
        "type":         "csv",
        "row_count":    len(df),
        "column_count": len(df.columns),
        "columns": [
            {"name": col, "datatype": str(df[col].dtype),
             "non_null_count": int(df[col].count())}
            for col in df.columns
        ]
    }
    return create_metadata_json(file_path, result, data_folder)


def extract_mhtml_schema(file_path, data_folder="Data") -> dict:
    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read(5000)
    result = {
        "file_name":        Path(file_path).stem,
        "type":             "mhtml",
        "contains_html":    "<html" in content.lower(),
        "contains_tables":  "<table" in content.lower(),
        "contains_images":  "image/" in content.lower(),
    }
    return create_metadata_json(file_path, result, data_folder)


def extract_pdf_metadata(file_path, data_folder="Data") -> dict:
    if not PDF_SUPPORT:
        logger.warning(f"PyPDF2 not installed — basic metadata only for: {file_path}")
        result = {"file_name": Path(file_path).stem, "type": "pdf"}
        return create_metadata_json(file_path, result, data_folder)

    with open(file_path, "rb") as f:
        reader   = PyPDF2.PdfReader(f)
        metadata = reader.metadata
        result   = {
            "file_name":  Path(file_path).stem,
            "type":       "pdf",
            "page_count": len(reader.pages),
            "document_info": {
                "title":    metadata.title    if metadata else None,
                "author":   metadata.author   if metadata else None,
                "creator":  metadata.creator  if metadata else None,
                "producer": metadata.producer if metadata else None,
                "subject":  metadata.subject  if metadata else None,
            }
        }
    return create_metadata_json(file_path, result, data_folder)


def extract_json_schema(file_path, data_folder="Data") -> dict:
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    record_count = len(data) if isinstance(data, list) else 1
    result = {
        "file_name":      Path(file_path).stem,
        "type":           "json",
        "record_count":   record_count,
        "structure_type": type(data).__name__,
    }
    return create_metadata_json(file_path, result, data_folder)


def generate_metadata_for_file(
    file_path:    str,
    mapping_file: str = "file_mapping.json",
    data_folder:  str = "Data",
) -> dict:
    """
    Generate metadata for a single file.
    Skips if already in mapping.
    Updates file_mapping.json.
    Returns { file_path, metadata_file_path, processed, skipped }
    """
    global file_mapping
    os.makedirs("metadata", exist_ok=True)

    # Load existing mapping
    if os.path.exists(mapping_file):
        with open(mapping_file, "r") as f:
            file_mapping.update(json.load(f))

    absolute_path = Path(file_path).resolve()
    ext           = absolute_path.suffix.lower()

    try:
        relative_path = str(absolute_path.relative_to(Path(data_folder).resolve()))
    except Exception:
        logger.error(f"File not inside data folder: {file_path}")
        return {"file_path": None, "metadata_file_path": None,
                "processed": 0, "skipped": 0}

    # Skip if already processed
    if relative_path in file_mapping:
        logger.info(f"Metadata already exists, skipping: {relative_path}")
        meta_path = file_mapping[relative_path]
        with open(mapping_file, "w") as f:
            json.dump(file_mapping, f, indent=4)
        return {"file_path": relative_path, "metadata_file_path": meta_path,
                "processed": 0, "skipped": 1}

    # Process file
    res = None
    try:
        if ext == ".csv":
            res = extract_csv_schema(str(absolute_path), data_folder)
        elif ext == ".json":
            res = extract_json_schema(str(absolute_path), data_folder)
        elif ext in [".html", ".mhtml", ".mht"]:
            res = extract_mhtml_schema(str(absolute_path), data_folder)
        elif ext == ".pdf":
            res = extract_pdf_metadata(str(absolute_path), data_folder)
        else:
            logger.warning(f"Unsupported file type: {ext}")
            return {"file_path": None, "metadata_file_path": None,
                    "processed": 0, "skipped": 1}

        logger.info(f"Metadata generated for: {relative_path}")

    except Exception as e:
        logger.error(f"Error generating metadata for {relative_path}: {e}")
        return {"file_path": None, "metadata_file_path": None,
                "processed": 0, "skipped": 0}

    # Save updated mapping
    with open(mapping_file, "w") as f:
        json.dump(file_mapping, f, indent=4)

    return {
        "file_path":          res["file_path"] if res else None,
        "metadata_file_path": res["metadata_file_path"] if res else None,
        "processed":          1,
        "skipped":            0,
    }

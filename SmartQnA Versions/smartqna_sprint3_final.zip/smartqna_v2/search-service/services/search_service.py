"""
SmartQnA — Search Service
Full 10-step hybrid search pipeline from Group A's logic,
converted to work within FastAPI search service.
"""

import time
import sys
import os

from db.chroma_client import collection

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from logger import get_logger

logger = get_logger("search_service.search")

# ── Cache ─────────────────────────────────────────────────────────────
search_cache = {}
CACHE_TTL    = 3000   # 50 minutes — matches Group A


def normalize_query(query: str) -> str:
    return query.lower().strip()


def get_cache(key: str):
    entry = search_cache.get(key)
    if not entry:
        return None
    if time.time() - entry["time"] > CACHE_TTL:
        del search_cache[key]
        return None
    return entry["data"]


def set_cache(key: str, value):
    search_cache[key] = {"data": value, "time": time.time()}


def clear_search_cache():
    search_cache.clear()
    logger.info("Search cache cleared")


# ── Step 1: Vector search ─────────────────────────────────────────────
def vector_search(query: str, n_results: int = 20, domain_filter: str = None) -> list:
    """
    Query ChromaDB for semantically similar chunks.
    Optionally filter by domain/category.
    """
    where = None
    if domain_filter:
        where = {"category": domain_filter.lower()}

    results = collection.query(
        query_texts=[query],
        n_results=n_results,
        include=["documents", "metadatas", "distances"],
        where=where,
    )

    output = []
    for i in range(len(results["documents"][0])):
        output.append({
            "document": results["documents"][0][i],
            "metadata": results["metadatas"][0][i],
            "score":    results["distances"][0][i],
        })

    return output


# ── Step 2: Normalize scores ──────────────────────────────────────────
def normalize_scores(results: list) -> list:
    """
    Convert ChromaDB distance (lower=better) to relevance score (higher=better).
    Formula: 1 / (1 + distance)  — Group A's approach
    """
    for r in results:
        r["score"] = 1 / (1 + r["score"])
    return results


# ── Step 3: Keyword boost ─────────────────────────────────────────────
def keyword_boost(query: str, results: list) -> list:
    """
    Add +0.05 to score for each query word found in the document.
    Rewards exact keyword matches on top of semantic similarity.
    """
    query_words = query.lower().split()
    for r in results:
        text    = r["document"].lower()
        matches = sum(1 for word in query_words if word in text)
        r["score"] += matches * 0.05
    return results


# ── Step 4: Phrase boost ──────────────────────────────────────────────
def phrase_boost(query: str, results: list) -> list:
    """
    Add +0.2 if the full query phrase appears verbatim in the document.
    Strongly rewards exact phrase matches.
    """
    query_lower = query.lower()
    for r in results:
        if query_lower in r["document"].lower():
            r["score"] += 0.2
    return results


# ── Step 5: Deduplicate ───────────────────────────────────────────────
def deduplicate(results: list) -> list:
    """
    Remove duplicate chunks — same file + same chunk_id.
    Prevents the same paragraph appearing multiple times.
    """
    seen   = set()
    unique = []
    for r in results:
        key = (r["metadata"]["file_name"], r["metadata"]["chunk_id"])
        if key not in seen:
            seen.add(key)
            unique.append(r)
    return unique


# ── Step 6: Limit per file ────────────────────────────────────────────
def limit_per_file(results: list, limit: int = 2) -> list:
    """
    Allow max 2 chunks per source file.
    Prevents one large document from dominating all results.
    """
    file_count = {}
    final      = []
    for r in results:
        fname = r["metadata"].get("file_name")
        if file_count.get(fname, 0) < limit:
            final.append(r)
            file_count[fname] = file_count.get(fname, 0) + 1
    return final


# ── Step 7: Score filter ──────────────────────────────────────────────
def filter_by_score(results: list, min_score: float = 0.6) -> list:
    """
    Remove results below minimum quality threshold.
    Falls back to all results if nothing passes (avoids empty returns).
    """
    filtered = [r for r in results if r["score"] >= min_score]
    return filtered if filtered else results


# ── Main: hybrid search (10 steps) ────────────────────────────────────
def hybrid_search(
    query:         str,
    top_k:         int  = 5,
    domain_filter: str  = None,
    brand_filter:  str  = None,
) -> list:
    """
    Full hybrid search pipeline — Group A's 10-step approach.

    Steps:
      1. Vector search (semantic — ChromaDB embeddings)
      2. Normalize scores (distance → relevance)
      3. Keyword boost (+0.05 per matching word)
      4. Phrase boost (+0.2 for exact phrase match)
      5. Deduplicate (same chunk appearing twice)
      6. Limit per file (max 2 chunks per source)
      7. Filter by score (min 0.6 threshold)
      8. Sort descending by score
      9. Take top_k
      10. Format output

    Returns list of dicts with:
      answer, file, category, score, chunk_id, file_name
    """
    normalized = normalize_query(query)
    cache_key  = f"{normalized}_{top_k}_{domain_filter}_{brand_filter}"

    # ── Check cache ───────────────────────────────────────────────────
    cached = get_cache(cache_key)
    if cached:
        logger.info(f"Cache HIT for query: '{query[:60]}'")
        return cached

    logger.info(f"Cache MISS — running hybrid search for: '{query[:60]}'")

    # ── Step 1: Vector search ─────────────────────────────────────────
    results = vector_search(query, n_results=top_k * 4, domain_filter=domain_filter)

    if not results:
        logger.warning(f"No vector search results for: '{query[:60]}'")
        return []

    # ── Steps 2–9 ─────────────────────────────────────────────────────
    results = normalize_scores(results)
    results = keyword_boost(query, results)
    results = phrase_boost(query, results)
    results = deduplicate(results)
    results = limit_per_file(results, limit=2)
    results = filter_by_score(results, min_score=0.6)
    results.sort(key=lambda x: x["score"], reverse=True)
    results = results[:top_k]

    # ── Step 10: Format output ────────────────────────────────────────
    output = []
    for r in results:
        meta = r["metadata"]

        # Apply brand filter post-search if specified
        # (ChromaDB doesn't store brand separately so we filter here)
        if brand_filter:
            file_name = meta.get("file_name", "").lower()
            if brand_filter.lower() not in file_name:
                continue

        output.append({
            "answer":    r["document"].strip(),  # "answer" to match Group A's shape
            "file":      meta.get("file_name", ""),
            "file_name": meta.get("file_name", ""),
            "category":  meta.get("category", ""),
            "score":     round(r["score"], 4),
            "chunk_id":  meta.get("chunk_id"),
            "file_path": meta.get("file_path", ""),
        })

    logger.info(
        f"Hybrid search complete | query: '{query[:60]}' | "
        f"results: {len(output)} | domain: {domain_filter}"
    )

    set_cache(cache_key, output)
    return output

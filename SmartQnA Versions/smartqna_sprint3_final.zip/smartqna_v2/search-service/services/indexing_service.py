"""
SmartQnA — Indexing Service
Single-file indexing logic from Group A, converted to FastAPI service.
Only indexes the newly uploaded file — never re-indexes everything.
"""

import json
import os
import sys
from pathlib import Path

from langchain_text_splitters import RecursiveCharacterTextSplitter

from db.chroma_client import collection
from utils.extractor import extract_text
from utils.classifier import detect_category

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", ".."))
from logger import get_logger

logger = get_logger("search_service.indexing")


def clean_text(text: str) -> str:
    text = text.replace("\n", " ")
    text = text.replace("\t", " ")
    text = " ".join(text.split())
    return text.strip()


def format_markdown(text: str) -> str:
    text = text.replace("NETWORK",  "\n## Network\n")
    text = text.replace("LAUNCH",   "\n## Launch\n")
    text = text.replace("BODY",     "\n## Body\n")
    text = text.replace("DISPLAY",  "\n## Display\n")
    text = text.replace("PLATFORM", "\n## Platform\n")
    text = text.replace("BATTERY",  "\n## Battery\n")
    text = "\n".join(line.strip() for line in text.split("\n") if line.strip())
    return text.strip()


def split_text(text: str) -> list:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=50,
        separators=["\n## ", "\n\n", "\n", ".", " ", ""]
    )
    return splitter.split_text(text)


def index_single_file(
    file_path:    str,
    mapping_file: str = "file_mapping.json",
    data_folder:  str = "Data",
) -> int:
    """
    Index a single file into ChromaDB.
    Only processes the given file — never re-indexes everything.
    Returns number of chunks indexed.
    """
    # Load mapping
    try:
        with open(mapping_file, "r", encoding="utf-8") as f:
            file_mapping = json.load(f)
    except Exception as e:
        logger.error(f"Mapping file not found: {e}")
        return 0

    file_path   = Path(file_path).resolve()
    data_folder = Path(data_folder).resolve()

    # Get relative path — must match mapping key format
    try:
        rel_path = str(file_path.relative_to(data_folder))
        rel_path = rel_path.replace("/", "\\")   # match Group A's mapping format
    except Exception as e:
        logger.error(f"File not inside Data folder: {file_path}")
        return 0

    # Get metadata path from mapping
    meta_path = file_mapping.get(rel_path)
    if not meta_path:
        logger.warning(f"No metadata found for: {rel_path}")
        return 0

    meta_path = meta_path.replace("\\", "/")

    logger.info(f"Indexing: {file_path.name}")

    # Load metadata
    try:
        with open(meta_path, "r", encoding="utf-8") as f:
            metadata = json.load(f)
    except Exception as e:
        logger.warning(f"Could not read metadata: {e}")
        metadata = {}

    # Extract text
    content = extract_text(file_path)
    if not content:
        logger.warning(f"No content extracted from: {file_path.name}")
        return 0

    content = clean_text(content)
    if len(content) < 50:
        logger.warning(f"Content too short, skipping: {file_path.name}")
        return 0

    content  = format_markdown(content)
    category = detect_category(file_path, metadata)
    chunks   = split_text(content)

    logger.info(
        f"Chunked '{file_path.name}' into {len(chunks)} chunks | "
        f"category: {category}"
    )

    # Batch insert into ChromaDB
    BATCH_SIZE   = 20
    total_chunks = 0

    for i in range(0, len(chunks), BATCH_SIZE):
        batch = chunks[i:i + BATCH_SIZE]
        ids, documents, metadatas = [], [], []

        for j, chunk in enumerate(batch):
            chunk_index = i + j
            chunk_id    = f"{rel_path}_{chunk_index}"

            # Check if already indexed — skip duplicates
            existing = collection.get(ids=[chunk_id])
            if existing["ids"]:
                continue

            doc = f"# {file_path.name}\nCategory: {category}\n\n{chunk}"

            ids.append(chunk_id)
            documents.append(doc)
            metadatas.append({
                "category":  category,
                "file_type": file_path.suffix.lower(),
                "file_name": file_path.name,
                "file_path": str(file_path),
                "chunk_id":  chunk_index,
            })

        if not ids:
            continue

        try:
            collection.add(ids=ids, documents=documents, metadatas=metadatas)
            total_chunks += len(ids)
        except Exception as e:
            logger.error(f"ChromaDB batch insert error: {e}")
            continue

    logger.info(f"Indexed {total_chunks} chunks for: {file_path.name}")
    return total_chunks

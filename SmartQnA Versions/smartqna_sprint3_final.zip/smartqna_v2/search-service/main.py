"""
SmartQnA — Search Service
Port: 8001

Group A's search logic fully integrated into FastAPI.
Handles: file upload, metadata extraction, indexing, hybrid search.
"""

import os
import sys
import shutil
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

sys.path.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
from logger import get_logger

from services.search_service   import hybrid_search, clear_search_cache
from services.metadata_service import generate_metadata_for_file
from services.indexing_service import index_single_file
from db.chroma_client          import collection

logger = get_logger("search_service")

# ── App ───────────────────────────────────────────────────────────────
app = FastAPI(title="SmartQnA — Search Service", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8000"],
    allow_methods=["*"],
    allow_headers=["*"],
)

os.makedirs("Data",     exist_ok=True)
os.makedirs("metadata", exist_ok=True)

@app.on_event("startup")
def startup():
    logger.info("Search service started on port 8001")


# ── Models ────────────────────────────────────────────────────────────
class SearchRequest(BaseModel):
    query:         str
    top_k:         int           = 5
    domain_filter: Optional[str] = None
    brand_filter:  Optional[str] = None


# ── Health ────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok", "service": "search", "version": "2.0.0"}


# ── Upload + metadata + index ─────────────────────────────────────────
@app.post("/generate-metadata")
async def generate_metadata_endpoint(file: UploadFile = File(...)):
    """
    Accepts a file upload:
    1. Saves to correct Data/ subfolder by type
    2. Generates metadata JSON
    3. Indexes into ChromaDB
    4. Clears search cache

    No manual metadata required — everything extracted automatically.
    Matches Group A's /generate-metadata endpoint behaviour.
    """
    ext = os.path.splitext(file.filename)[1].lower()

    # Map extension to subfolder — matches Group A's logic
    folder_map = {
        ".csv":   "Data/CSV",
        ".pdf":   "Data/PDF",
        ".html":  "Data/HTML",
        ".mhtml": "Data/HTML",
        ".mht":   "Data/HTML",
        ".json":  "Data/JSON",
    }

    target_folder = folder_map.get(ext)
    if not target_folder:
        logger.warning(f"Unsupported file type rejected: {file.filename}")
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{ext}'. Allowed: CSV, PDF, HTML, JSON"
        )

    os.makedirs(target_folder, exist_ok=True)
    target_path = os.path.join(target_folder, file.filename)

    # Save file — skip if already exists
    if not os.path.exists(target_path):
        content = await file.read()
        with open(target_path, "wb") as f:
            f.write(content)
        logger.info(f"File saved: {target_path}")
    else:
        logger.info(f"File already exists, skipping save: {target_path}")

    # Generate metadata
    result = generate_metadata_for_file(target_path, data_folder="Data")

    total_chunks = 0

    # Index if metadata was generated successfully
    if result["file_path"] and result["processed"] == 1:
        total_chunks = index_single_file(target_path, data_folder="Data")
        clear_search_cache()

    logger.info(
        f"Upload complete: {file.filename} | "
        f"chunks: {total_chunks} | skipped: {result['skipped']}"
    )

    return {
        "status":             "success",
        "filename":           file.filename,
        "file_path":          result["file_path"],
        "metadata_file_path": result["metadata_file_path"],
        "processed":          result["processed"],
        "skipped":            result["skipped"],
        "total_chunks":       total_chunks,
        # UI-friendly alias
        "success":            True,
        "chunks_indexed":     total_chunks,
    }


# ── Search ────────────────────────────────────────────────────────────
@app.post("/search")
async def search_endpoint(body: SearchRequest):
    """
    Hybrid search using Group A's 10-step pipeline:
    vector search → normalize → keyword boost → phrase boost →
    deduplicate → limit per file → score filter → sort → top_k → format
    """
    if not body.query or not body.query.strip():
        raise HTTPException(status_code=422, detail="query cannot be empty")

    results = hybrid_search(
        query         = body.query,
        top_k         = body.top_k,
        domain_filter = body.domain_filter,
        brand_filter  = body.brand_filter,
    )

    return {
        "status":  "success",
        "query":   body.query,
        "results": results,
        "total":   len(results),
    }


# ── Validate ──────────────────────────────────────────────────────────
@app.post("/search/validate")
async def validate_endpoint(body: SearchRequest):
    """Return only high-confidence results (score >= 0.7)."""
    if not body.query or not body.query.strip():
        raise HTTPException(status_code=422, detail="query cannot be empty")

    all_results   = hybrid_search(body.query, top_k=10)
    valid_results = [r for r in all_results if r["score"] >= 0.7]

    return {
        "query":         body.query,
        "valid_results": valid_results,
        "total_results": len(all_results),
        "valid_count":   len(valid_results),
    }


# ── Documents list ────────────────────────────────────────────────────
@app.get("/documents")
async def list_documents(
    search: Optional[str] = Query(None),
    domain: Optional[str] = Query(None),
    type:   Optional[str] = Query(None),
):
    """List all indexed documents from ChromaDB."""
    try:
        all_items = collection.get(include=["metadatas"])
        metadatas = all_items.get("metadatas", [])

        seen = set()
        docs = []

        for meta in metadatas:
            fp = meta.get("file_path", "")
            if fp in seen:
                continue
            seen.add(fp)

            category  = meta.get("category", "")
            file_type = meta.get("file_type", "").replace(".", "")

            if domain and category.lower() != domain.lower():
                continue
            if type and file_type.lower() != type.lower():
                continue
            if search and search.lower() not in meta.get("file_name","").lower():
                continue

            docs.append({
                "id":           fp,
                "model":        meta.get("file_name", ""),
                "generation":   category.upper(),
                "domain":       category.upper(),
                "source":       fp,
                "content_type": file_type,
                "uploaded_at":  None,
            })

        return {"documents": docs, "total": len(docs)}

    except Exception as e:
        logger.error(f"Error listing documents: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ── Delete document ───────────────────────────────────────────────────
@app.delete("/documents/{doc_id:path}")
async def delete_document(doc_id: str):
    """Delete all chunks for a file from ChromaDB and remove from disk."""
    try:
        results       = collection.get(where={"file_path": doc_id}, include=["metadatas"])
        ids_to_delete = results.get("ids", [])

        if ids_to_delete:
            collection.delete(ids=ids_to_delete)
            logger.info(f"Deleted {len(ids_to_delete)} chunks for: {doc_id}")

        if os.path.exists(doc_id):
            os.remove(doc_id)

        clear_search_cache()
        return {"success": True, "id": doc_id, "chunks_deleted": len(ids_to_delete)}

    except Exception as e:
        logger.error(f"Error deleting document: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ── Cache management ──────────────────────────────────────────────────
@app.post("/cache/clear")
def clear_cache():
    clear_search_cache()
    return {"status": "cache cleared"}

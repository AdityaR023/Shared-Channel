// ── Redirect if already logged in ────────────────────────────────────
if (localStorage.getItem("token")) {
  window.location.href = "/chat";
}

// ── Element references ────────────────────────────────────────────────
const loginForm  = document.getElementById("loginForm");
const emailInput = document.getElementById("email");
const passInput  = document.getElementById("password");
const loginBtn   = document.getElementById("loginBtn");
const errorAlert = document.getElementById("errorAlert");
const emailError = document.getElementById("emailError");
const passError  = document.getElementById("passwordError");
const tiles      = document.querySelectorAll(".domain-tile");
const domainTileError = document.getElementById("domainTileError");

// ── Domain tile selection ─────────────────────────────────────────────
// Tracks which domain tile the user clicked
let selectedDomain = null;

tiles.forEach(tile => {
  tile.addEventListener("click", () => {
    // Remove selected from all tiles first
    tiles.forEach(t => t.classList.remove("selected"));
    // Select this one
    tile.classList.add("selected");
    selectedDomain = tile.dataset.domain;
    domainTileError.style.display = "none";

    // Also sync the generation dropdown if domain matches a generation
    const genMap = { "2G": "2G", "3G": "3G", "4G": "4G", "5G": "5G" };
    if (genMap[selectedDomain]) {
      document.getElementById("generation").value = genMap[selectedDomain];
    }
  });
});

// ── Form submit ───────────────────────────────────────────────────────
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearErrors();

  const email    = emailInput.value.trim();
  const password = passInput.value.trim();
  const generation = document.getElementById("generation").value;
  let valid = true;

  // Validate domain tile selection
  if (!selectedDomain) {
    domainTileError.style.display = "block";
    valid = false;
  }
  if (!email || !isValidEmail(email)) {
    showFieldError(emailInput, emailError);
    valid = false;
  }
  if (!password) {
    showFieldError(passInput, passError);
    valid = false;
  }
  if (!valid) return;

  setLoading(true);

  try {
    const formData = new URLSearchParams();
    formData.append("username",   email);
    formData.append("password",   password);
    formData.append("domain",     selectedDomain);
    formData.append("generation", generation || "");

    const response = await fetch("/api/auth/login", {
      method:  "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body:    formData,
    });

    const data = await response.json();

    if (response.ok) {
      localStorage.setItem("token",   data.access_token);
      localStorage.setItem("user",    JSON.stringify(data.user));
      localStorage.setItem("domains", JSON.stringify(data.user.domains));
      window.location.href = "/chat";
    } else {
      showAlert(data.detail || "Invalid credentials. Please try again.");
    }
  } catch {
    showAlert("Could not reach the server. Please try again.");
  } finally {
    setLoading(false);
  }
});

// ── Helpers ───────────────────────────────────────────────────────────
function isValidEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

function showFieldError(input, el) {
  input.classList.add("error");
  el.classList.add("visible");
}

function clearErrors() {
  [emailInput, passInput].forEach(el => el.classList.remove("error"));
  [emailError, passError].forEach(el => el.classList.remove("visible"));
  errorAlert.classList.remove("visible");
  errorAlert.textContent = "";
  domainTileError.style.display = "none";
}

function showAlert(msg) {
  errorAlert.textContent = msg;
  errorAlert.classList.add("visible");
}

function setLoading(loading) {
  loginBtn.disabled  = loading;
  loginBtn.innerHTML = loading
    ? '<span class="spinner"></span> Signing in...'
    : "Continue";
}

// ── Element references ────────────────────────────────────────────────
const signupForm      = document.getElementById("signupForm");
const usernameInput   = document.getElementById("username");
const emailInput      = document.getElementById("email");
const passInput       = document.getElementById("password");
const confirmInput    = document.getElementById("confirmPassword");
const signupBtn       = document.getElementById("signupBtn");
const errorAlert      = document.getElementById("errorAlert");
const successAlert    = document.getElementById("successAlert");

// ── Form submit ───────────────────────────────────────────────────────
signupForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearErrors();

  const username = usernameInput.value.trim();
  const email    = emailInput.value.trim();
  const password = passInput.value.trim();
  const confirm  = confirmInput.value.trim();
  let valid = true;

  if (!username) {
    showFieldError(usernameInput, "usernameError"); valid = false;
  }
  if (!email || !isValidEmail(email)) {
    showFieldError(emailInput, "emailError"); valid = false;
  }
  if (!password || password.length < 8) {
    showFieldError(passInput, "passwordError"); valid = false;
  }
  if (confirm !== password) {
    showFieldError(confirmInput, "confirmError"); valid = false;
  }
  if (!valid) return;

  setLoading(true);

  try {
    const response = await fetch("/api/auth/signup", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password, domains: [] }),
    });

    const data = await response.json();

    if (response.ok) {
      localStorage.setItem("token",   data.access_token);
      localStorage.setItem("user",    JSON.stringify(data.user));
      localStorage.setItem("domains", JSON.stringify(data.user.domains || []));
      localStorage.setItem("api_key", data.api_key);

      const params = new URLSearchParams({ key: data.api_key, secret: data.api_secret });
      window.location.href = `/signup/success?${params}`;
    } else {
      showAlert("error", data.detail || "Could not create account. Email may already be registered.");
    }
  } catch {
    showAlert("error", "Could not reach the server. Please try again.");
  } finally {
    setLoading(false);
  }
});

// ── Helpers ───────────────────────────────────────────────────────────
function isValidEmail(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e); }

function showFieldError(input, errorId) {
  input.classList.add("error");
  document.getElementById(errorId).classList.add("visible");
}

function clearErrors() {
  [usernameInput, emailInput, passInput, confirmInput]
    .forEach(el => el.classList.remove("error"));
  document.querySelectorAll(".error-msg")
    .forEach(el => el.classList.remove("visible"));
  [errorAlert, successAlert].forEach(el => {
    el.classList.remove("visible");
    el.textContent = "";
  });
}

function showAlert(type, message) {
  const el = type === "error" ? errorAlert : successAlert;
  el.textContent = message;
  el.classList.add("visible");
}

function setLoading(loading) {
  signupBtn.disabled  = loading;
  signupBtn.innerHTML = loading
    ? '<span class="spinner"></span> Creating account...'
    : "Create Account";
}
